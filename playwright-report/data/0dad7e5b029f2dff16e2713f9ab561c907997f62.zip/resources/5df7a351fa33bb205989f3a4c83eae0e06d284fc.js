;!function(){try { var e="undefined"!=typeof globalThis?globalThis:"undefined"!=typeof global?global:"undefined"!=typeof window?window:"undefined"!=typeof self?self:{},n=(new e.Error).stack;n&&((e._debugIds|| (e._debugIds={}))[n]="ebf9fdc5-5736-d52d-21a9-246663bbed0b")}catch(e){}}();
(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[project]/lib/ui-mode.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * UI Mode Configuration
 * 
 * Reads NEXT_PUBLIC_UI_MODE environment variable to control app-wide UI state
 * for visual regression testing.
 * 
 * Modes:
 * - "suspense": Force all pages to show loading/suspense states
 * - "empty": Force all pages to show empty states (no contacts)
 * - "normal": Use real data (default)
 * 
 * If the variable is missing, commented out, or empty, defaults to "normal"
 */ __turbopack_context__.s([
    "getUIMode",
    ()=>getUIMode
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = /*#__PURE__*/ __turbopack_context__.i("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
function getUIMode() {
    const envValue = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].env.NEXT_PUBLIC_UI_MODE;
    // If undefined, empty string, or whitespace-only, default to "normal"
    if (!envValue || envValue.trim() === "") {
        return "normal";
    }
    const normalizedValue = envValue.trim().toLowerCase();
    // Validate and return the mode
    if (normalizedValue === "suspense" || normalizedValue === "empty" || normalizedValue === "normal") {
        return normalizedValue;
    }
    // Invalid value - warn and default to "normal"
    if ("TURBOPACK compile-time truthy", 1) {
        console.warn(`Invalid NEXT_PUBLIC_UI_MODE value: "${envValue}". ` + `Valid values are: "suspense", "empty", "normal". Defaulting to "normal".`);
    }
    return "normal";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContact.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useContact",
    ()=>useContact
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ui-mode.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function useContact(userId, contactId) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contact",
            userId,
            contactId
        ],
        queryFn: {
            "useContact.useQuery[query]": async ()=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`);
                if (!response.ok) {
                    if (response.status === 404) {
                        return null;
                    }
                    const errorData = await response.json().catch({
                        "useContact.useQuery[query]": ()=>({})
                    }["useContact.useQuery[query]"]);
                    throw new Error(errorData.error || "Failed to fetch contact");
                }
                const data = await response.json();
                return data.contact;
            }
        }["useContact.useQuery[query]"],
        staleTime: 0,
        enabled: !!userId && !!contactId,
        // ⭐ ONLY placeholderData — NO initialData
        // This ensures optimistic updates persist during refetches
        placeholderData: {
            "useContact.useQuery[query]": ()=>{
                // First check if we have the individual contact query data (includes optimistic updates)
                const detail = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                if (detail) return detail;
                // Otherwise fall back to contacts list
                const list = queryClient.getQueryData([
                    "contacts",
                    userId
                ]);
                return list?.find({
                    "useContact.useQuery[query]": (c)=>c.contactId === contactId
                }["useContact.useQuery[query]"]);
            }
        }["useContact.useQuery[query]"]
    });
    const uiMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUIMode"])();
    // Override query result based on UI mode
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useContact.useMemo": ()=>{
            if (uiMode === "suspense") {
                return {
                    ...query,
                    data: undefined,
                    isLoading: true
                };
            }
            if (uiMode === "empty") {
                return {
                    ...query,
                    data: undefined,
                    isLoading: false
                };
            }
            return query;
        }
    }["useContact.useMemo"], [
        query,
        uiMode
    ]);
}
_s(useContact, "wZf+12UpbbP5RRtCZ5pP5uR42PI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useActionItems.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useActionItems",
    ()=>useActionItems
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/ui-mode.ts [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function useActionItems(userId, contactId, initialData) {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const queryKey = contactId ? [
        "action-items",
        userId,
        contactId
    ] : [
        "action-items",
        userId
    ];
    const query = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey,
        queryFn: {
            "useActionItems.useQuery[query]": async ()=>{
                if (contactId) {
                    const response = await fetch(`/api/action-items?contactId=${encodeURIComponent(contactId)}`);
                    if (!response.ok) {
                        const errorData = await response.json().catch({
                            "useActionItems.useQuery[query]": ()=>({})
                        }["useActionItems.useQuery[query]"]);
                        throw new Error(errorData.error || "Failed to fetch action items");
                    }
                    const data = await response.json();
                    return data.actionItems;
                } else {
                    const response = await fetch("/api/action-items/all");
                    if (!response.ok) {
                        const errorData = await response.json().catch({
                            "useActionItems.useQuery[query]": ()=>({})
                        }["useActionItems.useQuery[query]"]);
                        throw new Error(errorData.error || "Failed to fetch action items");
                    }
                    const data = await response.json();
                    return data.actionItems;
                }
            }
        }["useActionItems.useQuery[query]"],
        enabled: !!userId,
        initialData,
        // If fetching single contact's action items, use all action items cache as placeholder
        // This is a valid optimization: show filtered items while fetching
        placeholderData: {
            "useActionItems.useQuery[query]": ()=>{
                if (contactId) {
                    const allActionItems = queryClient.getQueryData([
                        "action-items",
                        userId
                    ]);
                    if (allActionItems) {
                        return allActionItems.filter({
                            "useActionItems.useQuery[query]": (item)=>item.contactId === contactId
                        }["useActionItems.useQuery[query]"]);
                    }
                }
                return undefined;
            }
        }["useActionItems.useQuery[query]"]
    });
    const uiMode = (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$ui$2d$mode$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getUIMode"])();
    // Override query result based on UI mode
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "useActionItems.useMemo": ()=>{
            if (uiMode === "suspense") {
                return {
                    ...query,
                    data: undefined,
                    isLoading: true
                };
            }
            if (uiMode === "empty") {
                return {
                    ...query,
                    data: [],
                    isLoading: false
                };
            }
            return query;
        }
    }["useActionItems.useMemo"], [
        query,
        uiMode
    ]);
}
_s(useActionItems, "wZf+12UpbbP5RRtCZ5pP5uR42PI=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/timestamp-utils-server.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Convert Firestore Timestamp to ISO string for JSON serialization
 * 
 * This function handles multiple timestamp formats:
 * - Firestore Timestamp objects (with toDate() or toMillis() methods)
 * - Serialized Firestore Timestamps (with _seconds/_nanoseconds or seconds/nanoseconds)
 * - JavaScript Date objects
 * - ISO string dates (returns as-is)
 * 
 * @param value - The timestamp value to convert
 * @returns ISO string representation or null if value is null/undefined/invalid
 */ __turbopack_context__.s([
    "convertTimestamp",
    ()=>convertTimestamp,
    "convertTimestampToISO",
    ()=>convertTimestampToISO
]);
function convertTimestampToISO(value) {
    if (!value) return null;
    // Handle Firestore Timestamp objects with toDate() method
    if (value && typeof value === "object" && "toDate" in value) {
        const timestamp = value;
        return timestamp.toDate().toISOString();
    }
    // Handle Firestore Timestamp objects with toMillis() method
    if (value && typeof value === "object" && "toMillis" in value) {
        const timestamp = value;
        return new Date(timestamp.toMillis()).toISOString();
    }
    // Handle Firestore Timestamp serialized format with underscores
    if (value && typeof value === "object" && "_seconds" in value && "_nanoseconds" in value) {
        const timestamp = value;
        return new Date(timestamp._seconds * 1000 + timestamp._nanoseconds / 1000000).toISOString();
    }
    // Handle Firestore Timestamp serialized format without underscores
    if (value && typeof value === "object" && "seconds" in value && "nanoseconds" in value) {
        const timestamp = value;
        return new Date(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000).toISOString();
    }
    // Handle JavaScript Date objects
    if (value instanceof Date) {
        return value.toISOString();
    }
    // Handle ISO strings (return as-is)
    if (typeof value === "string") {
        return value;
    }
    return null;
}
function convertTimestamp(value) {
    const converted = convertTimestampToISO(value);
    return converted !== null ? converted : value;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ThemedSuspense.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ThemedSuspense,
    "getThemedFallback",
    ()=>getThemedFallback
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
"use client";
;
;
function getThemedFallback(variant = "default") {
    switch(variant){
        case "simple":
            // Simple bar skeleton for small content
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "h-8 w-16 bg-theme-light rounded animate-pulse"
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 20,
                columnNumber: 9
            }, this);
        case "card":
            // Single card skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "bg-card-highlight-light rounded-xl shadow p-4 animate-pulse",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-4",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 28,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 space-y-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-5 bg-theme-light rounded w-2/3"
                                }, void 0, false, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 30,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "h-4 bg-theme-light rounded w-1/2"
                                }, void 0, false, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 31,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 29,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ThemedSuspense.tsx",
                    lineNumber: 27,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 26,
                columnNumber: 9
            }, this);
        case "list":
            // List skeleton without card wrapper
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: Array.from({
                    length: 3
                }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center gap-4 p-4 bg-card-highlight-light rounded-sm animate-pulse",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                            }, void 0, false, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 43,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 space-y-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-5 bg-theme-light rounded w-2/3"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 45,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-4 bg-theme-light rounded w-1/2"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 46,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 44,
                                columnNumber: 15
                            }, this)
                        ]
                    }, i, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 42,
                        columnNumber: 13
                    }, this))
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 40,
                columnNumber: 9
            }, this);
        case "dashboard":
            // Dashboard loading skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "grid grid-cols-1 xl:grid-cols-[1fr_340px] gap-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-40 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 60,
                                        columnNumber: 17
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-3",
                                        children: Array.from({
                                            length: 3
                                        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex items-center gap-4",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                                                    }, void 0, false, {
                                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                                        lineNumber: 64,
                                                        columnNumber: 23
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex-1 space-y-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "h-5 bg-theme-light rounded w-2/3"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ThemedSuspense.tsx",
                                                                lineNumber: 66,
                                                                columnNumber: 25
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                                className: "h-4 bg-theme-light rounded w-1/2"
                                                            }, void 0, false, {
                                                                fileName: "[project]/components/ThemedSuspense.tsx",
                                                                lineNumber: 67,
                                                                columnNumber: 25
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                                        lineNumber: 65,
                                                        columnNumber: 23
                                                    }, this)
                                                ]
                                            }, i, true, {
                                                fileName: "[project]/components/ThemedSuspense.tsx",
                                                lineNumber: 63,
                                                columnNumber: 21
                                            }, this))
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 61,
                                        columnNumber: 17
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 59,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 58,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "space-y-6",
                            children: Array.from({
                                length: 4
                            }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-6 bg-theme-light rounded w-32 mb-4"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 77,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "h-32 bg-theme-light rounded"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 78,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, i, true, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 76,
                                    columnNumber: 17
                                }, this))
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 74,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/components/ThemedSuspense.tsx",
                    lineNumber: 57,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 56,
                columnNumber: 9
            }, this);
        case "page":
            // Full page loading skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-10 w-24 bg-theme-light rounded animate-pulse"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 91,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 90,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 95,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-32 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 96,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 94,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 99,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-64 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 100,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 98,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 93,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 89,
                columnNumber: 9
            }, this);
        case "sync":
            // Sync page loading skeleton
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-8",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "h-10 w-24 bg-theme-light rounded animate-pulse"
                        }, void 0, false, {
                            fileName: "[project]/components/ThemedSuspense.tsx",
                            lineNumber: 111,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 110,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-8",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 115,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-32 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 116,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 114,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-6 animate-pulse",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-6 bg-theme-light rounded w-32 mb-4"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 119,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "h-64 bg-theme-light rounded"
                                    }, void 0, false, {
                                        fileName: "[project]/components/ThemedSuspense.tsx",
                                        lineNumber: 120,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 118,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 113,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 109,
                columnNumber: 9
            }, this);
        case "default":
        default:
            // Card-based list skeleton (default)
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "h-6 bg-card-highlight-light rounded w-32 mb-2 animate-pulse"
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 131,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-1 gap-3",
                        children: Array.from({
                            length: 5
                        }).map((_, i)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "bg-card-highlight-light rounded-xl shadow p-4 animate-pulse",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "w-12 h-12 bg-theme-light rounded-full shrink-0"
                                        }, void 0, false, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 136,
                                            columnNumber: 19
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 space-y-2",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-5 bg-theme-light rounded w-2/3"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                                    lineNumber: 138,
                                                    columnNumber: 21
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "h-4 bg-theme-light rounded w-1/2"
                                                }, void 0, false, {
                                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                                    lineNumber: 139,
                                                    columnNumber: 21
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/components/ThemedSuspense.tsx",
                                            lineNumber: 137,
                                            columnNumber: 19
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/components/ThemedSuspense.tsx",
                                    lineNumber: 135,
                                    columnNumber: 17
                                }, this)
                            }, i, false, {
                                fileName: "[project]/components/ThemedSuspense.tsx",
                                lineNumber: 134,
                                columnNumber: 15
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/components/ThemedSuspense.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/ThemedSuspense.tsx",
                lineNumber: 130,
                columnNumber: 9
            }, this);
    }
}
function ThemedSuspense({ children, fallback, variant = "default", isLoading = false }) {
    // If isLoading is true, show fallback immediately (for conditional rendering)
    if (isLoading) {
        if (fallback !== undefined) {
            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: fallback
            }, void 0, false);
        }
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
            children: getThemedFallback(variant)
        }, void 0, false);
    }
    // For Suspense mode, children is required
    if (!children) {
        return null;
    }
    // If custom fallback provided, use it
    if (fallback !== undefined) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
            fallback: fallback,
            children: children
        }, void 0, false, {
            fileName: "[project]/components/ThemedSuspense.tsx",
            lineNumber: 186,
            columnNumber: 12
        }, this);
    }
    // Use themed fallback based on variant
    const defaultFallback = getThemedFallback(variant);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Suspense"], {
        fallback: defaultFallback,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/ThemedSuspense.tsx",
        lineNumber: 191,
        columnNumber: 10
    }, this);
}
_c = ThemedSuspense;
var _c;
__turbopack_context__.k.register(_c, "ThemedSuspense");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Skeleton.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Skeleton
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function Skeleton({ className = "", variant = "default", width, height, rounded = "md" }) {
    // Base classes - always use theme-aware colors
    const baseClasses = "animate-pulse";
    // Variant-specific background colors
    let bgClass = "";
    switch(variant){
        case "card":
            bgClass = "bg-card-highlight-light";
            break;
        case "circle":
            bgClass = "bg-theme-light";
            break;
        case "text":
            bgClass = "bg-theme-light";
            break;
        default:
            bgClass = "bg-theme-light";
            break;
    }
    // Rounded classes
    const roundedClass = variant === "circle" ? "rounded-full" : rounded === "none" ? "" : `rounded-${rounded}`;
    // Height default for text variant
    const heightClass = height || (variant === "text" ? "h-4" : "");
    // Combine all classes
    const combinedClasses = [
        baseClasses,
        bgClass,
        width,
        heightClass,
        roundedClass,
        className
    ].filter(Boolean).join(" ");
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: combinedClasses
    }, void 0, false, {
        fileName: "[project]/components/Skeleton.tsx",
        lineNumber: 76,
        columnNumber: 10
    }, this);
}
_c = Skeleton;
var _c;
__turbopack_context__.k.register(_c, "Skeleton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useContactMutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useArchiveContact",
    ()=>useArchiveContact,
    "useBulkArchiveContacts",
    ()=>useBulkArchiveContacts,
    "useBulkUpdateCompanies",
    ()=>useBulkUpdateCompanies,
    "useBulkUpdateSegments",
    ()=>useBulkUpdateSegments,
    "useBulkUpdateTags",
    ()=>useBulkUpdateTags,
    "useCreateContact",
    ()=>useCreateContact,
    "useDeleteContact",
    ()=>useDeleteContact,
    "useUpdateContact",
    ()=>useUpdateContact,
    "useUpdateTouchpointStatus",
    ()=>useUpdateTouchpointStatus
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature(), _s3 = __turbopack_context__.k.signature(), _s4 = __turbopack_context__.k.signature(), _s5 = __turbopack_context__.k.signature(), _s6 = __turbopack_context__.k.signature(), _s7 = __turbopack_context__.k.signature(), _s8 = __turbopack_context__.k.signature();
"use client";
;
;
function useCreateContact() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useCreateContact.useMutation": async (contactData)=>{
                const response = await fetch("/api/contacts", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(contactData)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useCreateContact.useMutation": ()=>({})
                    }["useCreateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to create contact");
                }
                const data = await response.json();
                return data.contactId;
            }
        }["useCreateContact.useMutation"],
        onSuccess: {
            "useCreateContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useCreateContact.useMutation"],
        onError: {
            "useCreateContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Creating contact",
                    tags: {
                        component: "useCreateContact"
                    }
                });
            }
        }["useCreateContact.useMutation"]
    });
}
_s(useCreateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateContact(userId) {
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    // Defensive contact matcher - handles contactId, id, or _id fields
    const isSameContact = (c, contactId)=>{
        return c.contactId === contactId || c.id === contactId || c._id === contactId;
    };
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(updates)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateContact.useMutation": ()=>({})
                    }["useUpdateContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to update contact");
                }
                const data = await response.json();
                return data.contact; // API now returns { contact: Contact }
            }
        }["useUpdateContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update both detail and ALL list caches so UI feels instant
     */ onMutate: {
            "useUpdateContact.useMutation": async ({ contactId, updates })=>{
                // Cancel all related queries
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ],
                    exact: false
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Snapshot previous detail state (for this specific user+contact, if such a query exists)
                const prevDetail = userId ? queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]) : undefined;
                // Snapshot ALL contacts lists (regardless of key shape)
                const prevLists = {};
                queryClient.getQueryCache().findAll({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }).forEach({
                    "useUpdateContact.useMutation": (q)=>{
                        const key = JSON.stringify(q.queryKey);
                        const data = q.state.data;
                        if (data) prevLists[key] = data;
                    }
                }["useUpdateContact.useMutation"]);
                // Optimistically update detail (if userId provided)
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], {
                        "useUpdateContact.useMutation": (old)=>old ? {
                                ...old,
                                ...updates
                            } : old
                    }["useUpdateContact.useMutation"]);
                }
                // Optimistically update ALL contacts lists (regardless of key shape)
                queryClient.setQueriesData({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                }, {
                    "useUpdateContact.useMutation": (old)=>{
                        if (!old || !Array.isArray(old)) return old;
                        return old.map({
                            "useUpdateContact.useMutation": (c)=>isSameContact(c, contactId) ? {
                                    ...c,
                                    ...updates
                                } : c
                        }["useUpdateContact.useMutation"]);
                    }
                }["useUpdateContact.useMutation"]);
                return {
                    prevDetail,
                    prevLists
                };
            }
        }["useUpdateContact.useMutation"],
        /**
     * SUCCESS — update detail only & delay list invalidation
     * Firestore eventual consistency means list queries might not see the update immediately
     * So we invalidate after a delay to let Firestore propagate the change
     */ onSuccess: {
            "useUpdateContact.useMutation": (updatedContact, variables)=>{
                const { contactId, updates } = variables;
                // Update detail cache with actual server result
                if (userId) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        contactId
                    ], updatedContact);
                }
                // If touchpoint date was updated, invalidate calendar events
                if (updates.nextTouchpointDate !== undefined) {
                    queryClient.invalidateQueries({
                        queryKey: [
                            "calendar-events"
                        ],
                        exact: false
                    });
                }
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ],
                    exact: false
                });
                // Invalidate dashboard stats to ensure consistency
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ],
                    exact: false
                });
            }
        }["useUpdateContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateContact.useMutation": (error, variables, context)=>{
                // Restore detail (if userId provided)
                if (userId && context?.prevDetail) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prevDetail);
                }
                // Restore ALL contacts lists
                if (context?.prevLists) {
                    for (const [key, data] of Object.entries(context.prevLists)){
                        queryClient.setQueryData(JSON.parse(key), data);
                    }
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating contact",
                    tags: {
                        component: "useUpdateContact"
                    }
                });
            }
        }["useUpdateContact.useMutation"]
    });
}
_s1(useUpdateContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useDeleteContact() {
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useDeleteContact.useMutation": async (contactId)=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}`, {
                    method: "DELETE"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useDeleteContact.useMutation": ()=>({})
                    }["useDeleteContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to delete contact");
                }
                return response.json();
            }
        }["useDeleteContact.useMutation"],
        onSuccess: {
            "useDeleteContact.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ]
                });
            }
        }["useDeleteContact.useMutation"],
        onError: {
            "useDeleteContact.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting contact",
                    tags: {
                        component: "useDeleteContact"
                    }
                });
            }
        }["useDeleteContact.useMutation"]
    });
}
_s2(useDeleteContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useArchiveContact(userId) {
    _s3();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/archive`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useArchiveContact.useMutation": ()=>({})
                    }["useArchiveContact.useMutation"]);
                    throw new Error(errorData.error || "Failed to archive contact");
                }
                return response.json();
            }
        }["useArchiveContact.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useArchiveContact.useMutation": async ({ contactId, archived })=>{
                if (!userId) return;
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            archived
                        };
                    }
                }["useArchiveContact.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useArchiveContact.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useArchiveContact.useMutation": (c)=>c.contactId === contactId ? {
                                    ...c,
                                    archived
                                } : c
                        }["useArchiveContact.useMutation"]);
                    }
                }["useArchiveContact.useMutation"]);
                return {
                    prev
                };
            }
        }["useArchiveContact.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useArchiveContact.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Archiving contact",
                    tags: {
                        component: "useArchiveContact"
                    }
                });
            }
        }["useArchiveContact.useMutation"],
        onSettled: {
            "useArchiveContact.useMutation": ()=>{
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useArchiveContact.useMutation"]
    });
}
_s3(useArchiveContact, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateTouchpointStatus(userId) {
    _s4();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/touchpoint-status`, {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        status,
                        reason
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateTouchpointStatus.useMutation": ()=>({})
                    }["useUpdateTouchpointStatus.useMutation"]);
                    // Throw user-friendly error message - will be extracted by component
                    const errorMessage = errorData.error || "Failed to update touchpoint status. Please try again.";
                    throw new Error(errorMessage);
                }
                const data = await response.json();
                return {
                    ...data,
                    contactId,
                    status,
                    reason
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * OPTIMISTIC UPDATE
     * Immediately update the cache so UI feels instant
     */ onMutate: {
            "useUpdateTouchpointStatus.useMutation": async ({ contactId, status, reason })=>{
                if (!userId) return;
                // Cancel outgoing refetches to avoid overwriting optimistic update
                await queryClient.cancelQueries({
                    queryKey: [
                        "contact",
                        userId,
                        contactId
                    ]
                });
                await queryClient.cancelQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                // Snapshot previous value for rollback
                const prev = queryClient.getQueryData([
                    "contact",
                    userId,
                    contactId
                ]);
                // Update cache immediately - UI updates instantly
                queryClient.setQueryData([
                    "contact",
                    userId,
                    contactId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return {
                            ...old,
                            touchpointStatus: status,
                            touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                            touchpointStatusReason: reason !== undefined ? reason : old.touchpointStatusReason
                        };
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                // Also update in contacts list
                queryClient.setQueryData([
                    "contacts",
                    userId
                ], {
                    "useUpdateTouchpointStatus.useMutation": (old)=>{
                        if (!old) return old;
                        return old.map({
                            "useUpdateTouchpointStatus.useMutation": (contact)=>contact.contactId === contactId ? {
                                    ...contact,
                                    touchpointStatus: status,
                                    touchpointStatusUpdatedAt: status !== null ? new Date().toISOString() : null,
                                    touchpointStatusReason: reason !== undefined ? reason : contact.touchpointStatusReason
                                } : contact
                        }["useUpdateTouchpointStatus.useMutation"]);
                    }
                }["useUpdateTouchpointStatus.useMutation"]);
                return {
                    prev
                };
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Roll back if error
     */ onError: {
            "useUpdateTouchpointStatus.useMutation": (error, variables, context)=>{
                if (userId && context?.prev) {
                    queryClient.setQueryData([
                        "contact",
                        userId,
                        variables.contactId
                    ], context.prev);
                }
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status",
                    tags: {
                        component: "useUpdateTouchpointStatus"
                    }
                });
            }
        }["useUpdateTouchpointStatus.useMutation"],
        /**
     * Invalidate after success to ensure server consistency
     */ onSettled: {
            "useUpdateTouchpointStatus.useMutation": (_data, _error, vars)=>{
                if (!userId) return;
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact",
                        userId,
                        vars.contactId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts",
                        userId
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ],
                    exact: false
                });
                // Invalidate calendar events when touchpoint status changes
                queryClient.invalidateQueries({
                    queryKey: [
                        "calendar-events"
                    ],
                    exact: false
                });
            }
        }["useUpdateTouchpointStatus.useMutation"]
    });
}
_s4(useUpdateTouchpointStatus, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkArchiveContacts() {
    _s5();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkArchiveContacts.useMutation": async ({ contactIds, archived })=>{
                const response = await fetch("/api/contacts/bulk-archive", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        archived
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkArchiveContacts.useMutation": ()=>({})
                    }["useBulkArchiveContacts.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk archive contacts");
                }
                return response.json();
            }
        }["useBulkArchiveContacts.useMutation"],
        onSuccess: {
            "useBulkArchiveContacts.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkArchiveContacts.useMutation"],
        onError: {
            "useBulkArchiveContacts.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk archiving contacts",
                    tags: {
                        component: "useBulkArchiveContacts"
                    }
                });
            }
        }["useBulkArchiveContacts.useMutation"]
    });
}
_s5(useBulkArchiveContacts, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateSegments() {
    _s6();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateSegments.useMutation": async ({ contactIds, segment })=>{
                const response = await fetch("/api/contacts/bulk-segment", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        segment
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateSegments.useMutation": ()=>({})
                    }["useBulkUpdateSegments.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update segments");
                }
                return response.json();
            }
        }["useBulkUpdateSegments.useMutation"],
        onSuccess: {
            "useBulkUpdateSegments.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateSegments.useMutation"],
        onError: {
            "useBulkUpdateSegments.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact segments",
                    tags: {
                        component: "useBulkUpdateSegments"
                    }
                });
            }
        }["useBulkUpdateSegments.useMutation"]
    });
}
_s6(useBulkUpdateSegments, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateTags() {
    _s7();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateTags.useMutation": async ({ contactIds, tags })=>{
                const response = await fetch("/api/contacts/bulk-tags", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        tags
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateTags.useMutation": ()=>({})
                    }["useBulkUpdateTags.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update tags");
                }
                return response.json();
            }
        }["useBulkUpdateTags.useMutation"],
        onSuccess: {
            "useBulkUpdateTags.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateTags.useMutation"],
        onError: {
            "useBulkUpdateTags.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact tags",
                    tags: {
                        component: "useBulkUpdateTags"
                    }
                });
            }
        }["useBulkUpdateTags.useMutation"]
    });
}
_s7(useBulkUpdateTags, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useBulkUpdateCompanies() {
    _s8();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useBulkUpdateCompanies.useMutation": async ({ contactIds, company })=>{
                const response = await fetch("/api/contacts/bulk-company", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactIds,
                        company
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useBulkUpdateCompanies.useMutation": ()=>({})
                    }["useBulkUpdateCompanies.useMutation"]);
                    throw new Error(errorData.error || "Failed to bulk update companies");
                }
                return response.json();
            }
        }["useBulkUpdateCompanies.useMutation"],
        onSuccess: {
            "useBulkUpdateCompanies.useMutation": ()=>{
                // Invalidate by prefixes → guarantees matching all screen variations
                queryClient.invalidateQueries({
                    queryKey: [
                        "contacts"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "contact"
                    ]
                });
                queryClient.invalidateQueries({
                    queryKey: [
                        "dashboard-stats"
                    ]
                });
            }
        }["useBulkUpdateCompanies.useMutation"],
        onError: {
            "useBulkUpdateCompanies.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Bulk updating contact companies",
                    tags: {
                        component: "useBulkUpdateCompanies"
                    }
                });
            }
        }["useBulkUpdateCompanies.useMutation"]
    });
}
_s8(useBulkUpdateCompanies, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Card.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Card
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Card({ children, className = "", padding = "md", hover = false }) {
    const paddingClasses = {
        none: "",
        sm: "p-3",
        md: "p-6",
        lg: "p-8",
        xl: "p-12",
        responsive: "p-3 xl:p-6"
    };
    const baseClasses = "bg-card-light rounded-sm shadow-sm border border-theme-lighter";
    const paddingClass = padding === "none" || className.includes("p-") ? "" : paddingClasses[padding];
    const hoverClasses = hover ? "hover:shadow-[0px_6px_16px_rgba(0,0,0,0.15)] transition-shadow duration-200" : "";
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `${baseClasses} ${paddingClass} ${hoverClasses} ${className}`.trim(),
        children: children
    }, void 0, false, {
        fileName: "[project]/components/Card.tsx",
        lineNumber: 30,
        columnNumber: 5
    }, this);
}
_c = Card;
var _c;
__turbopack_context__.k.register(_c, "Card");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Input.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
;
/**
 * Reusable Input component with consistent styling
 * Provides consistent styling across all text input elements in the application
 */ const Input = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].forwardRef(_c = ({ className = "", ...props }, ref)=>{
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
        ref: ref,
        ...props,
        className: `w-full px-4 py-2 border border-theme-darker placeholder:text-foreground rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Input.tsx",
        lineNumber: 10,
        columnNumber: 7
    }, ("TURBOPACK compile-time value", void 0));
});
_c1 = Input;
Input.displayName = "Input";
const __TURBOPACK__default__export__ = Input;
var _c, _c1;
__turbopack_context__.k.register(_c, "Input$React.forwardRef");
__turbopack_context__.k.register(_c1, "Input");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/contacts/ContactAutosaveProvider.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "ContactAutosaveContext",
    ()=>ContactAutosaveContext,
    "ContactAutosaveProvider",
    ()=>ContactAutosaveProvider,
    "useContactAutosave",
    ()=>useContactAutosave
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
const ContactAutosaveContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function ContactAutosaveProvider({ children }) {
    _s();
    const [dirtyKeys, setDirtyKeys] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const [isSaving, setIsSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [pendingCount, setPendingCount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(0);
    const [lastSavedAt, setLastSavedAt] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [lastError, setLastError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [pendingPromises, setPendingPromises] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(new Set());
    const flushCallbackRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const markDirty = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[markDirty]": (key)=>{
            setDirtyKeys({
                "ContactAutosaveProvider.useCallback[markDirty]": (prev)=>{
                    const next = new Set(prev);
                    next.add(key);
                    return next;
                }
            }["ContactAutosaveProvider.useCallback[markDirty]"]);
            // Clear error when marking dirty (user is making new changes)
            setLastError(null);
        }
    }["ContactAutosaveProvider.useCallback[markDirty]"], []);
    const markClean = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[markClean]": (key)=>{
            setDirtyKeys({
                "ContactAutosaveProvider.useCallback[markClean]": (prev)=>{
                    const next = new Set(prev);
                    next.delete(key);
                    return next;
                }
            }["ContactAutosaveProvider.useCallback[markClean]"]);
            setLastSavedAt(Date.now());
        }
    }["ContactAutosaveProvider.useCallback[markClean]"], []);
    const setError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[setError]": (error)=>{
            setLastError(error);
        }
    }["ContactAutosaveProvider.useCallback[setError]"], []);
    const registerPending = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[registerPending]": (promise, key)=>{
            setPendingPromises({
                "ContactAutosaveProvider.useCallback[registerPending]": (prev)=>{
                    const next = new Set(prev);
                    next.add(promise);
                    return next;
                }
            }["ContactAutosaveProvider.useCallback[registerPending]"]);
            setPendingCount({
                "ContactAutosaveProvider.useCallback[registerPending]": (prev)=>prev + 1
            }["ContactAutosaveProvider.useCallback[registerPending]"]);
            setIsSaving(true);
            promise.then({
                "ContactAutosaveProvider.useCallback[registerPending]": ()=>{
                    setPendingPromises({
                        "ContactAutosaveProvider.useCallback[registerPending]": (prev)=>{
                            const next = new Set(prev);
                            next.delete(promise);
                            return next;
                        }
                    }["ContactAutosaveProvider.useCallback[registerPending]"]);
                    setPendingCount({
                        "ContactAutosaveProvider.useCallback[registerPending]": (prev)=>{
                            const newCount = prev - 1;
                            if (newCount === 0) {
                                setIsSaving(false);
                            }
                            return newCount;
                        }
                    }["ContactAutosaveProvider.useCallback[registerPending]"]);
                }
            }["ContactAutosaveProvider.useCallback[registerPending]"]).catch({
                "ContactAutosaveProvider.useCallback[registerPending]": (error)=>{
                    setPendingPromises({
                        "ContactAutosaveProvider.useCallback[registerPending]": (prev)=>{
                            const next = new Set(prev);
                            next.delete(promise);
                            return next;
                        }
                    }["ContactAutosaveProvider.useCallback[registerPending]"]);
                    setPendingCount({
                        "ContactAutosaveProvider.useCallback[registerPending]": (prev)=>{
                            const newCount = prev - 1;
                            if (newCount === 0) {
                                setIsSaving(false);
                            }
                            return newCount;
                        }
                    }["ContactAutosaveProvider.useCallback[registerPending]"]);
                    // Set error if provided
                    const errorMessage = error instanceof Error ? error.message : "Failed to save changes";
                    setLastError({
                        message: errorMessage,
                        key
                    });
                }
            }["ContactAutosaveProvider.useCallback[registerPending]"]);
        }
    }["ContactAutosaveProvider.useCallback[registerPending]"], []);
    const registerFlushCallback = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[registerFlushCallback]": (callback)=>{
            flushCallbackRef.current = callback;
        }
    }["ContactAutosaveProvider.useCallback[registerFlushCallback]"], []);
    const flush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[flush]": async ()=>{
            // First, trigger the hook's flush to execute any scheduled saves
            if (flushCallbackRef.current) {
                try {
                    await flushCallbackRef.current();
                } catch (error) {
                // Errors are handled by individual save functions
                }
            }
            // Then wait for all pending promises to complete
            if (pendingPromises.size > 0) {
                try {
                    await Promise.allSettled(Array.from(pendingPromises));
                } catch (error) {
                // Individual promises handle their own errors
                }
            }
            // Return true if everything is saved, false if there are still errors or dirty keys
            return dirtyKeys.size === 0 && pendingCount === 0 && lastError === null;
        }
    }["ContactAutosaveProvider.useCallback[flush]"], [
        pendingPromises,
        dirtyKeys,
        pendingCount,
        lastError
    ]);
    const clearError = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "ContactAutosaveProvider.useCallback[clearError]": ()=>{
            setLastError(null);
        }
    }["ContactAutosaveProvider.useCallback[clearError]"], []);
    const hasUnsavedChanges = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactAutosaveProvider.useMemo[hasUnsavedChanges]": ()=>{
            return dirtyKeys.size > 0 || pendingCount > 0;
        }
    }["ContactAutosaveProvider.useMemo[hasUnsavedChanges]"], [
        dirtyKeys,
        pendingCount
    ]);
    const value = {
        dirtyKeys,
        isSaving,
        pendingCount,
        lastSavedAt,
        lastError,
        hasUnsavedChanges,
        markDirty,
        markClean,
        registerPending,
        setError,
        registerFlushCallback,
        flush,
        clearError
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactAutosaveContext.Provider, {
        value: value,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/contacts/ContactAutosaveProvider.tsx",
        lineNumber: 153,
        columnNumber: 5
    }, this);
}
_s(ContactAutosaveProvider, "A/E0mJTzsjUQ9efiOHjEDRFtt/I=");
_c = ContactAutosaveProvider;
function useContactAutosave() {
    _s1();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(ContactAutosaveContext);
    if (context === undefined) {
        throw new Error("useContactAutosave must be used within ContactAutosaveProvider");
    }
    return context;
}
_s1(useContactAutosave, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
var _c;
__turbopack_context__.k.register(_c, "ContactAutosaveProvider");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useDebouncedAutosave",
    ()=>useDebouncedAutosave
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactAutosaveProvider.tsx [app-client] (ecmascript)");
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function useDebouncedAutosave(options = {}) {
    _s();
    const { delayMs = 700 } = options;
    const { markDirty, markClean, registerPending, setError, registerFlushCallback } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactAutosave"])();
    const timersRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    const saveFunctionsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(new Map());
    // Register flush callback with provider
    // Use a ref to store the latest flush function so it doesn't need to be in dependencies
    const flushAllRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDebouncedAutosave.useEffect": ()=>{
            flushAllRef.current = ({
                "useDebouncedAutosave.useEffect": async ()=>{
                    const keysToFlush = Array.from(timersRef.current.keys());
                    // Cancel all timers
                    timersRef.current.forEach({
                        "useDebouncedAutosave.useEffect": (timer)=>clearTimeout(timer)
                    }["useDebouncedAutosave.useEffect"]);
                    timersRef.current.clear();
                    // Execute all pending saves
                    const promises = keysToFlush.map({
                        "useDebouncedAutosave.useEffect.promises": async (k)=>{
                            const saveFn = saveFunctionsRef.current.get(k);
                            if (saveFn) {
                                try {
                                    const promise = saveFn();
                                    registerPending(promise, k);
                                    await promise;
                                    markClean(k);
                                    saveFunctionsRef.current.delete(k);
                                } catch (error) {
                                    const errorMessage = error instanceof Error ? error.message : "Failed to save changes";
                                    setError({
                                        message: errorMessage,
                                        key: k
                                    });
                                    // Don't mark clean on error
                                    saveFunctionsRef.current.delete(k);
                                }
                            }
                        }
                    }["useDebouncedAutosave.useEffect.promises"]);
                    await Promise.allSettled(promises);
                }
            })["useDebouncedAutosave.useEffect"];
            registerFlushCallback({
                "useDebouncedAutosave.useEffect": async ()=>{
                    if (flushAllRef.current) {
                        await flushAllRef.current();
                    }
                }
            }["useDebouncedAutosave.useEffect"]);
        }
    }["useDebouncedAutosave.useEffect"], [
        registerFlushCallback,
        registerPending,
        markClean,
        setError
    ]);
    // Cleanup timers on unmount
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "useDebouncedAutosave.useEffect": ()=>{
            return ({
                "useDebouncedAutosave.useEffect": ()=>{
                    timersRef.current.forEach({
                        "useDebouncedAutosave.useEffect": (timer)=>clearTimeout(timer)
                    }["useDebouncedAutosave.useEffect"]);
                    timersRef.current.clear();
                }
            })["useDebouncedAutosave.useEffect"];
        }
    }["useDebouncedAutosave.useEffect"], []);
    const schedule = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDebouncedAutosave.useCallback[schedule]": (key, fn, customDelay)=>{
            // Cancel existing timer for this key
            const existingTimer = timersRef.current.get(key);
            if (existingTimer) {
                clearTimeout(existingTimer);
            }
            // Store the save function
            saveFunctionsRef.current.set(key, fn);
            // Mark as dirty
            markDirty(key);
            // Schedule new save
            const delay = customDelay ?? delayMs;
            const timer = setTimeout({
                "useDebouncedAutosave.useCallback[schedule].timer": async ()=>{
                    const saveFn = saveFunctionsRef.current.get(key);
                    if (!saveFn) return;
                    try {
                        const promise = saveFn();
                        registerPending(promise, key);
                        await promise;
                        markClean(key);
                        saveFunctionsRef.current.delete(key);
                    } catch (error) {
                        const errorMessage = error instanceof Error ? error.message : "Failed to save changes";
                        setError({
                            message: errorMessage,
                            key
                        });
                        // Don't mark clean on error - keep it dirty so user can retry
                        saveFunctionsRef.current.delete(key);
                    } finally{
                        timersRef.current.delete(key);
                    }
                }
            }["useDebouncedAutosave.useCallback[schedule].timer"], delay);
            timersRef.current.set(key, timer);
        }
    }["useDebouncedAutosave.useCallback[schedule]"], [
        delayMs,
        markDirty,
        markClean,
        registerPending,
        setError,
        registerFlushCallback
    ]);
    const flush = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDebouncedAutosave.useCallback[flush]": async (key)=>{
            if (key) {
                // Flush specific key
                const timer = timersRef.current.get(key);
                if (timer) {
                    clearTimeout(timer);
                    timersRef.current.delete(key);
                }
                const saveFn = saveFunctionsRef.current.get(key);
                if (saveFn) {
                    try {
                        const promise = saveFn();
                        registerPending(promise, key);
                        await promise;
                        markClean(key);
                        saveFunctionsRef.current.delete(key);
                    } catch (error) {
                        const errorMessage = error instanceof Error ? error.message : "Failed to save changes";
                        setError({
                            message: errorMessage,
                            key
                        });
                        // Don't mark clean on error
                        saveFunctionsRef.current.delete(key);
                        throw error;
                    }
                }
            } else {
                // Flush all keys
                const keysToFlush = Array.from(timersRef.current.keys());
                // Cancel all timers
                timersRef.current.forEach({
                    "useDebouncedAutosave.useCallback[flush]": (timer)=>clearTimeout(timer)
                }["useDebouncedAutosave.useCallback[flush]"]);
                timersRef.current.clear();
                // Execute all pending saves
                const promises = keysToFlush.map({
                    "useDebouncedAutosave.useCallback[flush].promises": async (k)=>{
                        const saveFn = saveFunctionsRef.current.get(k);
                        if (saveFn) {
                            try {
                                const promise = saveFn();
                                registerPending(promise, k);
                                await promise;
                                markClean(k);
                                saveFunctionsRef.current.delete(k);
                            } catch (error) {
                                const errorMessage = error instanceof Error ? error.message : "Failed to save changes";
                                setError({
                                    message: errorMessage,
                                    key: k
                                });
                                // Don't mark clean on error
                                saveFunctionsRef.current.delete(k);
                            }
                        }
                    }
                }["useDebouncedAutosave.useCallback[flush].promises"]);
                await Promise.allSettled(promises);
            }
        }
    }["useDebouncedAutosave.useCallback[flush]"], [
        markClean,
        registerPending,
        setError
    ]);
    const cancel = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "useDebouncedAutosave.useCallback[cancel]": (key)=>{
            if (key) {
                const timer = timersRef.current.get(key);
                if (timer) {
                    clearTimeout(timer);
                    timersRef.current.delete(key);
                }
                saveFunctionsRef.current.delete(key);
                markClean(key);
            } else {
                // Cancel all
                timersRef.current.forEach({
                    "useDebouncedAutosave.useCallback[cancel]": (timer)=>clearTimeout(timer)
                }["useDebouncedAutosave.useCallback[cancel]"]);
                timersRef.current.clear();
                saveFunctionsRef.current.clear();
            // Note: We don't mark clean all keys here because they might still be dirty
            // The component should handle cleanup
            }
        }
    }["useDebouncedAutosave.useCallback[cancel]"], [
        markClean
    ]);
    return {
        schedule,
        flush,
        cancel
    };
}
_s(useDebouncedAutosave, "3EvAE7hqv/kUxhYfaVwZzoNzBcc=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactAutosave"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>BasicInfoCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function BasicInfoCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { schedule, flush } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"])();
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastSavedValuesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [firstName, setFirstName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [lastName, setLastName] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [company, setCompany] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Use refs to store current values so save function always reads latest state
    const firstNameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(firstName);
    const lastNameRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(lastName);
    const companyRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(company);
    // Keep refs in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BasicInfoCard.useEffect": ()=>{
            firstNameRef.current = firstName;
        }
    }["BasicInfoCard.useEffect"], [
        firstName
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BasicInfoCard.useEffect": ()=>{
            lastNameRef.current = lastName;
        }
    }["BasicInfoCard.useEffect"], [
        lastName
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BasicInfoCard.useEffect": ()=>{
            companyRef.current = company;
        }
    }["BasicInfoCard.useEffect"], [
        company
    ]);
    // Reset form state only when contactId changes (switching to a different contact)
    // Don't reset when contact data updates from our own save
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "BasicInfoCard.useEffect": ()=>{
            if (!contact) return;
            // Only reset if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                lastSavedValuesRef.current = null; // Clear saved values when switching contacts
                // Batch state updates to avoid cascading renders
                setFirstName(contact.firstName ?? "");
                setLastName(contact.lastName ?? "");
                setCompany(contact.company ?? "");
                return;
            }
            // If contact data updated but it matches what we just saved, don't reset
            if (lastSavedValuesRef.current) {
                const saved = lastSavedValuesRef.current;
                const contactMatchesSaved = (contact.firstName ?? "") === saved.firstName && (contact.lastName ?? "") === saved.lastName && (contact.company ?? "") === saved.company;
                if (contactMatchesSaved) {
                    // This update came from our save, don't reset form
                    return;
                }
            }
            // Only update if form values match the old contact values (user hasn't made changes)
            // This prevents overwriting user input when contact refetches
            const formMatchesOldContact = firstName === (contact.firstName ?? "") && lastName === (contact.lastName ?? "") && company === (contact.company ?? "");
            if (formMatchesOldContact) {
                // Form hasn't been edited, safe to update from contact
                setFirstName(contact.firstName ?? "");
                setLastName(contact.lastName ?? "");
                setCompany(contact.company ?? "");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["BasicInfoCard.useEffect"], [
        contact?.contactId,
        contact?.firstName,
        contact?.lastName,
        contact?.company
    ]);
    // Save function for autosave - reads from refs to always get latest values
    const saveBasicInfo = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "BasicInfoCard.useMemo[saveBasicInfo]": ()=>{
            return ({
                "BasicInfoCard.useMemo[saveBasicInfo]": async ()=>{
                    if (!contact) return;
                    // Read current form values from refs (always latest, even if scheduled before state update)
                    const currentFirstName = firstNameRef.current || null;
                    const currentLastName = lastNameRef.current || null;
                    const currentCompany = companyRef.current || null;
                    return new Promise({
                        "BasicInfoCard.useMemo[saveBasicInfo]": (resolve, reject)=>{
                            updateMutation.mutate({
                                contactId,
                                updates: {
                                    firstName: currentFirstName,
                                    lastName: currentLastName,
                                    company: currentCompany
                                }
                            }, {
                                onSuccess: {
                                    "BasicInfoCard.useMemo[saveBasicInfo]": ()=>{
                                        // Remember what we saved so we don't reset form when contact refetches
                                        lastSavedValuesRef.current = {
                                            firstName: currentFirstName ?? "",
                                            lastName: currentLastName ?? "",
                                            company: currentCompany ?? ""
                                        };
                                        resolve();
                                    }
                                }["BasicInfoCard.useMemo[saveBasicInfo]"],
                                onError: {
                                    "BasicInfoCard.useMemo[saveBasicInfo]": (error)=>{
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                                            context: "Saving basic info in BasicInfoCard",
                                            tags: {
                                                component: "BasicInfoCard",
                                                contactId
                                            }
                                        });
                                        reject(error);
                                    }
                                }["BasicInfoCard.useMemo[saveBasicInfo]"]
                            });
                        }
                    }["BasicInfoCard.useMemo[saveBasicInfo]"]);
                }
            })["BasicInfoCard.useMemo[saveBasicInfo]"];
        }
    }["BasicInfoCard.useMemo[saveBasicInfo]"], [
        contact,
        contactId,
        updateMutation
    ]);
    // Handle field changes with autosave
    // Schedule debounced save - refs ensure we always read latest values
    const handleFirstNameChange = (e)=>{
        setFirstName(e.target.value);
        schedule("basic", saveBasicInfo);
    };
    const handleLastNameChange = (e)=>{
        setLastName(e.target.value);
        schedule("basic", saveBasicInfo);
    };
    const handleCompanyChange = (e)=>{
        setCompany(e.target.value);
        schedule("basic", saveBasicInfo);
    };
    // Flush on blur (immediate save when user leaves field)
    const handleBlurFlush = ()=>{
        flush("basic");
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-32",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                lineNumber: 162,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
            lineNumber: 161,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 177,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                            lineNumber: 171,
                            columnNumber: 11
                        }, this),
                        "Basic Information"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                    lineNumber: 170,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                lineNumber: 169,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                        children: "First Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 190,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        id: "contact-first-name",
                                        name: "contact-first-name",
                                        value: firstName,
                                        onChange: handleFirstNameChange,
                                        onBlur: handleBlurFlush,
                                        placeholder: "First Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 193,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 189,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "block text-sm font-medium text-theme-darker mb-2",
                                        children: "Last Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 203,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        id: "contact-last-name",
                                        name: "contact-last-name",
                                        value: lastName,
                                        onChange: handleLastNameChange,
                                        onBlur: handleBlurFlush,
                                        placeholder: "Last Name"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                        lineNumber: 206,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 202,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 188,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Company"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 217,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "contact-company",
                                name: "contact-company",
                                value: company,
                                onChange: handleCompanyChange,
                                onBlur: handleBlurFlush,
                                placeholder: "Company"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Email"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 230,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                type: "email",
                                id: "contact-email",
                                name: "contact-email",
                                disabled: true,
                                className: "bg-theme-lighter text-[#8d8a85] cursor-not-allowed",
                                value: contact.primaryEmail
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                                lineNumber: 233,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                        lineNumber: 229,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
                lineNumber: 187,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx",
        lineNumber: 168,
        columnNumber: 5
    }, this);
}
_s(BasicInfoCard, "iGxMIUuIgZ0s20TH2dVdSQcJE4Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"]
    ];
});
_c = BasicInfoCard;
var _c;
__turbopack_context__.k.register(_c, "BasicInfoCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/InfoPopover.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>InfoPopover
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function InfoPopover({ content }) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [positionRight, setPositionRight] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const buttonRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const popoverRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "InfoPopover.useEffect": ()=>{
            if (!isOpen || !buttonRef.current || !popoverRef.current) return;
            const checkPosition = {
                "InfoPopover.useEffect.checkPosition": ()=>{
                    const buttonRect = buttonRef.current.getBoundingClientRect();
                    const popoverWidth = 256; // w-64 = 16rem = 256px
                    const spaceOnRight = window.innerWidth - buttonRect.right;
                    const spaceOnLeft = buttonRect.left;
                    // If there's not enough space on the right (less than popover width + some padding)
                    // and there's more space on the left, position to the right
                    if (spaceOnRight < popoverWidth + 16 && spaceOnLeft > spaceOnRight) {
                        setPositionRight(true);
                    } else {
                        setPositionRight(false);
                    }
                }
            }["InfoPopover.useEffect.checkPosition"];
            checkPosition();
            window.addEventListener("resize", checkPosition);
            window.addEventListener("scroll", checkPosition, true);
            return ({
                "InfoPopover.useEffect": ()=>{
                    window.removeEventListener("resize", checkPosition);
                    window.removeEventListener("scroll", checkPosition, true);
                }
            })["InfoPopover.useEffect"];
        }
    }["InfoPopover.useEffect"], [
        isOpen
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "relative inline-block",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                ref: buttonRef,
                type: "button",
                onMouseEnter: ()=>setIsOpen(true),
                onMouseLeave: ()=>setIsOpen(false),
                onClick: ()=>setIsOpen(!isOpen),
                className: "inline-flex items-center justify-center w-5 h-5 rounded-full bg-card-highlight-light border border-gray-200 text-theme-darkest hover:bg-theme-medium transition-colors",
                "aria-label": "More information",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                    className: "text-xs font-bold leading-none",
                    children: "i"
                }, void 0, false, {
                    fileName: "[project]/components/InfoPopover.tsx",
                    lineNumber: 54,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/components/InfoPopover.tsx",
                lineNumber: 45,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: popoverRef,
                className: `absolute bottom-full mb-2 w-64 p-3 bg-card-highlight-light border border-gray-200 text-foreground text-[14px] rounded-sm shadow-xl z-50 ${positionRight ? "right-0" : "left-0"}`,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "leading-relaxed lowercase",
                        children: content
                    }, void 0, false, {
                        fileName: "[project]/components/InfoPopover.tsx",
                        lineNumber: 63,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `absolute top-full w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-white ${positionRight ? "right-4" : "left-4"}`
                    }, void 0, false, {
                        fileName: "[project]/components/InfoPopover.tsx",
                        lineNumber: 64,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: `absolute top-full -mt-px w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-gray-200 ${positionRight ? "right-4" : "left-4"}`
                    }, void 0, false, {
                        fileName: "[project]/components/InfoPopover.tsx",
                        lineNumber: 69,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/components/InfoPopover.tsx",
                lineNumber: 57,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/InfoPopover.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_s(InfoPopover, "oLKBiRZdtEa2yMMBfmC8qGKMsLM=");
_c = InfoPopover;
var _c;
__turbopack_context__.k.register(_c, "InfoPopover");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/SegmentSelect.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SegmentSelect
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
function SegmentSelect({ value, onChange, existingSegments, placeholder = "Enter or select segment...", className = "" }) {
    _s();
    const [inputValue, setInputValue] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(value || "");
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [highlightedIndex, setHighlightedIndex] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(-1);
    const inputRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const isUserTypingRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(false);
    const previousValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(value);
    const inputValueRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(inputValue);
    // Keep ref in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SegmentSelect.useEffect": ()=>{
            inputValueRef.current = inputValue;
        }
    }["SegmentSelect.useEffect"], [
        inputValue
    ]);
    // Function to sync input value from prop changes (called from effect)
    // This follows React's recommendation to call a function instead of setState directly
    const syncInputFromProp = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "SegmentSelect.useCallback[syncInputFromProp]": (newValue)=>{
            const valueToSet = newValue || "";
            // Use ref to check current value without causing re-renders
            if (inputValueRef.current !== valueToSet) {
                setInputValue(valueToSet);
            }
        }
    }["SegmentSelect.useCallback[syncInputFromProp]"], []);
    // Update input value when prop value changes (only if changed externally, not from user input)
    // This is necessary to sync controlled input state with prop changes while allowing user typing
    // We defer the state update by calling the sync function asynchronously to avoid cascading renders
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "SegmentSelect.useEffect": ()=>{
            if (previousValueRef.current !== value && !isUserTypingRef.current) {
                previousValueRef.current = value;
                // Defer the function call to avoid synchronous setState in effect
                queueMicrotask({
                    "SegmentSelect.useEffect": ()=>{
                        syncInputFromProp(value);
                    }
                }["SegmentSelect.useEffect"]);
            }
            // Reset typing flag after a short delay
            if (isUserTypingRef.current) {
                const timer = setTimeout({
                    "SegmentSelect.useEffect.timer": ()=>{
                        isUserTypingRef.current = false;
                    }
                }["SegmentSelect.useEffect.timer"], 100);
                return ({
                    "SegmentSelect.useEffect": ()=>clearTimeout(timer)
                })["SegmentSelect.useEffect"];
            }
        }
    }["SegmentSelect.useEffect"], [
        value,
        syncInputFromProp
    ]);
    // Filter segments based on input
    const filteredSegments = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SegmentSelect.useMemo[filteredSegments]": ()=>{
            if (!inputValue.trim()) {
                return existingSegments;
            }
            const searchLower = inputValue.toLowerCase();
            return existingSegments.filter({
                "SegmentSelect.useMemo[filteredSegments]": (segment)=>segment.toLowerCase().includes(searchLower)
            }["SegmentSelect.useMemo[filteredSegments]"]);
        }
    }["SegmentSelect.useMemo[filteredSegments]"], [
        inputValue,
        existingSegments
    ]);
    // Check if current input matches an existing segment
    const isExistingSegment = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "SegmentSelect.useMemo[isExistingSegment]": ()=>{
            return existingSegments.includes(inputValue.trim());
        }
    }["SegmentSelect.useMemo[isExistingSegment]"], [
        inputValue,
        existingSegments
    ]);
    const handleInputChange = (e)=>{
        const newValue = e.target.value;
        isUserTypingRef.current = true;
        setInputValue(newValue);
        setHighlightedIndex(-1);
        setIsOpen(true);
        // Update parent immediately so user can type freely
        onChange(newValue.trim() || null);
    };
    const handleInputFocus = ()=>{
        setIsOpen(true);
    };
    const handleInputBlur = (e)=>{
        // Check if the newly focused element is within the dropdown
        const relatedTarget = e.relatedTarget;
        if (dropdownRef.current?.contains(relatedTarget)) {
            // User is clicking on dropdown item, don't close
            return;
        }
        // Delay closing to allow clicking on dropdown items
        setTimeout(()=>{
            if (!dropdownRef.current?.contains(document.activeElement)) {
                setIsOpen(false);
                setHighlightedIndex(-1);
                // If input doesn't match existing segment, keep it (allow new segments)
                // If input is empty, clear it
                if (!inputValue.trim()) {
                    onChange(null);
                }
            }
        }, 150);
    };
    const handleSelectSegment = (segment, e)=>{
        // Prevent blur from interfering with selection
        e?.preventDefault();
        e?.stopPropagation();
        setInputValue(segment);
        onChange(segment);
        setIsOpen(false);
        setHighlightedIndex(-1);
        // Use setTimeout to ensure the selection happens before blur
        setTimeout(()=>{
            inputRef.current?.blur();
        }, 0);
    };
    const handleClear = ()=>{
        setInputValue("");
        onChange(null);
        setIsOpen(false);
        inputRef.current?.focus();
    };
    const handleKeyDown = (e)=>{
        if (!isOpen && (e.key === "ArrowDown" || e.key === "ArrowUp")) {
            setIsOpen(true);
            return;
        }
        if (e.key === "ArrowDown") {
            e.preventDefault();
            setHighlightedIndex((prev)=>prev < filteredSegments.length - 1 ? prev + 1 : prev);
        } else if (e.key === "ArrowUp") {
            e.preventDefault();
            setHighlightedIndex((prev)=>prev > 0 ? prev - 1 : -1);
        } else if (e.key === "Enter" && highlightedIndex >= 0) {
            e.preventDefault();
            handleSelectSegment(filteredSegments[highlightedIndex]);
        } else if (e.key === "Escape") {
            setIsOpen(false);
            setHighlightedIndex(-1);
            inputRef.current?.blur();
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `relative ${className}`,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                        ref: inputRef,
                        type: "text",
                        value: inputValue,
                        onChange: handleInputChange,
                        onFocus: handleInputFocus,
                        onBlur: handleInputBlur,
                        onKeyDown: handleKeyDown,
                        placeholder: placeholder,
                        "data-no-autofocus": true,
                        className: "w-full px-4 py-2 border border-theme-darker rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 pr-10 text-foreground placeholder:text-gray-400"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        type: "button",
                        onClick: handleClear,
                        className: "absolute right-2 top-1/2 -translate-y-1/2 text-gray-400 hover:text-theme-dark transition-colors",
                        tabIndex: -1,
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M6 18L18 6M6 6l12 12"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 192,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                            lineNumber: 186,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 180,
                        columnNumber: 11
                    }, this),
                    !inputValue && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "absolute right-3 top-1/2 -translate-y-1/2 pointer-events-none",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M19 9l-7 7-7-7"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 209,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                            lineNumber: 203,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 202,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this),
            isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "fixed inset-0 z-10",
                        onClick: ()=>setIsOpen(false)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 223,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        ref: dropdownRef,
                        className: "absolute z-20 w-full mt-1 bg-selected-background border border-gray-200 rounded-sm shadow-lg max-h-60 overflow-y-auto",
                        children: filteredSegments.length > 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: [
                                filteredSegments.map((segment, index)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onMouseDown: (e)=>{
                                            e.preventDefault(); // Prevent input blur
                                            handleSelectSegment(segment, e);
                                        },
                                        className: `w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-selected-active transition-colors ${index === highlightedIndex ? "bg-selected-active text-selected-foreground" : ""} ${segment === value ? "bg-selected-active text-selected-foreground font-bold" : ""}`,
                                        children: segment
                                    }, segment, false, {
                                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                        lineNumber: 234,
                                        columnNumber: 19
                                    }, this)),
                                !isExistingSegment && inputValue.trim() && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "border-t border-gray-200",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        type: "button",
                                        onMouseDown: (e)=>{
                                            e.preventDefault(); // Prevent input blur
                                            handleSelectSegment(inputValue.trim(), e);
                                        },
                                        className: "w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-selected-active transition-colors",
                                        children: [
                                            '+ Create "',
                                            inputValue.trim(),
                                            '"'
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                        lineNumber: 252,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                    lineNumber: 251,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                            children: inputValue.trim() ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                type: "button",
                                onMouseDown: (e)=>{
                                    e.preventDefault(); // Prevent input blur
                                    handleSelectSegment(inputValue.trim(), e);
                                },
                                className: "w-full text-left px-4 py-2 text-sm text-foreground rounded-sm hover:bg-theme-darker hover:text-theme-lightest transition-colors",
                                children: [
                                    '+ Create new segment: "',
                                    inputValue.trim(),
                                    '"'
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 268,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "px-4 py-2 text-sm text-gray-500",
                                children: "No segments available"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                                lineNumber: 279,
                                columnNumber: 19
                            }, this)
                        }, void 0, false)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
                        lineNumber: 227,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/SegmentSelect.tsx",
        lineNumber: 165,
        columnNumber: 5
    }, this);
}
_s(SegmentSelect, "mXhLx9Yc2+h+4KO3C+zJadMZEPU=");
_c = SegmentSelect;
var _c;
__turbopack_context__.k.register(_c, "SegmentSelect");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TagsClassificationCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InfoPopover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$SegmentSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/SegmentSelect.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function TagsClassificationCard({ contactId, userId, uniqueSegments = [] }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { schedule, flush } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"])();
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastSavedValuesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [tagsInput, setTagsInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(""); // Raw input string for free typing
    const [tags, setTags] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])([]); // Parsed tags array
    const [segment, setSegment] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [leadSource, setLeadSource] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Use refs to store current values so save function always reads latest state
    const tagsRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(tags);
    const segmentRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(segment);
    const leadSourceRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(leadSource);
    // Keep refs in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagsClassificationCard.useEffect": ()=>{
            tagsRef.current = tags;
        }
    }["TagsClassificationCard.useEffect"], [
        tags
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagsClassificationCard.useEffect": ()=>{
            segmentRef.current = segment;
        }
    }["TagsClassificationCard.useEffect"], [
        segment
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagsClassificationCard.useEffect": ()=>{
            leadSourceRef.current = leadSource;
        }
    }["TagsClassificationCard.useEffect"], [
        leadSource
    ]);
    // Reset form state only when contactId changes (switching to a different contact)
    // Don't reset when contact data updates from our own save
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TagsClassificationCard.useEffect": ()=>{
            if (!contact) return;
            // Only reset if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                lastSavedValuesRef.current = null; // Clear saved values when switching contacts
                // Batch state updates to avoid cascading renders
                const contactTags = contact.tags ?? [];
                setTags(contactTags);
                setTagsInput(contactTags.join(", ")); // Initialize input with tags joined by comma
                setSegment(contact.segment ?? null);
                setLeadSource(contact.leadSource ?? "");
                return;
            }
            // If contact data updated but it matches what we just saved, don't reset
            if (lastSavedValuesRef.current) {
                const saved = lastSavedValuesRef.current;
                const contactTags = contact.tags ?? [];
                const contactMatchesSaved = JSON.stringify(contactTags.sort()) === JSON.stringify(saved.tags.sort()) && (contact.segment ?? null) === saved.segment && (contact.leadSource ?? "") === saved.leadSource;
                if (contactMatchesSaved) {
                    // This update came from our save, don't reset form
                    return;
                }
            }
            // Only update if form values match the old contact values (user hasn't made changes)
            const formMatchesOldContact = JSON.stringify(tags.sort()) === JSON.stringify((contact.tags ?? []).sort()) && segment === (contact.segment ?? null) && leadSource === (contact.leadSource ?? "");
            if (formMatchesOldContact) {
                // Form hasn't been edited, safe to update from contact
                const contactTags = contact.tags ?? [];
                setTags(contactTags);
                setTagsInput(contactTags.join(", "));
                setSegment(contact.segment ?? null);
                setLeadSource(contact.leadSource ?? "");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["TagsClassificationCard.useEffect"], [
        contact?.contactId,
        contact?.tags,
        contact?.segment,
        contact?.leadSource
    ]);
    // Save function for autosave - reads from refs to always get latest values
    const saveTags = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "TagsClassificationCard.useMemo[saveTags]": ()=>{
            return ({
                "TagsClassificationCard.useMemo[saveTags]": async ()=>{
                    if (!contact) return;
                    // Read current form values from refs (always latest, even if scheduled before state update)
                    const currentTags = tagsRef.current.length > 0 ? tagsRef.current : [];
                    const currentSegment = segmentRef.current || null;
                    const currentLeadSource = leadSourceRef.current || null;
                    return new Promise({
                        "TagsClassificationCard.useMemo[saveTags]": (resolve, reject)=>{
                            updateMutation.mutate({
                                contactId,
                                updates: {
                                    tags: currentTags,
                                    segment: currentSegment,
                                    leadSource: currentLeadSource
                                }
                            }, {
                                onSuccess: {
                                    "TagsClassificationCard.useMemo[saveTags]": ()=>{
                                        // Remember what we saved so we don't reset form when contact refetches
                                        lastSavedValuesRef.current = {
                                            tags: currentTags,
                                            segment: currentSegment,
                                            leadSource: currentLeadSource ?? ""
                                        };
                                        resolve();
                                    }
                                }["TagsClassificationCard.useMemo[saveTags]"],
                                onError: {
                                    "TagsClassificationCard.useMemo[saveTags]": (error)=>{
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                                            context: "Saving tags & classification in TagsClassificationCard",
                                            tags: {
                                                component: "TagsClassificationCard",
                                                contactId
                                            }
                                        });
                                        reject(error);
                                    }
                                }["TagsClassificationCard.useMemo[saveTags]"]
                            });
                        }
                    }["TagsClassificationCard.useMemo[saveTags]"]);
                }
            })["TagsClassificationCard.useMemo[saveTags]"];
        }
    }["TagsClassificationCard.useMemo[saveTags]"], [
        contact,
        contactId,
        updateMutation
    ]);
    // Parse tags input string into tags array
    const parseTags = (input)=>{
        return input.split(",").map((s)=>s.trim()).filter(Boolean);
    };
    const handleTagsInputChange = (e)=>{
        const value = e.target.value;
        setTagsInput(value); // Allow free typing
        const parsedTags = parseTags(value);
        setTags(parsedTags); // Update tags array for comparison
        schedule("tags", saveTags);
    };
    const handleTagsBlur = ()=>{
        // Normalize the input on blur (remove extra spaces, etc.)
        const normalized = tags.join(", ");
        setTagsInput(normalized);
        flush("tags");
    };
    const handleSegmentChange = (value)=>{
        setSegment(value);
        schedule("tags", saveTags);
    };
    const handleLeadSourceChange = (e)=>{
        setLeadSource(e.target.value);
        schedule("tags", saveTags);
    };
    const handleLeadSourceBlur = ()=>{
        flush("tags");
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-48",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 186,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
            lineNumber: 185,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M7 7h.01M7 3h5c.512 0 1.024.195 1.414.586l7 7a2 2 0 010 2.828l-7 7a2 2 0 01-2.828 0l-7-7A1.994 1.994 0 013 12V7a4 4 0 014-4z"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 201,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                            lineNumber: 195,
                            columnNumber: 11
                        }, this),
                        "Tags & Classification"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                    lineNumber: 194,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 193,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-theme-dark mb-4",
                children: "Organize and categorize your contacts using tags, segments, and lead sources to better track relationships and tailor your communication strategies."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 211,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                className: "flex items-center gap-1.5 text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Tags",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        content: "Tags are labels you can assign to contacts to organize and categorize them. Use tags to group contacts by characteristics like industry, role, project, or any custom classification that helps you manage your relationships."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 218,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 216,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "contact-tags",
                                name: "contact-tags",
                                value: tagsInput,
                                onChange: handleTagsInputChange,
                                onBlur: handleTagsBlur,
                                placeholder: "tag1, tag2, tag3"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "mt-2 text-xs text-theme-dark",
                                children: 'Enter tags separated by commas. Spaces within tags are allowed (e.g., "School of Hard Knocks, Referral, VIP").'
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 228,
                                columnNumber: 11
                            }, this),
                            tags.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2 mt-3",
                                children: tags.map((tag, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "inline-flex items-center gap-1 px-3 py-1 bg-blue-50 text-blue-700 rounded-full text-sm font-medium",
                                        children: tag
                                    }, idx, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 234,
                                        columnNumber: 17
                                    }, this))
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 232,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                        lineNumber: 215,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "grid grid-cols-2 gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-1.5 text-sm font-medium text-theme-darker mb-2",
                                        children: [
                                            "Segment",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                content: "A segment categorizes contacts into distinct groups based on shared characteristics such as company size, industry, customer type, or market segment. This helps you tailor your communication and sales strategies to different groups."
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                                lineNumber: 248,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 246,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$SegmentSelect$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        value: segment,
                                        onChange: handleSegmentChange,
                                        existingSegments: uniqueSegments,
                                        placeholder: "Enter or select segment..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 250,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 245,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                        className: "flex items-center gap-1.5 text-sm font-medium text-theme-darker mb-2",
                                        children: [
                                            "Lead Source",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                                content: "The original source or channel where this contact was first acquired. This helps track which marketing channels or referral sources are most effective for your business."
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                                lineNumber: 260,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 258,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        type: "text",
                                        id: "contact-lead-source",
                                        name: "contact-lead-source",
                                        value: leadSource,
                                        onChange: handleLeadSourceChange,
                                        onBlur: handleLeadSourceBlur,
                                        placeholder: "Enter lead source..."
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                        lineNumber: 262,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                                lineNumber: 257,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                        lineNumber: 244,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
                lineNumber: 214,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx",
        lineNumber: 192,
        columnNumber: 5
    }, this);
}
_s(TagsClassificationCard, "Idt9R4OWbJau2J5kNAme8g03/5Y=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"]
    ];
});
_c = TagsClassificationCard;
var _c;
__turbopack_context__.k.register(_c, "TagsClassificationCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/util/contact-utils.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "formatContactDate",
    ()=>formatContactDate,
    "getDisplayName",
    ()=>getDisplayName,
    "getInitials",
    ()=>getInitials
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [app-client] (ecmascript)");
;
function getInitials(contact) {
    if (contact.firstName && contact.lastName) {
        return `${contact.firstName[0]}${contact.lastName[0]}`.toUpperCase();
    }
    if (contact.firstName) {
        return contact.firstName[0].toUpperCase();
    }
    if (contact.primaryEmail) {
        return contact.primaryEmail[0].toUpperCase();
    }
    return "?";
}
function getDisplayName(contact) {
    if (contact.firstName || contact.lastName) {
        return `${contact.firstName || ""} ${contact.lastName || ""}`.trim();
    }
    if (contact.company) {
        return contact.company;
    }
    return contact.primaryEmail;
}
function formatContactDate(date, options) {
    if (!date) return "N/A";
    let dateObj = null;
    // Handle ISO date strings (from API - timestamps converted to ISO strings)
    if (typeof date === "string") {
        dateObj = new Date(date);
        if (isNaN(dateObj.getTime())) {
            return "N/A";
        }
    } else if (date instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] || typeof date === "object" && date !== null && "toDate" in date) {
        dateObj = date.toDate();
    } else if (typeof date === "object" && date !== null && "seconds" in date && "nanoseconds" in date) {
        const timestamp = date;
        dateObj = new Date(timestamp.seconds * 1000 + timestamp.nanoseconds / 1000000);
    } else if (typeof date === "object" && date !== null && "_seconds" in date && "_nanoseconds" in date) {
        const timestamp = date;
        dateObj = new Date(timestamp._seconds * 1000 + timestamp._nanoseconds / 1000000);
    } else if (date instanceof Date) {
        dateObj = date;
    } else if (typeof date === "number") {
        dateObj = new Date(date);
        if (isNaN(dateObj.getTime())) {
            return "N/A";
        }
    }
    if (!dateObj) return "N/A";
    // Relative time option (handles both past and future dates)
    if (options?.relative) {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        const dateToCompare = new Date(dateObj.getFullYear(), dateObj.getMonth(), dateObj.getDate());
        // Calculate difference in calendar days (positive = past, negative = future)
        const diffMs = today.getTime() - dateToCompare.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        // Handle future dates (negative diffDays)
        if (diffDays < 0) {
            const absDays = Math.abs(diffDays);
            if (absDays === 0) {
                return "Today";
            } else if (absDays === 1) {
                return "Tomorrow";
            } else if (absDays < 7) {
                return `in ${absDays} days`;
            } else if (absDays < 30) {
                const weeks = Math.floor(absDays / 7);
                return `in ${weeks} ${weeks === 1 ? "week" : "weeks"}`;
            } else if (absDays < 365) {
                const months = Math.floor(absDays / 30);
                return `in ${months} ${months === 1 ? "month" : "months"}`;
            } else {
                const years = Math.floor(absDays / 365);
                return `in ${years} ${years === 1 ? "year" : "years"}`;
            }
        }
        // Handle past dates (positive diffDays)
        if (diffDays === 0) {
            return "Today";
        } else if (diffDays === 1) {
            return "Yesterday";
        } else if (diffDays < 7) {
            return `${diffDays} days ago`;
        } else if (diffDays < 30) {
            const weeks = Math.floor(diffDays / 7);
            return `${weeks} ${weeks === 1 ? "week" : "weeks"} ago`;
        } else if (diffDays < 365) {
            const months = Math.floor(diffDays / 30);
            return `${months} ${months === 1 ? "month" : "months"} ago`;
        } else {
            const years = Math.floor(diffDays / 365);
            return `${years} ${years === 1 ? "year" : "years"} ago`;
        }
    }
    // Standard formatting
    if (options?.includeTime) {
        return dateObj.toLocaleString("en-US", {
            year: "numeric",
            month: "long",
            day: "numeric",
            hour: "numeric",
            minute: "2-digit"
        });
    }
    return dateObj.toLocaleDateString("en-US", {
        year: "numeric",
        month: "long",
        day: "numeric"
    });
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/ActionItemCheckbox.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemCheckbox
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
"use client";
;
function ActionItemCheckbox({ checked, onChange, disabled = false, label }) {
    const defaultLabel = checked ? "Complete" : "Mark Complete";
    const displayLabel = label ?? defaultLabel;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
        className: "flex items-center gap-2 cursor-pointer",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "checkbox",
                checked: checked,
                onChange: onChange,
                disabled: disabled,
                onClick: (e)=>e.stopPropagation(),
                className: "w-4 h-4 text-blue-600 border-gray-300 rounded focus:ring-blue-500 disabled:opacity-50 disabled:cursor-not-allowed",
                title: displayLabel,
                "aria-label": displayLabel
            }, void 0, false, {
                fileName: "[project]/components/ActionItemCheckbox.tsx",
                lineNumber: 21,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: "text-sm text-theme-darker select-none",
                children: displayLabel
            }, void 0, false, {
                fileName: "[project]/components/ActionItemCheckbox.tsx",
                lineNumber: 31,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/ActionItemCheckbox.tsx",
        lineNumber: 20,
        columnNumber: 5
    }, this);
}
_c = ActionItemCheckbox;
var _c;
__turbopack_context__.k.register(_c, "ActionItemCheckbox");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Textarea.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Textarea
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
;
function Textarea({ className = "", ...props }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("textarea", {
        ...props,
        className: `w-full px-4 py-3 border text-foreground placeholder:text-foreground border-gray-300 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200 resize-none ${className}`
    }, void 0, false, {
        fileName: "[project]/components/Textarea.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
_c = Textarea;
var _c;
__turbopack_context__.k.register(_c, "Textarea");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ActionItemCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ActionItemCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ActionItemCheckbox.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function ActionItemCard({ actionItem, contactId, contactName, contactEmail, contactFirstName, contactLastName, onComplete, onDelete, onEdit, disabled = false, compact = false, isOverdue: preComputedIsOverdue, displayName: preComputedDisplayName, initials: preComputedInitials, contactLoading = false }) {
    _s();
    // Use pre-computed values if provided, otherwise compute on client (for backward compatibility)
    const isOverdue = preComputedIsOverdue !== undefined ? preComputedIsOverdue : actionItem.status === "pending" && actionItem.dueDate ? (()=>{
        const dueDate = actionItem.dueDate;
        if (!dueDate) return false;
        if (dueDate instanceof Date) return dueDate < new Date();
        if (typeof dueDate === "string") return new Date(dueDate) < new Date();
        if (typeof dueDate === "object" && "toDate" in dueDate) {
            return dueDate.toDate() < new Date();
        }
        return false;
    })() : false;
    const [isEditing, setIsEditing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [editText, setEditText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(actionItem.text);
    const [editDueDate, setEditDueDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(actionItem.dueDate ? typeof actionItem.dueDate === "string" ? actionItem.dueDate.split("T")[0] : actionItem.dueDate instanceof Date ? actionItem.dueDate.toISOString().split("T")[0] : "" : "");
    // Use pre-computed values if provided, otherwise compute on client
    const displayName = preComputedDisplayName !== undefined ? preComputedDisplayName : contactName || (()=>{
        const contactForUtils = {
            contactId: contactId,
            firstName: contactFirstName,
            lastName: contactLastName,
            primaryEmail: contactEmail || "",
            createdAt: new Date(),
            updatedAt: new Date()
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contactForUtils);
    })();
    const initials = preComputedInitials !== undefined ? preComputedInitials : (()=>{
        const contactForUtils = {
            contactId: contactId,
            firstName: contactFirstName,
            lastName: contactLastName,
            primaryEmail: contactEmail || "",
            createdAt: new Date(),
            updatedAt: new Date()
        };
        return (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contactForUtils);
    })();
    const email = contactEmail || "";
    const getVariantStyles = ()=>{
        if (actionItem.status === "completed") {
            return "bg-card-highlight-light border border-gray-200";
        }
        if (isOverdue) {
            return "bg-card-overdue border border-card-overdue-dark";
        }
        return "bg-transparent border border-gray-200";
    };
    const getAvatarStyles = ()=>{
        if (actionItem.status === "completed") {
            return "bg-gradient-to-br from-gray-400 to-gray-500";
        }
        if (isOverdue) {
            return "bg-gradient-to-br from-red-600 to-red-700";
        }
        return "bg-gradient-to-br from-blue-500 to-purple-600";
    };
    const handleSaveEdit = ()=>{
        onEdit(editText, editDueDate || null);
        setIsEditing(false);
    };
    const handleCancelEdit = ()=>{
        setEditText(actionItem.text);
        setEditDueDate(actionItem.dueDate ? typeof actionItem.dueDate === "string" ? actionItem.dueDate.split("T")[0] : "" : "");
        setIsEditing(false);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: `rounded-sm p-3 sm:p-4 transition-all duration-200 min-w-0 overflow-hidden ${getVariantStyles()}`,
        children: isEditing ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-3",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    id: `action-item-edit-text-${actionItem.actionItemId}`,
                    name: `action-item-edit-text-${actionItem.actionItemId}`,
                    value: editText,
                    onChange: (e)=>setEditText(e.target.value),
                    className: "px-3 py-2",
                    rows: 2,
                    disabled: disabled
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 155,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    type: "date",
                    value: editDueDate,
                    onChange: (e)=>setEditDueDate(e.target.value),
                    className: "px-3 py-2",
                    disabled: disabled
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 164,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: handleSaveEdit,
                            disabled: disabled || !editText.trim(),
                            variant: "primary",
                            size: "sm",
                            children: "Save"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 172,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: handleCancelEdit,
                            disabled: disabled,
                            variant: "outline",
                            size: "sm",
                            children: "Cancel"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 180,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 171,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
            lineNumber: 154,
            columnNumber: 9
        }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex flex-col gap-3 min-w-0 overflow-hidden",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ActionItemCheckbox$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            checked: actionItem.status === "completed",
                            onChange: onComplete,
                            disabled: disabled
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 195,
                            columnNumber: 13
                        }, this),
                        actionItem.status === "pending" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-1 shrink-0 ml-auto",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>setIsEditing(true),
                                    disabled: disabled,
                                    variant: "outline",
                                    size: "sm",
                                    className: "p-1 text-gray-400 hover:text-blue-600",
                                    title: "Edit",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 218,
                                            columnNumber: 23
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 212,
                                        columnNumber: 21
                                    }, void 0),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "sr-only",
                                        children: "Edit"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 227,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 204,
                                    columnNumber: 17
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: onDelete,
                                    disabled: disabled,
                                    variant: "outline",
                                    size: "sm",
                                    className: "p-1 text-gray-400 hover:text-red-600",
                                    title: "Delete",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 243,
                                            columnNumber: 23
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 237,
                                        columnNumber: 21
                                    }, void 0),
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "sr-only",
                                        children: "Delete"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 252,
                                        columnNumber: 19
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 229,
                                    columnNumber: 17
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 203,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 193,
                    columnNumber: 11
                }, this),
                !compact && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    href: `/contacts/${contactId}`,
                    className: "flex items-center gap-2 group border border-gray-300 rounded-sm px-3 py-2 hover:border-gray-400 transition-colors",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "shrink-0",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: `w-8 h-8 ${getAvatarStyles()} rounded-full flex items-center justify-center text-white font-semibold text-xs shadow-sm`,
                                children: initials
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                lineNumber: 266,
                                columnNumber: 17
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 265,
                            columnNumber: 15
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex-1 min-w-0",
                            children: contactLoading || displayName === null ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                height: "h-[38px]",
                                width: "w-24"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                lineNumber: 274,
                                columnNumber: 19
                            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: `text-sm font-semibold group-hover:text-theme-darker transition-colors truncate ${actionItem.status === "completed" ? "text-gray-500" : "text-theme-darkest"}`,
                                        children: displayName || ""
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 277,
                                        columnNumber: 21
                                    }, this),
                                    email && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: `text-xs truncate mt-0.5 ${actionItem.status === "completed" ? "text-gray-400" : "text-gray-500"}`,
                                        children: email
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                        lineNumber: 283,
                                        columnNumber: 23
                                    }, this)
                                ]
                            }, void 0, true)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 272,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 260,
                    columnNumber: 13
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "min-w-0",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: `text-sm font-medium wrap-break-word mb-2 ${actionItem.status === "completed" ? "text-gray-500 line-through" : "text-theme-darkest"}`,
                            children: actionItem.text
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 297,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex flex-wrap gap-x-4 gap-y-1",
                            children: [
                                actionItem.status === "pending" && actionItem.dueDate ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: `text-xs flex items-center gap-1 ${isOverdue ? "text-red-600 font-medium" : "text-gray-500"}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-3.5 h-3.5 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                                lineNumber: 319,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 313,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Due: ",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(actionItem.dueDate, {
                                                    relative: true
                                                }),
                                                isOverdue ? " (Overdue)" : null
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 326,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 310,
                                    columnNumber: 19
                                }, this) : null,
                                actionItem.status === "completed" && actionItem.completedAt ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-500 flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-3.5 h-3.5 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                                lineNumber: 340,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 334,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Completed: ",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(actionItem.completedAt, {
                                                    relative: true
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 347,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 333,
                                    columnNumber: 19
                                }, this) : null,
                                actionItem.createdAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-gray-400 flex items-center gap-1",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-3.5 h-3.5 shrink-0",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                                lineNumber: 360,
                                                columnNumber: 23
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 354,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            children: [
                                                "Created: ",
                                                (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(actionItem.createdAt, {
                                                    relative: true
                                                })
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                            lineNumber: 367,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                                    lineNumber: 353,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                            lineNumber: 308,
                            columnNumber: 15
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
                    lineNumber: 296,
                    columnNumber: 11
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
            lineNumber: 191,
            columnNumber: 9
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ActionItemCard.tsx",
        lineNumber: 152,
        columnNumber: 5
    }, this);
}
_s(ActionItemCard, "O8K2FZRfxTS2h5RUyDtwakPWgPk=");
_c = ActionItemCard;
var _c;
__turbopack_context__.k.register(_c, "ActionItemCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/Modal.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>Modal
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react-dom/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
function Modal({ isOpen, onClose, children, title, showBackdrop = true, closeOnBackdropClick = true, maxWidth = "md", className = "" }) {
    _s();
    const maxWidthClasses = {
        sm: "max-w-sm",
        md: "max-w-md",
        lg: "max-w-lg",
        xl: "max-w-xl",
        "2xl": "max-w-2xl",
        "4xl": "max-w-4xl",
        "5xl": "max-w-5xl"
    };
    const modalRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const titleId = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"])();
    const previousActiveElementRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Get all focusable elements within the modal
    const getFocusableElements = ()=>{
        if (!modalRef.current) return [];
        const focusableSelectors = [
            'a[href]',
            'button:not([disabled])',
            'textarea:not([disabled])',
            'input:not([disabled])',
            'select:not([disabled])',
            '[tabindex]:not([tabindex="-1"])'
        ].join(', ');
        return Array.from(modalRef.current.querySelectorAll(focusableSelectors));
    };
    // Focus trap: keep focus within modal
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!isOpen || !modalRef.current) return;
            const handleTabKey = {
                "Modal.useEffect.handleTabKey": (e)=>{
                    if (e.key !== 'Tab') return;
                    const focusableElements = getFocusableElements();
                    if (focusableElements.length === 0) return;
                    const firstElement = focusableElements[0];
                    const lastElement = focusableElements[focusableElements.length - 1];
                    if (e.shiftKey) {
                        // Shift + Tab
                        if (document.activeElement === firstElement) {
                            e.preventDefault();
                            lastElement.focus();
                        }
                    } else {
                        // Tab
                        if (document.activeElement === lastElement) {
                            e.preventDefault();
                            firstElement.focus();
                        }
                    }
                }
            }["Modal.useEffect.handleTabKey"];
            document.addEventListener('keydown', handleTabKey);
            return ({
                "Modal.useEffect": ()=>{
                    document.removeEventListener('keydown', handleTabKey);
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    // Handle escape key
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (!isOpen) return;
            const handleEscape = {
                "Modal.useEffect.handleEscape": (e)=>{
                    if (e.key === "Escape") {
                        onClose();
                    }
                }
            }["Modal.useEffect.handleEscape"];
            document.addEventListener("keydown", handleEscape);
            return ({
                "Modal.useEffect": ()=>{
                    document.removeEventListener("keydown", handleEscape);
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen,
        onClose
    ]);
    // Focus management: move focus to modal on open, return on close
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (isOpen) {
                // Store the previously focused element
                previousActiveElementRef.current = document.activeElement;
                // Move focus to modal after a brief delay to ensure it's rendered
                // Skip inputs that have data-no-autofocus attribute
                setTimeout({
                    "Modal.useEffect": ()=>{
                        const focusableElements = getFocusableElements().filter({
                            "Modal.useEffect.focusableElements": (el)=>!el.hasAttribute('data-no-autofocus')
                        }["Modal.useEffect.focusableElements"]);
                        if (focusableElements.length > 0) {
                            focusableElements[0].focus();
                        } else if (modalRef.current) {
                            modalRef.current.focus();
                        }
                    }
                }["Modal.useEffect"], 0);
            } else {
                // Return focus to the previously focused element
                if (previousActiveElementRef.current) {
                    previousActiveElementRef.current.focus();
                    previousActiveElementRef.current = null;
                }
            }
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    // Prevent body scroll when modal is open
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "Modal.useEffect": ()=>{
            if (isOpen) {
                document.body.style.overflow = "hidden";
            } else {
                document.body.style.overflow = "";
            }
            return ({
                "Modal.useEffect": ()=>{
                    document.body.style.overflow = "";
                }
            })["Modal.useEffect"];
        }
    }["Modal.useEffect"], [
        isOpen
    ]);
    if (!isOpen) return null;
    const handleBackdropClick = (e)=>{
        if (closeOnBackdropClick && e.target === e.currentTarget) {
            onClose();
        }
    };
    const modalContent = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "fixed inset-0 z-200 flex items-center justify-center",
        onClick: handleBackdropClick,
        role: "presentation",
        children: [
            showBackdrop && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "absolute inset-0 bg-black/20 dark:bg-black/40",
                "aria-hidden": "true"
            }, void 0, false, {
                fileName: "[project]/components/Modal.tsx",
                lineNumber: 161,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                ref: modalRef,
                role: "dialog",
                "aria-modal": "true",
                "aria-labelledby": title ? titleId : undefined,
                tabIndex: -1,
                className: `relative rounded-xl p-6 ${maxWidthClasses[maxWidth]} w-full mx-4 z-10 focus:outline-none ${className}`,
                style: {
                    backgroundColor: 'var(--surface-modal)',
                    color: 'var(--foreground)',
                    boxShadow: 'var(--shadow-modal)',
                    border: '1px solid var(--border-subtle)'
                },
                onClick: (e)=>e.stopPropagation(),
                children: [
                    title && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                        id: titleId,
                        className: "text-lg font-semibold text-foreground mb-4",
                        children: title
                    }, void 0, false, {
                        fileName: "[project]/components/Modal.tsx",
                        lineNumber: 179,
                        columnNumber: 11
                    }, this),
                    children
                ]
            }, void 0, true, {
                fileName: "[project]/components/Modal.tsx",
                lineNumber: 163,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/Modal.tsx",
        lineNumber: 155,
        columnNumber: 5
    }, this);
    // Use portal to render modal at document body level
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2d$dom$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["createPortal"])(modalContent, document.body);
}
_s(Modal, "Al4JN5XtBcZZvMhrMN2+23NTASM=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useId"]
    ];
});
_c = Modal;
var _c;
__turbopack_context__.k.register(_c, "Modal");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/hooks/useActionItemMutations.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "useCreateActionItem",
    ()=>useCreateActionItem,
    "useDeleteActionItem",
    ()=>useDeleteActionItem,
    "useUpdateActionItem",
    ()=>useUpdateActionItem
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useMutation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature(), _s2 = __turbopack_context__.k.signature();
"use client";
;
;
function useCreateActionItem() {
    _s();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useCreateActionItem.useMutation": async ({ contactId, text, dueDate })=>{
                const response = await fetch("/api/action-items", {
                    method: "POST",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify({
                        contactId,
                        text,
                        dueDate
                    })
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useCreateActionItem.useMutation": ()=>({})
                    }["useCreateActionItem.useMutation"]);
                    throw new Error(errorData.error || "Failed to create action item");
                }
                return response.json();
            }
        }["useCreateActionItem.useMutation"],
        onSuccess: {
            "useCreateActionItem.useMutation": ()=>{
                // Invalidate and refetch all action items queries (both specific contact and all items)
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
                queryClient.refetchQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
            }
        }["useCreateActionItem.useMutation"],
        onError: {
            "useCreateActionItem.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Creating action item",
                    tags: {
                        component: "useCreateActionItem"
                    }
                });
            }
        }["useCreateActionItem.useMutation"]
    });
}
_s(useCreateActionItem, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useUpdateActionItem() {
    _s1();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useUpdateActionItem.useMutation": async ({ contactId, actionItemId, updates })=>{
                const url = new URL("/api/action-items", window.location.origin);
                url.searchParams.set("contactId", contactId);
                url.searchParams.set("actionItemId", actionItemId);
                const response = await fetch(url.toString(), {
                    method: "PATCH",
                    headers: {
                        "Content-Type": "application/json"
                    },
                    body: JSON.stringify(updates)
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useUpdateActionItem.useMutation": ()=>({})
                    }["useUpdateActionItem.useMutation"]);
                    throw new Error(errorData.error || "Failed to update action item");
                }
                return response.json();
            }
        }["useUpdateActionItem.useMutation"],
        onSuccess: {
            "useUpdateActionItem.useMutation": ()=>{
                // Invalidate and refetch all action items queries (both specific contact and all items)
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
                queryClient.refetchQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
            }
        }["useUpdateActionItem.useMutation"],
        onError: {
            "useUpdateActionItem.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating action item",
                    tags: {
                        component: "useUpdateActionItem"
                    }
                });
            }
        }["useUpdateActionItem.useMutation"]
    });
}
_s1(useUpdateActionItem, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
function useDeleteActionItem() {
    _s2();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"])({
        mutationFn: {
            "useDeleteActionItem.useMutation": async ({ contactId, actionItemId })=>{
                const url = new URL("/api/action-items", window.location.origin);
                url.searchParams.set("contactId", contactId);
                url.searchParams.set("actionItemId", actionItemId);
                const response = await fetch(url.toString(), {
                    method: "DELETE"
                });
                if (!response.ok) {
                    const errorData = await response.json().catch({
                        "useDeleteActionItem.useMutation": ()=>({})
                    }["useDeleteActionItem.useMutation"]);
                    throw new Error(errorData.error || "Failed to delete action item");
                }
                return response.json();
            }
        }["useDeleteActionItem.useMutation"],
        onSuccess: {
            "useDeleteActionItem.useMutation": ()=>{
                // Invalidate and refetch all action items queries (both specific contact and all items)
                queryClient.invalidateQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
                queryClient.refetchQueries({
                    queryKey: [
                        "action-items"
                    ],
                    exact: false
                });
            }
        }["useDeleteActionItem.useMutation"],
        onError: {
            "useDeleteActionItem.useMutation": (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting action item",
                    tags: {
                        component: "useDeleteActionItem"
                    }
                });
            }
        }["useDeleteActionItem.useMutation"]
    });
}
_s2(useDeleteActionItem, "YK0wzM21ECnncaq5SECwU+/SVdQ=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useMutation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMutation"]
    ];
});
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ActionItemsList.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemsList
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ActionItemCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/error-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Input.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItemMutations.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
function ActionItemsList({ userId, contactId, contactEmail, contactFirstName, contactLastName, contactCompany, onActionItemUpdate, initialActionItems, initialContact }) {
    _s();
    const { data: actionItems = [], isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"])(userId, contactId, initialActionItems);
    const createActionItemMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateActionItem"])();
    const updateActionItemMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateActionItem"])();
    const deleteActionItemMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteActionItem"])();
    const [filterStatus, setFilterStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [isAdding, setIsAdding] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [newText, setNewText] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [newDueDate, setNewDueDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [saving, setSaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [updating, setUpdating] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [addError, setAddError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [updateError, setUpdateError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [deleteConfirmItemId, setDeleteConfirmItemId] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const handleAdd = async ()=>{
        if (!newText.trim()) return;
        setSaving(true);
        setAddError(null);
        const textToSave = newText.trim();
        const dueDateToSave = newDueDate;
        setNewText("");
        setNewDueDate("");
        setIsAdding(false);
        try {
            await createActionItemMutation.mutateAsync({
                contactId,
                text: textToSave,
                dueDate: dueDateToSave || null
            });
            setAddError(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Adding action item",
                tags: {
                    component: "ActionItemsList",
                    contactId
                }
            });
            setAddError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            // Restore the form state so user can try again
            setNewText(textToSave);
            setNewDueDate(dueDateToSave);
            setIsAdding(true);
        } finally{
            setSaving(false);
        }
    };
    const handleComplete = async (actionItemId)=>{
        setUpdating(actionItemId);
        setUpdateError(null);
        const currentItem = actionItems.find((item)=>item.actionItemId === actionItemId);
        if (!currentItem) return;
        const newStatus = currentItem.status === "completed" ? "pending" : "completed";
        try {
            await updateActionItemMutation.mutateAsync({
                contactId,
                actionItemId,
                updates: {
                    status: newStatus
                }
            });
            setUpdateError(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Completing action item",
                tags: {
                    component: "ActionItemsList",
                    contactId,
                    actionItemId
                }
            });
            setUpdateError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
        } finally{
            setUpdating(null);
        }
    };
    const handleDeleteClick = (actionItemId)=>{
        setDeleteConfirmItemId(actionItemId);
        setUpdateError(null);
    };
    const handleDeleteConfirm = async ()=>{
        if (!deleteConfirmItemId) return;
        setUpdating(deleteConfirmItemId);
        setUpdateError(null);
        try {
            await deleteActionItemMutation.mutateAsync({
                contactId,
                actionItemId: deleteConfirmItemId
            });
            setUpdateError(null);
            setDeleteConfirmItemId(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Deleting action item",
                tags: {
                    component: "ActionItemsList",
                    contactId
                }
            });
            setUpdateError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
        } finally{
            setUpdating(null);
        }
    };
    const handleEdit = async (actionItemId, text, dueDate)=>{
        setUpdating(actionItemId);
        setUpdateError(null);
        try {
            await updateActionItemMutation.mutateAsync({
                contactId,
                actionItemId,
                updates: {
                    text: text.trim(),
                    dueDate: dueDate || null
                }
            });
            setUpdateError(null);
            onActionItemUpdate?.();
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Updating action item",
                tags: {
                    component: "ActionItemsList",
                    contactId,
                    actionItemId
                }
            });
            setUpdateError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
        } finally{
            setUpdating(null);
        }
    };
    const filteredItems = actionItems.filter((item)=>{
        if (filterStatus === "all") return true;
        return item.status === filterStatus;
    });
    const pendingCount = actionItems.filter((i)=>i.status === "pending").length;
    const completedCount = actionItems.filter((i)=>i.status === "completed").length;
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "text-center py-4",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-500",
                children: "Loading action items..."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                lineNumber: 197,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
            lineNumber: 196,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: deleteConfirmItemId !== null,
                onClose: ()=>{
                    if (!deleteActionItemMutation.isPending) {
                        setDeleteConfirmItemId(null);
                        setUpdateError(null);
                    }
                },
                title: "Delete Action Item",
                closeOnBackdropClick: !deleteActionItemMutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: "Are you sure you want to delete this action item? This action cannot be undone."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 216,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setDeleteConfirmItemId(null);
                                    setUpdateError(null);
                                },
                                disabled: deleteActionItemMutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 220,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleDeleteConfirm,
                                disabled: deleteActionItemMutation.isPending,
                                loading: deleteActionItemMutation.isPending,
                                variant: "danger",
                                size: "sm",
                                error: updateError,
                                children: "Delete"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 231,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 219,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                lineNumber: 205,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4 min-w-0 overflow-hidden",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center justify-between",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                    className: "text-sm font-semibold text-theme-darkest",
                                    children: "Action Items"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                    lineNumber: 248,
                                    columnNumber: 11
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 247,
                                columnNumber: 9
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-wrap gap-2",
                                role: "tablist",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterStatus("all"),
                                        role: "tab",
                                        "aria-selected": filterStatus === "all",
                                        className: `cursor-pointer px-3 py-1.5 text-xs sm:text-sm text-foreground font-medium rounded-sm transition-all duration-200 border border-theme-medium ${filterStatus === "all" ? "bg-theme-light" : "hover:bg-theme-light hover:bg-opacity-10"}`,
                                        children: [
                                            "All",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-1 ${filterStatus === "all" ? "text-theme-dark" : "text-gray-400"}`,
                                                children: [
                                                    "(",
                                                    actionItems.length,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                                lineNumber: 266,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                        lineNumber: 255,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterStatus("pending"),
                                        role: "tab",
                                        "aria-selected": filterStatus === "pending",
                                        className: `cursor-pointer px-3 py-1.5 text-xs sm:text-sm text-foreground font-medium rounded-sm transition-all duration-200 border border-theme-medium ${filterStatus === "pending" ? "bg-theme-light" : "hover:bg-theme-light hover:bg-opacity-10"}`,
                                        children: [
                                            "Pending",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-1 ${filterStatus === "pending" ? "text-theme-dark" : "text-gray-400"}`,
                                                children: [
                                                    "(",
                                                    pendingCount,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                                lineNumber: 283,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                        lineNumber: 272,
                                        columnNumber: 11
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: ()=>setFilterStatus("completed"),
                                        role: "tab",
                                        "aria-selected": filterStatus === "completed",
                                        className: `cursor-pointer px-3 py-1.5 text-xs sm:text-sm text-foreground font-medium rounded-sm transition-all duration-200 border border-theme-medium ${filterStatus === "completed" ? "bg-theme-light" : "hover:bg-theme-light hover:bg-opacity-10"}`,
                                        children: [
                                            "Completed",
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                className: `ml-1 ${filterStatus === "completed" ? "text-theme-dark" : "text-gray-400"}`,
                                                children: [
                                                    "(",
                                                    completedCount,
                                                    ")"
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                                lineNumber: 300,
                                                columnNumber: 13
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                        lineNumber: 289,
                                        columnNumber: 11
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 254,
                                columnNumber: 9
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 246,
                        columnNumber: 7
                    }, this),
                    isAdding ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "p-3 rounded-sm border border-gray-200 space-y-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "action-item-new-text",
                                name: "action-item-new-text",
                                value: newText,
                                onChange: (e)=>setNewText(e.target.value),
                                placeholder: "Enter action item...",
                                className: "px-3 py-2",
                                rows: 2,
                                disabled: saving
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 312,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Input$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                type: "date",
                                value: newDueDate,
                                onChange: (e)=>setNewDueDate(e.target.value),
                                placeholder: "Due date (optional)",
                                className: "px-3 py-2",
                                disabled: saving
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 322,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex flex-col gap-2",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: handleAdd,
                                            disabled: saving || !newText.trim(),
                                            loading: saving,
                                            variant: "secondary",
                                            size: "sm",
                                            error: addError,
                                            children: "Add"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                            lineNumber: 332,
                                            columnNumber: 15
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                            onClick: ()=>{
                                                setIsAdding(false);
                                                setNewText("");
                                                setNewDueDate("");
                                                setAddError(null);
                                            },
                                            disabled: saving,
                                            variant: "outline",
                                            size: "sm",
                                            children: "Cancel"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                            lineNumber: 342,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                    lineNumber: 331,
                                    columnNumber: 13
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 330,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 311,
                        columnNumber: 9
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setIsAdding(true),
                        size: "sm",
                        fullWidth: true,
                        icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-4 h-4",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 4v16m8-8H4"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 370,
                                columnNumber: 15
                            }, void 0)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                            lineNumber: 364,
                            columnNumber: 13
                        }, void 0),
                        children: "Add Action Item"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 359,
                        columnNumber: 9
                    }, this),
                    updateError && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-2",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                            message: updateError,
                            dismissible: true,
                            onDismiss: ()=>setUpdateError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                            lineNumber: 384,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 383,
                        columnNumber: 9
                    }, this),
                    filteredItems.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-medium text-center py-4",
                        children: filterStatus === "all" ? "No action items yet" : `No ${filterStatus} action items`
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 390,
                        columnNumber: 9
                    }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-2 min-w-0 overflow-hidden",
                        children: filteredItems.map((item)=>{
                            // Pre-compute values if we have initialContact, otherwise let ActionItemCard compute
                            const contactForUtils = initialContact || {
                                contactId: contactId,
                                firstName: contactFirstName,
                                lastName: contactLastName,
                                company: contactCompany,
                                primaryEmail: contactEmail || "",
                                createdAt: new Date(),
                                updatedAt: new Date()
                            };
                            const displayName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contactForUtils);
                            const initials = (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contactForUtils);
                            // Compute isOverdue on client (ActionItemCard will also compute if not provided)
                            const isOverdue = item.status === "pending" && item.dueDate ? (()=>{
                                const dueDate = item.dueDate;
                                if (!dueDate) return false;
                                if (dueDate instanceof Date) return dueDate < new Date();
                                if (typeof dueDate === "string") return new Date(dueDate) < new Date();
                                if (typeof dueDate === "object" && "toDate" in dueDate) {
                                    return dueDate.toDate() < new Date();
                                }
                                return false;
                            })() : false;
                            return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                actionItem: item,
                                contactId: contactId,
                                contactEmail: contactEmail,
                                contactFirstName: contactFirstName,
                                contactLastName: contactLastName,
                                onComplete: ()=>handleComplete(item.actionItemId),
                                onDelete: ()=>handleDeleteClick(item.actionItemId),
                                onEdit: (text, dueDate)=>handleEdit(item.actionItemId, text, dueDate ?? null),
                                disabled: updating === item.actionItemId,
                                compact: true,
                                isOverdue: isOverdue,
                                displayName: displayName,
                                initials: initials
                            }, item.actionItemId, false, {
                                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                                lineNumber: 427,
                                columnNumber: 15
                            }, this);
                        })
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                        lineNumber: 396,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ActionItemsList.tsx",
                lineNumber: 244,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ActionItemsList, "MCszRBJ5fP84h8WbhGHvIICl7mw=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCreateActionItem"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateActionItem"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItemMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteActionItem"]
    ];
});
_c = ActionItemsList;
var _c;
__turbopack_context__.k.register(_c, "ActionItemsList");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActionItemsCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ActionItemsList.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ActionItemsCard({ contactId, userId, initialActionItems, initialContact }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const displayContact = contact || initialContact;
    if (!displayContact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-96",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 28,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
            lineNumber: 27,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-theme-darkest mb-2",
                children: "Action Items"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-theme-dark mb-6",
                children: "Track tasks and follow-ups for this contact. Create action items with due dates to stay organized and never miss an important next step in your relationship."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 36,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ActionItemsList$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                userId: userId,
                contactId: contactId,
                contactEmail: displayContact.primaryEmail,
                contactFirstName: displayContact.firstName || undefined,
                contactLastName: displayContact.lastName || undefined,
                contactCompany: displayContact.company || undefined,
                onActionItemUpdate: ()=>{
                // Trigger a refresh if needed
                },
                initialActionItems: initialActionItems,
                initialContact: displayContact
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
                lineNumber: 39,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx",
        lineNumber: 34,
        columnNumber: 5
    }, this);
}
_s(ActionItemsCard, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ActionItemsCard;
var _c;
__turbopack_context__.k.register(_c, "ActionItemsCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/NotesCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NotesCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function NotesCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { schedule, flush } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"])();
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastSavedValuesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [notes, setNotes] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    // Use ref to store current value so save function always reads latest state
    const notesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(notes);
    // Keep ref in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotesCard.useEffect": ()=>{
            notesRef.current = notes;
        }
    }["NotesCard.useEffect"], [
        notes
    ]);
    // Reset form state only when contactId changes (switching to a different contact)
    // Don't reset when contact data updates from our own save
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NotesCard.useEffect": ()=>{
            if (!contact) return;
            // Only reset if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                lastSavedValuesRef.current = null; // Clear saved values when switching contacts
                setNotes(contact.notes ?? "");
                return;
            }
            // If contact data updated but it matches what we just saved, don't reset
            if (lastSavedValuesRef.current !== null) {
                const contactNotes = contact.notes ?? "";
                if (contactNotes === lastSavedValuesRef.current) {
                    // This update came from our save, don't reset form
                    return;
                }
            }
            // Only update if form value matches the old contact value (user hasn't made changes)
            if (notes === (contact.notes ?? "")) {
                // Form hasn't been edited, safe to update from contact
                setNotes(contact.notes ?? "");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["NotesCard.useEffect"], [
        contact?.contactId,
        contact?.notes
    ]);
    // Save function for autosave - reads from ref to always get latest value
    const saveNotes = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NotesCard.useMemo[saveNotes]": ()=>{
            return ({
                "NotesCard.useMemo[saveNotes]": async ()=>{
                    if (!contact) return;
                    // Read current form value from ref (always latest, even if scheduled before state update)
                    const currentNotes = notesRef.current || null;
                    return new Promise({
                        "NotesCard.useMemo[saveNotes]": (resolve, reject)=>{
                            updateMutation.mutate({
                                contactId,
                                updates: {
                                    notes: currentNotes
                                }
                            }, {
                                onSuccess: {
                                    "NotesCard.useMemo[saveNotes]": ()=>{
                                        // Remember what we saved so we don't reset form when contact refetches
                                        lastSavedValuesRef.current = currentNotes ?? "";
                                        resolve();
                                    }
                                }["NotesCard.useMemo[saveNotes]"],
                                onError: {
                                    "NotesCard.useMemo[saveNotes]": (error)=>{
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                                            context: "Saving notes in NotesCard",
                                            tags: {
                                                component: "NotesCard",
                                                contactId
                                            }
                                        });
                                        reject(error);
                                    }
                                }["NotesCard.useMemo[saveNotes]"]
                            });
                        }
                    }["NotesCard.useMemo[saveNotes]"]);
                }
            })["NotesCard.useMemo[saveNotes]"];
        }
    }["NotesCard.useMemo[saveNotes]"], [
        contact,
        contactId,
        updateMutation
    ]);
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-32",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                lineNumber: 104,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
            lineNumber: 103,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                    className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-gray-400",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                                lineNumber: 119,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this),
                        "Notes"
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                lineNumber: 111,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                id: "contact-notes",
                name: "contact-notes",
                rows: 6,
                value: notes,
                onChange: (e)=>{
                    setNotes(e.target.value);
                    schedule("notes", saveNotes);
                },
                onBlur: ()=>flush("notes"),
                placeholder: "Add notes about this contact..."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
                lineNumber: 129,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/NotesCard.tsx",
        lineNumber: 110,
        columnNumber: 5
    }, this);
}
_s(NotesCard, "ByDocAMUULGReCn4MQQ81Qcc4AE=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"]
    ];
});
_c = NotesCard;
var _c;
__turbopack_context__.k.register(_c, "NotesCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/TouchpointStatusActions.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>TouchpointStatusActions
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/error-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
function TouchpointStatusActions({ contactId, contactName, userId, onStatusUpdate, compact = false, currentStatus: fallbackStatus }) {
    _s();
    const { user } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    // Use userId prop if provided, otherwise fall back to user?.uid
    const effectiveUserId = userId || user?.uid || "";
    // Read contact directly from React Query cache for optimistic updates
    // Fall back to prop if contact isn't in cache (e.g., in ContactCard list view)
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(effectiveUserId, contactId);
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [currentStatus, setCurrentStatus] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(contact?.touchpointStatus ?? fallbackStatus ?? null);
    const [showCancelModal, setShowCancelModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showCompleteModal, setShowCompleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [reason, setReason] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const mutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateTouchpointStatus"])(effectiveUserId);
    // Reset state ONLY when contactId changes (switching to a different contact)
    // We don't update when updatedAt changes because that would reset our local state
    // during optimistic updates and refetches. The local state is the source of truth
    // until we switch to a different contact.
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "TouchpointStatusActions.useEffect": ()=>{
            if (!contact && !fallbackStatus) return;
            // Only update if we're switching to a different contact
            if (prevContactIdRef.current !== contactId) {
                prevContactIdRef.current = contactId;
                const statusToUse = contact?.touchpointStatus ?? fallbackStatus ?? null;
                // Batch state updates to avoid cascading renders
                setCurrentStatus(statusToUse);
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["TouchpointStatusActions.useEffect"], [
        contactId,
        fallbackStatus
    ]);
    const handleUpdateStatus = async (status, reason)=>{
        setError(null);
        setCurrentStatus(status);
        mutation.mutate({
            contactId,
            status,
            reason: reason || null
        }, {
            onSuccess: ()=>{
                setShowCancelModal(false);
                setShowCompleteModal(false);
                setReason("");
                onStatusUpdate?.();
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Updating touchpoint status in TouchpointStatusActions",
                    tags: {
                        component: "TouchpointStatusActions",
                        contactId
                    }
                });
                setError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    if (compact) {
        // Compact view for dashboard cards
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-2",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex flex-col sm:flex-row items-stretch sm:items-center gap-2",
                    children: [
                        currentStatus !== "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "secondary",
                            onClick: ()=>setShowCompleteModal(true),
                            disabled: mutation.isPending,
                            className: "flex-1 cursor-pointer sm:flex-none px-3 py-2 sm:px-2 sm:py-1 text-xs disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:gap-1",
                            title: "I've contacted this person",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-3.5 h-3.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M5 13l4 4L19 7"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 114,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 108,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "whitespace-nowrap",
                                    children: "Mark as Contacted"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 121,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 101,
                            columnNumber: 13
                        }, this),
                        currentStatus !== "cancelled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            variant: "outline",
                            onClick: ()=>setShowCancelModal(true),
                            disabled: mutation.isPending,
                            className: "flex-1 sm:flex-none px-3 py-2 sm:px-2 sm:py-1 text-xs font-medium text-foreground border border-theme-medium rounded hover:bg-theme-medium cursor-pointer transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-1.5 sm:gap-1",
                            title: "Skip this touchpoint - no action needed",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-3.5 h-3.5 shrink-0",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M6 18L18 6M6 6l12 12"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 138,
                                        columnNumber: 17
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 132,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "whitespace-nowrap",
                                    children: "Skip Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 145,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 125,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 99,
                    columnNumber: 9
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                    message: error,
                    dismissible: true,
                    onDismiss: ()=>setError(null)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 150,
                    columnNumber: 11
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpen: showCompleteModal,
                    onClose: ()=>{
                        if (!mutation.isPending) {
                            setShowCompleteModal(false);
                            setReason("");
                            setError(null);
                        }
                    },
                    title: "Mark as Contacted",
                    closeOnBackdropClick: !mutation.isPending,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-theme-dark mb-4",
                            children: [
                                "Mark the touchpoint for ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: contactName
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 169,
                                    columnNumber: 37
                                }, this),
                                " as contacted? This indicates you've reached out to them."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 168,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "touchpoint-complete-note-compact",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: [
                                        "Note (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500 font-normal ml-1",
                                            children: "— This will be saved and displayed on the contact page"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                            lineNumber: 174,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 172,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "touchpoint-complete-note-compact",
                                    name: "touchpoint-complete-note-compact",
                                    value: reason,
                                    onChange: (e)=>setReason(e.target.value),
                                    placeholder: "e.g., Discussed proposal, scheduled follow-up, sent quote...",
                                    className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                    rows: 3,
                                    disabled: mutation.isPending,
                                    autoComplete: "off",
                                    "data-form-type": "other",
                                    "data-lpignore": "true",
                                    "data-1p-ignore": "true"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 178,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 171,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                                message: error,
                                dismissible: true,
                                onDismiss: ()=>setError(null)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 195,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 194,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        setShowCompleteModal(false);
                                        setReason("");
                                        setError(null);
                                    },
                                    disabled: mutation.isPending,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Cancel"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 203,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>handleUpdateStatus("completed", reason),
                                    disabled: mutation.isPending,
                                    loading: mutation.isPending,
                                    variant: "secondary",
                                    size: "sm",
                                    children: "Mark as Contacted"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 215,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 202,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 156,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    isOpen: showCancelModal,
                    onClose: ()=>{
                        if (!mutation.isPending) {
                            setShowCancelModal(false);
                            setReason("");
                            setError(null);
                        }
                    },
                    title: "Skip Touchpoint",
                    closeOnBackdropClick: !mutation.isPending,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                            className: "text-sm text-theme-dark mb-4",
                            children: [
                                "Skip the touchpoint for ",
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                    children: contactName
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 239,
                                    columnNumber: 37
                                }, this),
                                "? This indicates no action is needed at this time."
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 238,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                    htmlFor: "touchpoint-skip-reason-compact",
                                    className: "block text-sm font-medium text-theme-darker mb-2",
                                    children: [
                                        "Reason (optional)",
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-xs text-gray-500 font-normal ml-1",
                                            children: "— This will be saved and displayed on the contact page"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                            lineNumber: 244,
                                            columnNumber: 15
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 242,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                    id: "touchpoint-skip-reason-compact",
                                    name: "touchpoint-skip-reason-compact",
                                    value: reason,
                                    onChange: (e)=>setReason(e.target.value),
                                    placeholder: "e.g., Not relevant, contact inactive, wrong contact...",
                                    className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                    rows: 3,
                                    disabled: mutation.isPending,
                                    autoComplete: "off",
                                    "data-form-type": "other",
                                    "data-lpignore": "true",
                                    "data-1p-ignore": "true"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 248,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 241,
                            columnNumber: 11
                        }, this),
                        error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "mb-4",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                                message: error,
                                dismissible: true,
                                onDismiss: ()=>setError(null)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 265,
                                columnNumber: 15
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 264,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-3 justify-end",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>{
                                        setShowCancelModal(false);
                                        setReason("");
                                        setError(null);
                                    },
                                    disabled: mutation.isPending,
                                    size: "sm",
                                    children: "Keep Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 273,
                                    columnNumber: 13
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: ()=>handleUpdateStatus("cancelled", reason),
                                    disabled: mutation.isPending,
                                    loading: mutation.isPending,
                                    variant: "outline",
                                    size: "sm",
                                    children: "Skip Touchpoint"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                    lineNumber: 284,
                                    columnNumber: 13
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 272,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                    lineNumber: 226,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
            lineNumber: 98,
            columnNumber: 7
        }, this);
    }
    // Full view for contact detail page
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center gap-3",
                children: [
                    currentStatus === "completed" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-green-700 bg-green-50 border border-green-200 rounded-full",
                        children: "✓ Contacted"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 304,
                        columnNumber: 11
                    }, this),
                    currentStatus === "cancelled" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-[#eeeeec] bg-theme-medium rounded-full",
                        children: "✕ Skipped"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 309,
                        columnNumber: 11
                    }, this),
                    (!currentStatus || currentStatus === "pending") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "px-3 py-1 text-sm font-medium text-blue-700 bg-blue-50 border border-blue-200 rounded-full",
                        children: "Pending"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 314,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 302,
                columnNumber: 7
            }, this),
            (!currentStatus || currentStatus === "pending") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex gap-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowCompleteModal(true),
                        disabled: mutation.isPending,
                        variant: "secondary",
                        size: "sm",
                        children: "Mark as Contacted"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 322,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: ()=>setShowCancelModal(true),
                        disabled: mutation.isPending,
                        variant: "outline",
                        size: "sm",
                        children: "Skip Touchpoint"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 330,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 321,
                columnNumber: 9
            }, this),
            (currentStatus === "completed" || currentStatus === "cancelled") && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: ()=>handleUpdateStatus(null),
                disabled: mutation.isPending,
                loading: mutation.isPending,
                variant: "outline",
                size: "sm",
                className: "text-blue-700 bg-blue-50 hover:bg-blue-100",
                children: "Restore to Pending"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 342,
                columnNumber: 9
            }, this),
            error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                message: error,
                dismissible: true,
                onDismiss: ()=>setError(null)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 355,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCompleteModal,
                onClose: ()=>{
                    if (!mutation.isPending) {
                        setShowCompleteModal(false);
                        setReason("");
                        setError(null);
                    }
                },
                title: "Mark as Contacted",
                closeOnBackdropClick: !mutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: [
                            "Mark the touchpoint for ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 376,
                                columnNumber: 35
                            }, this),
                            " as contacted? This indicates you've reached out to them."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 375,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "touchpoint-complete-note",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Note (optional)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-500 font-normal ml-1",
                                        children: "— This will be saved and displayed on the contact page"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 381,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 379,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "touchpoint-complete-note",
                                name: "touchpoint-complete-note",
                                value: reason,
                                onChange: (e)=>setReason(e.target.value),
                                placeholder: "e.g., Discussed proposal, scheduled follow-up, sent quote...",
                                className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                rows: 3,
                                disabled: mutation.isPending,
                                autoComplete: "off",
                                "data-form-type": "other",
                                "data-lpignore": "true",
                                "data-1p-ignore": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 385,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 378,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                            message: error,
                            dismissible: true,
                            onDismiss: ()=>setError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 402,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 401,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setShowCompleteModal(false);
                                    setReason("");
                                    setError(null);
                                },
                                disabled: mutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 410,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>handleUpdateStatus("completed", reason),
                                disabled: mutation.isPending,
                                loading: mutation.isPending,
                                variant: "secondary",
                                size: "sm",
                                children: "Mark Completed"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 422,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 409,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 363,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showCancelModal,
                onClose: ()=>{
                    if (!mutation.isPending) {
                        setShowCancelModal(false);
                        setReason("");
                        setError(null);
                    }
                },
                title: "Skip Touchpoint",
                closeOnBackdropClick: !mutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: [
                            "Skip the touchpoint for ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 447,
                                columnNumber: 35
                            }, this),
                            "? This indicates no action is needed at this time."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 446,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "touchpoint-skip-reason",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: [
                                    "Reason (optional)",
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "text-xs text-gray-500 font-normal ml-1",
                                        children: "— This will be saved and displayed on the contact page"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                        lineNumber: 452,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 450,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "touchpoint-skip-reason",
                                name: "touchpoint-skip-reason",
                                value: reason,
                                onChange: (e)=>setReason(e.target.value),
                                placeholder: "e.g., Not relevant, contact inactive, wrong contact...",
                                className: "px-3 py-2 text-theme-darkest disabled:text-theme-dark",
                                rows: 3,
                                disabled: mutation.isPending,
                                autoComplete: "off",
                                "data-form-type": "other",
                                "data-lpignore": "true",
                                "data-1p-ignore": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 456,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 449,
                        columnNumber: 9
                    }, this),
                    error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mb-4",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["ErrorMessage"], {
                            message: error,
                            dismissible: true,
                            onDismiss: ()=>setError(null)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                            lineNumber: 473,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 472,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>{
                                    setShowCancelModal(false);
                                    setReason("");
                                    setError(null);
                                },
                                disabled: mutation.isPending,
                                size: "sm",
                                children: "Keep Touchpoint"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 481,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>handleUpdateStatus("cancelled", reason),
                                disabled: mutation.isPending,
                                loading: mutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Skip Touchpoint"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                                lineNumber: 492,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                        lineNumber: 480,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
                lineNumber: 434,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/TouchpointStatusActions.tsx",
        lineNumber: 301,
        columnNumber: 5
    }, this);
}
_s(TouchpointStatusActions, "1Jh2UPZgvdtuvTUSRXwI+3BTGhA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateTouchpointStatus"]
    ];
});
_c = TouchpointStatusActions;
var _c;
__turbopack_context__.k.register(_c, "TouchpointStatusActions");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/shared/GuardedLink.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>GuardedLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function GuardedLink({ href, children, className, onClick, checkUnsavedChanges, ...linkProps }) {
    _s();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const [isFlushing, setIsFlushing] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleClick = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useCallback"])({
        "GuardedLink.useCallback[handleClick]": async (e)=>{
            // Call custom onClick if provided
            if (onClick) {
                onClick(e);
            }
            // If no check function provided, navigate normally
            if (!checkUnsavedChanges) {
                return; // Let Link handle navigation
            }
            // Prevent default navigation
            e.preventDefault();
            // Show saving state
            setIsFlushing(true);
            try {
                // Check and flush unsaved changes
                const canNavigate = await checkUnsavedChanges();
                if (canNavigate) {
                    // All saves succeeded, navigate
                    router.push(href);
                } else {
                    // Save failed, show error
                    alert("Couldn't save changes. Please try saving manually before navigating.");
                }
            } catch (error) {
                // Error occurred, show user-friendly message
                alert("Couldn't save changes. Please try saving manually before navigating.");
            } finally{
                setIsFlushing(false);
            }
        }
    }["GuardedLink.useCallback[handleClick]"], [
        href,
        checkUnsavedChanges,
        router,
        onClick
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: className,
        onClick: handleClick,
        ...linkProps,
        children: isFlushing ? "Saving…" : children
    }, void 0, false, {
        fileName: "[project]/components/shared/GuardedLink.tsx",
        lineNumber: 67,
        columnNumber: 5
    }, this);
}
_s(GuardedLink, "FxgDVLNmM/sLe31C7hm3JEBdaJo=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = GuardedLink;
var _c;
__turbopack_context__.k.register(_c, "GuardedLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/contacts/ContactGuardedLink.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactGuardedLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/client/app-dir/link.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactAutosaveProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$GuardedLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/shared/GuardedLink.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ContactGuardedLink({ href, children, className, onClick, ...linkProps }) {
    _s();
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContext"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContactAutosaveContext"]);
    // If context is not available, use regular Link
    if (!context) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$app$2d$dir$2f$link$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            href: href,
            className: className,
            onClick: onClick,
            ...linkProps,
            children: children
        }, void 0, false, {
            fileName: "[project]/components/contacts/ContactGuardedLink.tsx",
            lineNumber: 28,
            columnNumber: 7
        }, this);
    }
    const { hasUnsavedChanges, flush, isSaving, pendingCount } = context;
    const checkUnsavedChanges = async ()=>{
        // If no unsaved changes, allow navigation
        if (!hasUnsavedChanges && pendingCount === 0 && !isSaving) {
            return true;
        }
        // Flush all pending saves
        try {
            const success = await flush();
            return success;
        } catch (error) {
            return false;
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$shared$2f$GuardedLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        href: href,
        className: className,
        onClick: onClick,
        checkUnsavedChanges: checkUnsavedChanges,
        ...linkProps,
        children: children
    }, void 0, false, {
        fileName: "[project]/components/contacts/ContactGuardedLink.tsx",
        lineNumber: 52,
        columnNumber: 5
    }, this);
}
_s(ContactGuardedLink, "b9L3QQ+jgeyIrH0NfHrJ8nn7VMU=");
_c = ContactGuardedLink;
var _c;
__turbopack_context__.k.register(_c, "ContactGuardedLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>NextTouchpointCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$firebase$2f$firestore$2f$dist$2f$esm$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/firebase/firestore/dist/esm/index.esm.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@firebase/firestore/dist/index.esm.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$TouchpointStatusActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/TouchpointStatusActions.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactGuardedLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactGuardedLink.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function NextTouchpointCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { schedule, flush } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"])();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastSavedValuesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    // Initialize form state from contact using lazy initialization
    const [nextTouchpointDate, setNextTouchpointDate] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [nextTouchpointMessage, setNextTouchpointMessage] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [isConvertingToEvent, setIsConvertingToEvent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Use refs to store current values so save function always reads latest state
    const nextTouchpointDateRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(nextTouchpointDate);
    const nextTouchpointMessageRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(nextTouchpointMessage);
    // Keep refs in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NextTouchpointCard.useEffect": ()=>{
            nextTouchpointDateRef.current = nextTouchpointDate;
        }
    }["NextTouchpointCard.useEffect"], [
        nextTouchpointDate
    ]);
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NextTouchpointCard.useEffect": ()=>{
            nextTouchpointMessageRef.current = nextTouchpointMessage;
        }
    }["NextTouchpointCard.useEffect"], [
        nextTouchpointMessage
    ]);
    // Reset form state only when contactId changes (switching to a different contact)
    // Don't reset when contact data updates from our own save
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "NextTouchpointCard.useEffect": ()=>{
            if (!contact) return;
            // Only reset if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                lastSavedValuesRef.current = null; // Clear saved values when switching contacts
                // Batch state updates to avoid cascading renders
                const dateValue = contact.nextTouchpointDate instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] ? contact.nextTouchpointDate.toDate().toISOString().split("T")[0] : typeof contact.nextTouchpointDate === "string" ? contact.nextTouchpointDate.split("T")[0] : "";
                setNextTouchpointDate(dateValue);
                setNextTouchpointMessage(contact.nextTouchpointMessage ?? "");
                return;
            }
            // If contact data updated but it matches what we just saved, don't reset
            if (lastSavedValuesRef.current) {
                const saved = lastSavedValuesRef.current;
                const contactDate = contact.nextTouchpointDate instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] ? contact.nextTouchpointDate.toDate().toISOString().split("T")[0] : typeof contact.nextTouchpointDate === "string" ? contact.nextTouchpointDate.split("T")[0] : "";
                const contactMessage = contact.nextTouchpointMessage ?? "";
                if (contactDate === saved.date && contactMessage === saved.message) {
                    // This update came from our save, don't reset form
                    return;
                }
            }
            // Only update if form values match the old contact values (user hasn't made changes)
            const contactDate = contact.nextTouchpointDate instanceof __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$firebase$2f$firestore$2f$dist$2f$index$2e$esm$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Timestamp"] ? contact.nextTouchpointDate.toDate().toISOString().split("T")[0] : typeof contact.nextTouchpointDate === "string" ? contact.nextTouchpointDate.split("T")[0] : "";
            const contactMessage = contact.nextTouchpointMessage ?? "";
            if (nextTouchpointDate === contactDate && nextTouchpointMessage === contactMessage) {
                // Form hasn't been edited, safe to update from contact
                setNextTouchpointDate(contactDate);
                setNextTouchpointMessage(contactMessage);
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["NextTouchpointCard.useEffect"], [
        contact?.contactId,
        contact?.nextTouchpointDate,
        contact?.nextTouchpointMessage
    ]);
    // Save function for autosave - reads from refs to always get latest values
    const saveTouchpoint = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NextTouchpointCard.useMemo[saveTouchpoint]": ()=>{
            return ({
                "NextTouchpointCard.useMemo[saveTouchpoint]": async ()=>{
                    if (!contact) return;
                    // Read current form values from refs (always latest, even if scheduled before state update)
                    const currentDate = nextTouchpointDateRef.current || null;
                    const currentMessage = nextTouchpointMessageRef.current || null;
                    return new Promise({
                        "NextTouchpointCard.useMemo[saveTouchpoint]": (resolve, reject)=>{
                            updateMutation.mutate({
                                contactId,
                                updates: {
                                    nextTouchpointDate: currentDate,
                                    nextTouchpointMessage: currentMessage
                                }
                            }, {
                                onSuccess: {
                                    "NextTouchpointCard.useMemo[saveTouchpoint]": ()=>{
                                        // Remember what we saved so we don't reset form when contact refetches
                                        lastSavedValuesRef.current = {
                                            date: currentDate ?? "",
                                            message: currentMessage ?? ""
                                        };
                                        resolve();
                                    }
                                }["NextTouchpointCard.useMemo[saveTouchpoint]"],
                                onError: {
                                    "NextTouchpointCard.useMemo[saveTouchpoint]": (error)=>{
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                                            context: "Saving next touchpoint in NextTouchpointCard",
                                            tags: {
                                                component: "NextTouchpointCard",
                                                contactId
                                            }
                                        });
                                        reject(error);
                                    }
                                }["NextTouchpointCard.useMemo[saveTouchpoint]"]
                            });
                        }
                    }["NextTouchpointCard.useMemo[saveTouchpoint]"]);
                }
            })["NextTouchpointCard.useMemo[saveTouchpoint]"];
        }
    }["NextTouchpointCard.useMemo[saveTouchpoint]"], [
        contact,
        contactId,
        updateMutation
    ]);
    // Check if touchpoint is linked to a calendar event
    const isLinkedToEvent = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "NextTouchpointCard.useMemo[isLinkedToEvent]": ()=>{
            if (!contact) return false;
            return contact.linkedGoogleEventId && contact.linkStatus === "linked";
        }
    }["NextTouchpointCard.useMemo[isLinkedToEvent]"], [
        contact
    ]);
    const handleConvertToMeeting = async ()=>{
        if (!contact || !nextTouchpointDate) {
            alert("Please set a touchpoint date first");
            return;
        }
        // Flush any pending saves first
        await flush("touchpoint");
        setIsConvertingToEvent(true);
        try {
            const response = await fetch("/api/touchpoints/convert-to-event", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "include",
                body: JSON.stringify({
                    contactId: contact.contactId,
                    touchpointDate: nextTouchpointDate,
                    message: nextTouchpointMessage || undefined
                })
            });
            if (!response.ok) {
                const errorData = await response.json().catch(()=>({}));
                throw new Error(errorData.error || "Failed to convert touchpoint to meeting");
            }
            const data = await response.json();
            // Invalidate queries to refresh data
            queryClient.invalidateQueries({
                queryKey: [
                    "contacts"
                ]
            });
            queryClient.invalidateQueries({
                queryKey: [
                    "calendar-events"
                ]
            });
            // Navigate to calendar or show success
            if (data.event?.eventId) {
                router.push(`/calendar?eventId=${data.event.eventId}`);
            }
        } catch (error) {
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Converting touchpoint to calendar event",
                tags: {
                    component: "NextTouchpointCard",
                    contactId
                }
            });
            alert(error instanceof Error ? error.message : "Failed to convert touchpoint to meeting");
        } finally{
            setIsConvertingToEvent(false);
        }
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-48",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 207,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
            lineNumber: 206,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex items-center justify-between mb-2",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center gap-2",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                            className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                    className: "w-5 h-5 text-gray-400",
                                    fill: "none",
                                    stroke: "currentColor",
                                    viewBox: "0 0 24 24",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                        strokeLinecap: "round",
                                        strokeLinejoin: "round",
                                        strokeWidth: 2,
                                        d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                        lineNumber: 223,
                                        columnNumber: 15
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                    lineNumber: 217,
                                    columnNumber: 13
                                }, this),
                                "Next Touchpoint"
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                            lineNumber: 216,
                            columnNumber: 11
                        }, this),
                        isLinkedToEvent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "px-2 py-1 text-xs font-semibold bg-green-100 text-green-800 rounded-md",
                            children: "Linked to Meeting"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                            lineNumber: 233,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                    lineNumber: 215,
                    columnNumber: 9
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 214,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-theme-dark mb-4",
                children: "Schedule and plan your next interaction with this contact. Set a date and add notes about what to discuss to maintain consistent, meaningful engagement."
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 239,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "next-touchpoint-date",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Date"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 244,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                id: "next-touchpoint-date",
                                type: "date",
                                className: "w-full px-4 py-2 border border-gray-300 rounded-sm focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all duration-200",
                                value: nextTouchpointDate,
                                onChange: (e)=>{
                                    const dateValue = e.target.value;
                                    if (dateValue && dateValue.match(/^\d{4}-\d{2}-\d{2}$/)) {
                                        setNextTouchpointDate(dateValue);
                                        schedule("touchpoint", saveTouchpoint, 0); // Save immediately on date change
                                    } else if (!dateValue) {
                                        setNextTouchpointDate("");
                                        schedule("touchpoint", saveTouchpoint, 0);
                                    }
                                },
                                onBlur: ()=>flush("touchpoint")
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 247,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 243,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                                htmlFor: "next-touchpoint-message",
                                className: "block text-sm font-medium text-theme-darker mb-2",
                                children: "Message"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 266,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                id: "next-touchpoint-message",
                                name: "next-touchpoint-message",
                                rows: 3,
                                value: nextTouchpointMessage,
                                onChange: (e)=>{
                                    setNextTouchpointMessage(e.target.value);
                                    schedule("touchpoint", saveTouchpoint);
                                },
                                onBlur: ()=>flush("touchpoint"),
                                placeholder: "What should you discuss in the next touchpoint?"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 269,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 265,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 242,
                columnNumber: 7
            }, this),
            nextTouchpointDate && !isLinkedToEvent && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 pt-4 border-t border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                        onClick: handleConvertToMeeting,
                        disabled: isConvertingToEvent || !nextTouchpointDate,
                        loading: isConvertingToEvent,
                        variant: "primary",
                        fullWidth: true,
                        children: "Convert to Meeting"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 287,
                        columnNumber: 11
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-theme-dark mt-2 text-center",
                        children: "Create a Google Calendar event from this touchpoint"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 296,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 286,
                columnNumber: 9
            }, this),
            isLinkedToEvent && contact.linkedGoogleEventId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 pt-4 border-t border-gray-200",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-sm font-medium text-theme-darkest",
                                    children: "Linked to Calendar Event"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                    lineNumber: 307,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                    className: "text-xs text-theme-dark mt-1",
                                    children: "This touchpoint is connected to a Google Calendar event"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                    lineNumber: 308,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                            lineNumber: 306,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactGuardedLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            href: `/calendar?eventId=${contact.linkedGoogleEventId}`,
                            className: "text-sm text-blue-600 hover:text-blue-700 font-medium",
                            children: "View Event →"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                            lineNumber: 312,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                    lineNumber: 305,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 304,
                columnNumber: 9
            }, this),
            (nextTouchpointDate || contact.touchpointStatus) && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mt-4 pt-4 border-t border-gray-200",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$TouchpointStatusActions$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        contactId: contactId,
                        contactName: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact),
                        userId: userId,
                        onStatusUpdate: ()=>{
                        // No-op: React Query will automatically update the contact data
                        }
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 325,
                        columnNumber: 11
                    }, this),
                    contact.touchpointStatusUpdatedAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs text-gray-500 mt-2",
                        children: [
                            "Status updated:",
                            " ",
                            (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.touchpointStatusUpdatedAt, {
                                relative: true
                            })
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 334,
                        columnNumber: 13
                    }, this),
                    contact.touchpointStatusReason && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "mt-3 p-3 bg-theme-lighter border border-gray-200 rounded-sm",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs font-medium text-gray-500 uppercase tracking-wide mb-1",
                                children: contact.touchpointStatus === "completed" ? "Note" : "Reason"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 343,
                                columnNumber: 15
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-theme-darker",
                                children: contact.touchpointStatusReason
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                                lineNumber: 346,
                                columnNumber: 15
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                        lineNumber: 342,
                        columnNumber: 13
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
                lineNumber: 324,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx",
        lineNumber: 213,
        columnNumber: 5
    }, this);
}
_s(NextTouchpointCard, "1UzPKvcLoWW2+GEJG2pfeWHMs14=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"]
    ];
});
_c = NextTouchpointCard;
var _c;
__turbopack_context__.k.register(_c, "NextTouchpointCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>OutreachDraftCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Textarea.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function OutreachDraftCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const updateMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"])(userId);
    const { schedule, flush } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"])();
    const prevContactIdRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const lastSavedValuesRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const [localDraft, setLocalDraft] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [modalContent, setModalContent] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    // Use ref to store current value so save function always reads latest state
    const localDraftRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(localDraft);
    // Keep ref in sync with state
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OutreachDraftCard.useEffect": ()=>{
            localDraftRef.current = localDraft;
        }
    }["OutreachDraftCard.useEffect"], [
        localDraft
    ]);
    // Reset form state only when contactId changes (switching to a different contact)
    // Don't reset when contact data updates from our own save
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "OutreachDraftCard.useEffect": ()=>{
            if (!contact) return;
            // Only reset if we're switching to a different contact
            if (prevContactIdRef.current !== contact.contactId) {
                prevContactIdRef.current = contact.contactId;
                lastSavedValuesRef.current = null; // Clear saved values when switching contacts
                setLocalDraft(contact.outreachDraft ?? "");
                return;
            }
            // If contact data updated but it matches what we just saved, don't reset
            if (lastSavedValuesRef.current !== null) {
                const contactDraft = contact.outreachDraft ?? "";
                if (contactDraft === lastSavedValuesRef.current) {
                    // This update came from our save, don't reset form
                    return;
                }
            }
            // Only update if form value matches the old contact value (user hasn't made changes)
            if (localDraft === (contact.outreachDraft ?? "")) {
                // Form hasn't been edited, safe to update from contact
                setLocalDraft(contact.outreachDraft ?? "");
            }
        // eslint-disable-next-line react-hooks/exhaustive-deps
        }
    }["OutreachDraftCard.useEffect"], [
        contact?.contactId,
        contact?.outreachDraft
    ]);
    // Save function for autosave - reads from ref to always get latest value
    const saveDraft = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "OutreachDraftCard.useMemo[saveDraft]": ()=>{
            return ({
                "OutreachDraftCard.useMemo[saveDraft]": async ()=>{
                    if (!contact) return;
                    // Read current form value from ref (always latest, even if scheduled before state update)
                    const currentDraft = localDraftRef.current || null;
                    return new Promise({
                        "OutreachDraftCard.useMemo[saveDraft]": (resolve, reject)=>{
                            updateMutation.mutate({
                                contactId,
                                updates: {
                                    outreachDraft: currentDraft
                                }
                            }, {
                                onSuccess: {
                                    "OutreachDraftCard.useMemo[saveDraft]": ()=>{
                                        // Remember what we saved so we don't reset form when contact refetches
                                        lastSavedValuesRef.current = currentDraft ?? "";
                                        resolve();
                                    }
                                }["OutreachDraftCard.useMemo[saveDraft]"],
                                onError: {
                                    "OutreachDraftCard.useMemo[saveDraft]": (error)=>{
                                        (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                                            context: "Saving outreach draft in OutreachDraftCard",
                                            tags: {
                                                component: "OutreachDraftCard",
                                                contactId
                                            }
                                        });
                                        reject(error);
                                    }
                                }["OutreachDraftCard.useMemo[saveDraft]"]
                            });
                        }
                    }["OutreachDraftCard.useMemo[saveDraft]"]);
                }
            })["OutreachDraftCard.useMemo[saveDraft]"];
        }
    }["OutreachDraftCard.useMemo[saveDraft]"], [
        contact,
        contactId,
        updateMutation
    ]);
    const openGmailCompose = async ()=>{
        if (!contact?.primaryEmail) {
            setModalContent("no-email");
            return;
        }
        if (!localDraft.trim()) {
            setModalContent("no-draft");
            return;
        }
        // Flush any pending saves before opening Gmail
        try {
            await flush("draft");
        } catch (error) {
            // Continue anyway - don't block user from opening Gmail
            (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                context: "Auto-saving outreach draft before opening Gmail in OutreachDraftCard",
                tags: {
                    component: "OutreachDraftCard",
                    contactId
                }
            });
        }
        // Open Gmail
        const email = encodeURIComponent(contact.primaryEmail);
        const body = encodeURIComponent(localDraft);
        const subject = encodeURIComponent("Follow up");
        const gmailUrl = `https://mail.google.com/mail/?view=cm&to=${email}&body=${body}&su=${subject}`;
        window.open(gmailUrl, "_blank");
    };
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-32",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                lineNumber: 137,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
            lineNumber: 136,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: modalContent !== null,
                onClose: ()=>setModalContent(null),
                title: modalContent === "no-email" ? "No Email Address" : "No Draft Message",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: modalContent === "no-email" ? "This contact does not have an email address." : "Please add a draft message before continuing in Gmail."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 150,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                            onClick: ()=>setModalContent(null),
                            variant: "outline",
                            size: "sm",
                            children: "OK"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                            lineNumber: 156,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 155,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                lineNumber: 145,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                padding: "md",
                className: "relative",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col xl:flex-row xl:items-center xl:justify-between gap-3 mb-2",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                className: "text-lg font-semibold text-theme-darkest flex items-center gap-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-5 h-5 text-gray-400 shrink-0",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 175,
                                            columnNumber: 15
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 169,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                        className: "truncate",
                                        children: "Outreach Draft"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 182,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                lineNumber: 168,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-3 shrink-0",
                                children: localDraft.trim() && contact.primaryEmail && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                    onClick: openGmailCompose,
                                    variant: "link",
                                    size: "sm",
                                    "aria-label": "Open this draft in Gmail",
                                    className: "whitespace-nowrap",
                                    icon: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 shrink-0",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        "aria-hidden": "true",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 200,
                                            columnNumber: 21
                                        }, void 0)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                        lineNumber: 193,
                                        columnNumber: 19
                                    }, void 0),
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "hidden sm:inline",
                                            children: "Continue in Gmail"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 209,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "sm:hidden",
                                            children: "Gmail"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                            lineNumber: 210,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                    lineNumber: 186,
                                    columnNumber: 15
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                                lineNumber: 184,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-4",
                        children: "Draft and refine your email messages before sending. Your draft is automatically saved and can be opened directly in Gmail when ready to send."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 215,
                        columnNumber: 7
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Textarea$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                        id: "outreach-draft",
                        name: "outreach-draft",
                        value: localDraft,
                        onChange: (e)=>{
                            setLocalDraft(e.target.value);
                            schedule("draft", saveDraft);
                        },
                        onBlur: ()=>flush("draft"),
                        placeholder: "Write your outreach draft here...",
                        className: "min-h-[120px] text-foreground resize-y font-sans text-sm leading-relaxed"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                        lineNumber: 218,
                        columnNumber: 7
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(OutreachDraftCard, "A+UFXUad9MCEBGukfRI0STIDhEA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useUpdateContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"]
    ];
});
_c = OutreachDraftCard;
var _c;
__turbopack_context__.k.register(_c, "OutreachDraftCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactInsightsCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/InfoPopover.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
function ContactInsightsCard({ contactId, userId, initialContact }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const displayContact = contact || initialContact;
    if (!displayContact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-96",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                lineNumber: 27,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
            lineNumber: 26,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-xl font-semibold text-theme-darkest mb-6",
                children: "Contact Insights"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                lineNumber: 34,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-6",
                children: [
                    displayContact.summary && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-indigo-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-indigo-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 46,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 40,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "AI Summary"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 53,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 39,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-theme-darkest whitespace-pre-wrap leading-relaxed",
                                children: displayContact.summary
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 57,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, this),
                    (()=>{
                        const engagementScore = Number(displayContact.engagementScore);
                        const isValidScore = !isNaN(engagementScore) && engagementScore !== null && engagementScore !== undefined;
                        return isValidScore ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "border-l-4 border-teal-500 pl-4",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2 mb-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                            className: "w-4 h-4 text-teal-600",
                                            fill: "none",
                                            stroke: "currentColor",
                                            viewBox: "0 0 24 24",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                strokeLinecap: "round",
                                                strokeLinejoin: "round",
                                                strokeWidth: 2,
                                                d: "M13 7h8m0 0v8m0-8l-8 8-4-4-6 6"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                                lineNumber: 79,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 73,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                            className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                            children: "Engagement Score"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 86,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$InfoPopover$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                            content: "A numerical score (0-100) that measures how actively engaged this contact is with your communications. Higher scores indicate more frequent interactions, email opens, responses, and overall engagement with your content."
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 89,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                    lineNumber: 72,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-center gap-2",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 bg-gray-200 rounded-full h-2",
                                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "bg-teal-600 h-2 rounded-full",
                                                style: {
                                                    width: `${Math.min(engagementScore, 100)}%`
                                                }
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                                lineNumber: 93,
                                                columnNumber: 19
                                            }, this)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 92,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: "text-sm font-semibold text-theme-darkest",
                                            children: Math.round(engagementScore)
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 98,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                    lineNumber: 91,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                            lineNumber: 71,
                            columnNumber: 13
                        }, this) : null;
                    })(),
                    displayContact.threadCount && displayContact.threadCount > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-cyan-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-cyan-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 116,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 110,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Email Threads"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 123,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 109,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-theme-darkest",
                                children: displayContact.threadCount
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 127,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 108,
                        columnNumber: 11
                    }, this),
                    displayContact.lastEmailDate != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-blue-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-blue-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 143,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 137,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Last Email Date"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 150,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 136,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm font-semibold text-theme-darkest",
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(displayContact.lastEmailDate, {
                                    relative: true
                                })
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 154,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-xs text-gray-500 mt-1",
                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(displayContact.lastEmailDate, {
                                    includeTime: true
                                })
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 157,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 135,
                        columnNumber: 11
                    }, this),
                    displayContact.painPoints && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-red-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-2",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-red-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 173,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 167,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Pain Points"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 180,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 166,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                className: "text-sm text-theme-darkest whitespace-pre-wrap leading-relaxed",
                                children: displayContact.painPoints
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 184,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 165,
                        columnNumber: 11
                    }, this),
                    displayContact.sentiment && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "border-l-4 border-purple-500 pl-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-2 mb-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                        className: "w-4 h-4 text-purple-600",
                                        fill: "none",
                                        stroke: "currentColor",
                                        viewBox: "0 0 24 24",
                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                            strokeLinecap: "round",
                                            strokeLinejoin: "round",
                                            strokeWidth: 2,
                                            d: "M7 8h10M7 12h4m1 8l-4-4H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-3l-4 4z"
                                        }, void 0, false, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                            lineNumber: 199,
                                            columnNumber: 17
                                        }, this)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 193,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                        className: "text-xs font-medium text-gray-500 uppercase tracking-wide",
                                        children: "Sentiment"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                        lineNumber: 206,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 192,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                className: `inline-block px-2 py-1 rounded-full text-xs font-medium ${displayContact.sentiment.toLowerCase().includes("positive") ? "bg-green-100 text-green-800" : displayContact.sentiment.toLowerCase().includes("negative") ? "bg-red-100 text-red-800" : "bg-gray-100 text-theme-darker"}`,
                                children: displayContact.sentiment
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                                lineNumber: 210,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                        lineNumber: 191,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_s(ContactInsightsCard, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ContactInsightsCard;
var _c;
__turbopack_context__.k.register(_c, "ContactInsightsCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ActivityCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
function ActivityCard({ contactId, userId }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-32",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                lineNumber: 19,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
            lineNumber: 18,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                className: "text-lg font-semibold text-theme-darkest mb-4",
                children: "Activity"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                lineNumber: 26,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-3 text-sm",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-start gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-blue-500 rounded-full mt-1.5"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 29,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-medium text-theme-darkest",
                                        children: "Last updated"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 31,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.updatedAt, {
                                            includeTime: true
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 32,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 30,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                        lineNumber: 28,
                        columnNumber: 9
                    }, this),
                    contact.createdAt != null && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-start gap-3",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "w-2 h-2 bg-green-500 rounded-full mt-1.5"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 39,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "font-medium text-theme-darkest",
                                        children: "Created"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 41,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                        className: "text-gray-500",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatContactDate"])(contact.createdAt, {
                                            includeTime: true
                                        })
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                        lineNumber: 42,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                                lineNumber: 40,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                        lineNumber: 38,
                        columnNumber: 11
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
                lineNumber: 27,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
}
_s(ActivityCard, "RMraLUiYNjzSbpembo7KgOc4sVs=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"]
    ];
});
_c = ActivityCard;
var _c;
__turbopack_context__.k.register(_c, "ActivityCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/timeline/constants.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Timeline constants that can be used in both client and server contexts
 */ __turbopack_context__.s([
    "DEFAULT_TIMELINE_DAYS",
    ()=>DEFAULT_TIMELINE_DAYS,
    "MAX_TIMELINE_DAYS",
    ()=>MAX_TIMELINE_DAYS
]);
const DEFAULT_TIMELINE_DAYS = 45;
const MAX_TIMELINE_DAYS = 60;
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/timeline/sanitize-description.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/**
 * Sanitizes and formats meeting descriptions
 * - Decodes HTML entities
 * - Extracts URLs and formats them as clickable links
 * - Returns plain text with URL extraction for safe rendering
 */ __turbopack_context__.s([
    "formatLinkPath",
    ()=>formatLinkPath,
    "parseDescription",
    ()=>parseDescription
]);
/**
 * Decodes HTML entities in a string (works in both client and server contexts)
 */ function decodeHtmlEntities(text) {
    // Common HTML entities mapping
    const entityMap = {
        "&lt;": "<",
        "&gt;": ">",
        "&amp;": "&",
        "&quot;": '"',
        "&#39;": "'",
        "&apos;": "'",
        "&nbsp;": " "
    };
    let decoded = text;
    // Replace common entities
    Object.entries(entityMap).forEach(([entity, char])=>{
        decoded = decoded.replace(new RegExp(entity, "g"), char);
    });
    // Handle numeric entities like &#123;
    decoded = decoded.replace(/&#(\d+);/g, (match, num)=>{
        return String.fromCharCode(parseInt(num, 10));
    });
    // Handle hex entities like &#x1F;
    decoded = decoded.replace(/&#x([0-9a-fA-F]+);/g, (match, hex)=>{
        return String.fromCharCode(parseInt(hex, 16));
    });
    return decoded;
}
function parseDescription(description) {
    if (!description) {
        return {
            text: "",
            links: []
        };
    }
    // Decode HTML entities
    const cleaned = decodeHtmlEntities(description);
    // Extract URLs using a regex
    const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`[\]]+)/gi;
    const matches = cleaned.match(urlRegex) || [];
    // Extract unique URLs and parse them
    const uniqueUrls = Array.from(new Set(matches));
    const links = uniqueUrls.map((url)=>{
        try {
            const urlObj = new URL(url);
            return {
                url,
                hostname: urlObj.hostname,
                path: urlObj.pathname + urlObj.search
            };
        } catch  {
            return {
                url,
                hostname: url,
                path: ""
            };
        }
    });
    // Remove URLs from text (they'll be rendered separately)
    // But keep a placeholder so we can replace them with formatted links
    let textWithPlaceholders = cleaned;
    uniqueUrls.forEach((url, index)=>{
        textWithPlaceholders = textWithPlaceholders.replace(url, `[LINK_${index}]`);
    });
    return {
        text: textWithPlaceholders,
        links
    };
}
function formatLinkPath(path, maxLength = 50) {
    if (path.length <= maxLength) return path;
    return path.substring(0, maxLength - 3) + "...";
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/lib/timeline/group-meetings.ts [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "groupMeetingsIntoSeries",
    ()=>groupMeetingsIntoSeries
]);
/**
 * Normalizes a meeting title for grouping purposes
 */ function normalizeTitle(title) {
    return title.toLowerCase().trim().replace(/[^\w\s]/g, "") // Remove punctuation
    .replace(/\s+/g, " ") // Collapse multiple spaces
    .replace(/\b(weekly|monthly|daily|recurring|meeting|call|standup)\b/gi, "") // Remove common suffixes
    .trim();
}
/**
 * Normalizes attendee emails for comparison
 */ function normalizeAttendees(attendees) {
    if (!attendees || attendees.length === 0) return "";
    return attendees.map((a)=>a.email?.toLowerCase().trim() || "").filter(Boolean).sort().join(",");
}
/**
 * Creates a grouping key for a meeting
 * Note: All meetings in a contact's timeline are already filtered by contactId,
 * so we don't need to include it in the grouping key
 */ function createGroupKey(title, attendees) {
    const normalizedTitle = normalizeTitle(title);
    const normalizedAttendees = normalizeAttendees(attendees);
    // Group by: normalized title + stable attendee set
    return `${normalizedTitle}|${normalizedAttendees}`;
}
function groupMeetingsIntoSeries(meetings) {
    // Early return if no meetings
    if (meetings.length === 0) {
        return [];
    }
    // Filter to only calendar events
    const meetingItems = meetings.filter((item)=>item.type === "calendar_event");
    // Early return if no meeting items - return non-meeting items as-is
    if (meetingItems.length === 0) {
        return meetings.filter((item)=>item.type !== "calendar_event");
    }
    // Group meetings by their grouping key
    const groups = new Map();
    for (const meeting of meetingItems){
        const groupKey = createGroupKey(meeting.title, meeting.attendees);
        if (!groups.has(groupKey)) {
            groups.set(groupKey, []);
        }
        groups.get(groupKey).push(meeting);
    }
    const result = [];
    // Process each group
    for (const [groupKey, items] of groups.entries()){
        // If only one meeting, don't group it
        if (items.length === 1) {
            result.push(items[0]);
            continue;
        }
        // Sort items by timestamp (newest first)
        items.sort((a, b)=>{
            const getTime = (timestamp)=>{
                if (timestamp instanceof Date) return timestamp.getTime();
                if (typeof timestamp === "string") return new Date(timestamp).getTime();
                if (timestamp && typeof timestamp === "object") {
                    if ("toDate" in timestamp) {
                        return timestamp.toDate().getTime();
                    }
                    if ("seconds" in timestamp) {
                        const ts = timestamp;
                        return ts.seconds * 1000;
                    }
                }
                return 0;
            };
            return getTime(b.timestamp) - getTime(a.timestamp);
        });
        // Find last and next occurrence
        const now = new Date();
        let lastOccurrenceDate = new Date(0);
        let nextOccurrenceDate;
        const getDate = (timestamp)=>{
            if (timestamp instanceof Date) return timestamp;
            if (typeof timestamp === "string") return new Date(timestamp);
            if (timestamp && typeof timestamp === "object") {
                if ("toDate" in timestamp) {
                    return timestamp.toDate();
                }
                if ("seconds" in timestamp) {
                    const ts = timestamp;
                    return new Date(ts.seconds * 1000);
                }
            }
            return new Date();
        };
        for (const item of items){
            const itemDate = getDate(item.timestamp);
            if (itemDate > lastOccurrenceDate) {
                lastOccurrenceDate = itemDate;
            }
            if (itemDate > now && (!nextOccurrenceDate || itemDate < nextOccurrenceDate)) {
                nextOccurrenceDate = itemDate;
            }
        }
        // Get unique attendees count
        const allAttendees = new Set();
        items.forEach((item)=>{
            item.attendees?.forEach((a)=>{
                if (a.email) allAttendees.add(a.email.toLowerCase());
            });
        });
        // Use the most recent meeting's title as the series title
        const seriesTitle = items[0].title;
        const series = {
            seriesId: groupKey,
            title: seriesTitle,
            matchedContactId: null,
            attendeeCount: allAttendees.size,
            occurrenceCount: items.length,
            lastOccurrenceDate,
            nextOccurrenceDate,
            items
        };
        result.push(series);
    }
    // Add non-meeting items as-is
    const nonMeetingItems = meetings.filter((item)=>item.type !== "calendar_event");
    result.push(...nonMeetingItems);
    // Sort all items by timestamp (newest first)
    result.sort((a, b)=>{
        const getDate = (item)=>{
            if ("items" in item) {
                // It's a series - use last occurrence date
                return item.lastOccurrenceDate;
            }
            // It's a timeline item
            const timestamp = item.timestamp;
            if (timestamp instanceof Date) return timestamp;
            if (typeof timestamp === "string") return new Date(timestamp);
            if (timestamp && typeof timestamp === "object") {
                if ("toDate" in timestamp) {
                    return timestamp.toDate();
                }
                if ("seconds" in timestamp) {
                    const ts = timestamp;
                    return new Date(ts.seconds * 1000);
                }
            }
            return new Date(0);
        };
        return getDate(b).getTime() - getDate(a).getTime();
    });
    return result;
}
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactTimelineCard
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Card.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$formatDistanceToNow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/date-fns/formatDistanceToNow.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/node_modules/date-fns/format.js [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/timeline/constants.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$sanitize$2d$description$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/timeline/sanitize-description.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$group$2d$meetings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/timeline/group-meetings.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature(), _s1 = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
// Memoized component for description rendering to avoid re-parsing on every render
const DescriptionContent = /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].memo(_s(({ description })=>{
    _s();
    const parsed = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DescriptionContent.useMemo[parsed]": ()=>(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$sanitize$2d$description$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["parseDescription"])(description)
    }["DescriptionContent.useMemo[parsed]"], [
        description
    ]);
    const hasLinks = parsed.links.length > 0;
    // Reconstruct text without link placeholders
    const displayText = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "DescriptionContent.useMemo[displayText]": ()=>{
            let text = parsed.text;
            parsed.links.forEach({
                "DescriptionContent.useMemo[displayText]": (_, idx)=>{
                    text = text.replace(`[LINK_${idx}]`, "");
                }
            }["DescriptionContent.useMemo[displayText]"]);
            return text.trim();
        }
    }["DescriptionContent.useMemo[displayText]"], [
        parsed.text,
        parsed.links
    ]);
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "mb-2",
        children: [
            displayText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                className: "text-sm text-gray-600 mb-2 line-clamp-2",
                children: displayText
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 38,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0)),
            hasLinks && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-1 mt-2",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-xs font-medium text-gray-500 mb-1",
                        children: "Documents:"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 44,
                        columnNumber: 11
                    }, ("TURBOPACK compile-time value", void 0)),
                    parsed.links.map((link, idx)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex items-center gap-2 text-xs",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-600 truncate flex-1",
                                    children: [
                                        link.hostname,
                                        link.path && ` ${(0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$sanitize$2d$description$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatLinkPath"])(link.path, 40)}`
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                    lineNumber: 47,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                    onClick: async ()=>{
                                        try {
                                            await navigator.clipboard.writeText(link.url);
                                        } catch (err) {
                                        // Silently fail - clipboard errors are usually user permission issues
                                        }
                                    },
                                    className: "px-2 py-0.5 text-gray-600 hover:bg-gray-100 rounded",
                                    title: "Copy link",
                                    children: "Copy"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                    lineNumber: 51,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0)),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("a", {
                                    href: link.url,
                                    target: "_blank",
                                    rel: "noopener noreferrer",
                                    className: "px-2 py-0.5 text-blue-600 hover:bg-blue-50 rounded",
                                    children: "Open"
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                    lineNumber: 64,
                                    columnNumber: 15
                                }, ("TURBOPACK compile-time value", void 0))
                            ]
                        }, idx, true, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                            lineNumber: 46,
                            columnNumber: 13
                        }, ("TURBOPACK compile-time value", void 0)))
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 43,
                columnNumber: 9
            }, ("TURBOPACK compile-time value", void 0))
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
        lineNumber: 36,
        columnNumber: 5
    }, ("TURBOPACK compile-time value", void 0));
}, "LkNZjVcfKGg1UD4GzQPSax1glYE="));
_c = DescriptionContent;
DescriptionContent.displayName = "DescriptionContent";
function ContactTimelineCard({ contactId, userId }) {
    _s1();
    const [filter, setFilter] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("all");
    const [days, setDays] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["DEFAULT_TIMELINE_DAYS"]);
    const router = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"])();
    const queryClient = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"])();
    const { data: timelineItems = [], isLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "contact-timeline",
            userId,
            contactId,
            days
        ],
        queryFn: {
            "ContactTimelineCard.useQuery": async ()=>{
                const response = await fetch(`/api/contacts/${encodeURIComponent(contactId)}/timeline?limit=30&days=${days}`);
                if (!response.ok) {
                    throw new Error("Failed to fetch timeline");
                }
                const data = await response.json();
                return data.timelineItems;
            }
        }["ContactTimelineCard.useQuery"],
        staleTime: 30 * 1000
    });
    // Memoize grouped items - only recompute when timelineItems changes
    const groupedItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactTimelineCard.useMemo[groupedItems]": ()=>{
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$group$2d$meetings$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["groupMeetingsIntoSeries"])(timelineItems);
        }
    }["ContactTimelineCard.useMemo[groupedItems]"], [
        timelineItems
    ]);
    // Memoize filtered items - only recompute when groupedItems or filter changes
    const filteredItems = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useMemo"])({
        "ContactTimelineCard.useMemo[filteredItems]": ()=>{
            if (filter === "all") return groupedItems;
            return groupedItems.filter({
                "ContactTimelineCard.useMemo[filteredItems]": (item)=>{
                    if ("items" in item) {
                        // It's a MeetingSeries - show if filter is "calendar_event"
                        return filter === "calendar_event";
                    }
                    // It's a TimelineItem
                    return item.type === filter;
                }
            }["ContactTimelineCard.useMemo[filteredItems]"]);
        }
    }["ContactTimelineCard.useMemo[filteredItems]"], [
        groupedItems,
        filter
    ]);
    const getItemIcon = (type)=>{
        switch(type){
            case "calendar_event":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 128,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                    lineNumber: 127,
                    columnNumber: 11
                }, this);
            case "touchpoint":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 134,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                    lineNumber: 133,
                    columnNumber: 11
                }, this);
            case "action_item":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2m-6 9l2 2 4-4"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 140,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                    lineNumber: 139,
                    columnNumber: 11
                }, this);
            case "email":
                return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                    className: "w-5 h-5",
                    fill: "none",
                    stroke: "currentColor",
                    viewBox: "0 0 24 24",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                        strokeLinecap: "round",
                        strokeLinejoin: "round",
                        strokeWidth: 2,
                        d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 146,
                        columnNumber: 13
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                    lineNumber: 145,
                    columnNumber: 11
                }, this);
        }
    };
    const getItemTypeLabel = (type)=>{
        switch(type){
            case "calendar_event":
                return "Meeting";
            case "touchpoint":
                return "Touchpoint";
            case "action_item":
                return "Action Item";
            case "email":
                return "Email";
        }
    };
    const formatTimestamp = (timestamp)=>{
        if (!timestamp) return "";
        let date;
        try {
            if (timestamp instanceof Date) {
                date = timestamp;
            } else if (typeof timestamp === "string") {
                date = new Date(timestamp);
            } else if (typeof timestamp === "object" && timestamp !== null && "toDate" in timestamp) {
                date = timestamp.toDate();
            } else if (typeof timestamp === "object" && timestamp !== null && "seconds" in timestamp) {
                // Firestore Timestamp format
                const ts = timestamp;
                date = new Date(ts.seconds * 1000);
            } else {
                return "";
            }
            if (isNaN(date.getTime())) return "";
            return (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$formatDistanceToNow$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["formatDistanceToNow"])(date, {
                addSuffix: true
            });
        } catch  {
            return "";
        }
    };
    const handleQuickAction = (item, action)=>{
        switch(action){
            case "create-touchpoint":
                // Navigate to contact page with touchpoint date prefilled
                let itemDate;
                if (item.timestamp instanceof Date) {
                    itemDate = item.timestamp;
                } else if (typeof item.timestamp === "string") {
                    itemDate = new Date(item.timestamp);
                } else if (item.timestamp && typeof item.timestamp === "object" && "toDate" in item.timestamp) {
                    itemDate = item.timestamp.toDate();
                } else if (item.timestamp && typeof item.timestamp === "object" && "seconds" in item.timestamp) {
                    const ts = item.timestamp;
                    itemDate = new Date(ts.seconds * 1000);
                } else {
                    itemDate = new Date();
                }
                if (isNaN(itemDate.getTime())) {
                    itemDate = new Date();
                }
                const dateStr = itemDate.toISOString().split("T")[0];
                router.push(`/contacts/${contactId}?touchpointDate=${dateStr}`);
                break;
            case "view-event":
                if (item.eventId) {
                    // Open calendar event modal or navigate to calendar
                    router.push(`/calendar?eventId=${item.eventId}`);
                }
                break;
            case "view-email":
                if (item.threadId) {
                // Open email thread (if we have a route for this)
                // TODO: Implement email thread view
                }
                break;
            case "complete-action":
                if (item.actionItemId) {
                    // Mark action item as complete
                    fetch(`/api/action-items`, {
                        method: "PATCH",
                        headers: {
                            "Content-Type": "application/json"
                        },
                        body: JSON.stringify({
                            contactId,
                            actionItemId: item.actionItemId,
                            updates: {
                                status: "completed"
                            }
                        })
                    }).then(()=>{
                        // Refetch timeline
                        queryClient.invalidateQueries({
                            queryKey: [
                                "contact-timeline",
                                userId,
                                contactId
                            ]
                        });
                    });
                }
                break;
        }
    };
    if (isLoading) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
            padding: "md",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-96",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 250,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
            lineNumber: 249,
            columnNumber: 7
        }, this);
    }
    const handleLoadOlder = ()=>{
        // Increment by 15 days up to MAX_TIMELINE_DAYS
        const newDays = Math.min(days + 15, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_TIMELINE_DAYS"]);
        setDays(newDays);
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Card$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        padding: "md",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                        className: "text-xl font-semibold text-theme-darkest mb-3",
                        children: "Timeline"
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 264,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-2",
                        children: [
                            "all",
                            "calendar_event",
                            "touchpoint",
                            "action_item",
                            "email"
                        ].map((filterType)=>/*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: ()=>setFilter(filterType),
                                className: `px-3 py-1 text-sm rounded-md transition-colors ${filter === filterType ? "bg-blue-500 text-white" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}`,
                                children: filterType === "all" ? "All" : getItemTypeLabel(filterType)
                            }, filterType, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                lineNumber: 268,
                                columnNumber: 13
                            }, this))
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 266,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 263,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "mb-6",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-sm text-theme-dark mb-3",
                        children: "View all interactions, meetings, touchpoints, and action items in chronological order."
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 283,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex items-center justify-between",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("select", {
                                value: days,
                                onChange: (e)=>setDays(Number(e.target.value)),
                                className: "px-2 py-1 text-sm rounded-md border border-gray-300 bg-white text-gray-700 focus:outline-none focus:ring-2 focus:ring-blue-500",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: 15,
                                        children: "Last 15 days"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                        lineNumber: 293,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: 30,
                                        children: "Last 30 days"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                        lineNumber: 294,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: 45,
                                        children: "Last 45 days"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                        lineNumber: 295,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("option", {
                                        value: 60,
                                        children: "Last 60 days"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                        lineNumber: 296,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                lineNumber: 288,
                                columnNumber: 11
                            }, this),
                            days < __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$timeline$2f$constants$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["MAX_TIMELINE_DAYS"] && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                onClick: handleLoadOlder,
                                className: "text-sm text-blue-600 hover:text-blue-800 underline",
                                children: "Load older activity"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                lineNumber: 299,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 286,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 282,
                columnNumber: 7
            }, this),
            filteredItems.length === 0 ? /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "text-center py-12 text-gray-500",
                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    children: "No timeline items found."
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                    lineNumber: 311,
                    columnNumber: 11
                }, this)
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 310,
                columnNumber: 9
            }, this) : /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "space-y-4",
                children: filteredItems.map((item)=>{
                    // Check if this is a MeetingSeries
                    if ("items" in item) {
                        const series = item;
                        const lastDate = series.lastOccurrenceDate;
                        const lastDateStr = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$date$2d$fns$2f$format$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["format"])(lastDate, "MMM d");
                        // Determine frequency based on occurrence count and time span
                        let frequency = "Recurring";
                        if (series.items.length >= 2) {
                            const dates = series.items.map((i)=>{
                                const ts = i.timestamp;
                                if (ts instanceof Date) return ts;
                                if (typeof ts === "string") return new Date(ts);
                                if (ts && typeof ts === "object" && "toDate" in ts) {
                                    return ts.toDate();
                                }
                                if (ts && typeof ts === "object" && "seconds" in ts) {
                                    return new Date(ts.seconds * 1000);
                                }
                                return new Date();
                            }).sort((a, b)=>a.getTime() - b.getTime());
                            if (dates.length >= 2) {
                                const timeSpan = dates[dates.length - 1].getTime() - dates[0].getTime();
                                const daysSpan = timeSpan / (1000 * 60 * 60 * 24);
                                const avgDaysBetween = daysSpan / (dates.length - 1);
                                if (avgDaysBetween >= 6 && avgDaysBetween <= 8) {
                                    frequency = "Weekly";
                                } else if (avgDaysBetween >= 13 && avgDaysBetween <= 15) {
                                    frequency = "Bi-weekly";
                                } else if (avgDaysBetween >= 28 && avgDaysBetween <= 31) {
                                    frequency = "Monthly";
                                }
                            }
                        }
                        // Get the most recent event
                        const mostRecentEvent = series.items[0];
                        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "flex gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors",
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600",
                                    children: getItemIcon("calendar_event")
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                    lineNumber: 361,
                                    columnNumber: 19
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex-1 min-w-0",
                                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "flex items-start justify-between gap-4",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "flex-1 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "flex items-center gap-2 mb-1 flex-wrap",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs font-medium text-gray-500 uppercase",
                                                                children: "Meeting"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 368,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-xs text-gray-400",
                                                                children: "·"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 371,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "text-sm font-semibold text-theme-darkest",
                                                                children: series.title
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 372,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-flex items-center px-2 py-0.5 text-xs font-medium rounded bg-purple-100 text-purple-800",
                                                                children: "Recurring"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 375,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                        lineNumber: 367,
                                                        columnNumber: 25
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                        className: "text-sm text-gray-600 mb-2",
                                                        children: [
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "inline-block mr-1",
                                                                children: "↳"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 380,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    series.occurrenceCount,
                                                                    " occurrences"
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 381,
                                                                columnNumber: 27
                                                            }, this),
                                                            frequency !== "Recurring" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                                                                children: [
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        className: "mx-1",
                                                                        children: "·"
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                        lineNumber: 384,
                                                                        columnNumber: 31
                                                                    }, this),
                                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                        children: frequency
                                                                    }, void 0, false, {
                                                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                        lineNumber: 385,
                                                                        columnNumber: 31
                                                                    }, this)
                                                                ]
                                                            }, void 0, true),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                className: "mx-1",
                                                                children: "·"
                                                            }, void 0, false, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 388,
                                                                columnNumber: 27
                                                            }, this),
                                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                                children: [
                                                                    "Last: ",
                                                                    lastDateStr
                                                                ]
                                                            }, void 0, true, {
                                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                                lineNumber: 389,
                                                                columnNumber: 27
                                                            }, this)
                                                        ]
                                                    }, void 0, true, {
                                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                        lineNumber: 379,
                                                        columnNumber: 25
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                lineNumber: 366,
                                                columnNumber: 23
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "shrink-0 flex gap-2",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>{
                                                        // TODO: Expand series accordion (will implement in next step)
                                                        },
                                                        className: "text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100",
                                                        children: "View series"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                        lineNumber: 393,
                                                        columnNumber: 25
                                                    }, this),
                                                    mostRecentEvent?.eventId && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                        onClick: ()=>handleQuickAction(mostRecentEvent, "view-event"),
                                                        className: "text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100",
                                                        children: "View most recent"
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                        lineNumber: 402,
                                                        columnNumber: 27
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                lineNumber: 392,
                                                columnNumber: 23
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                        lineNumber: 365,
                                        columnNumber: 21
                                    }, this)
                                }, void 0, false, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                    lineNumber: 364,
                                    columnNumber: 19
                                }, this)
                            ]
                        }, series.seriesId, true, {
                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                            lineNumber: 357,
                            columnNumber: 17
                        }, this);
                    }
                    // Regular timeline item
                    let timestamp;
                    try {
                        if (item.timestamp instanceof Date) {
                            timestamp = item.timestamp;
                        } else if (typeof item.timestamp === "string") {
                            timestamp = new Date(item.timestamp);
                        } else if (item.timestamp && typeof item.timestamp === "object") {
                            if ("toDate" in item.timestamp) {
                                timestamp = item.timestamp.toDate();
                            } else if ("seconds" in item.timestamp) {
                                const ts = item.timestamp;
                                timestamp = new Date(ts.seconds * 1000);
                            } else {
                                timestamp = new Date();
                            }
                        } else {
                            timestamp = new Date();
                        }
                        if (isNaN(timestamp.getTime())) {
                            timestamp = new Date();
                        }
                    } catch  {
                        timestamp = new Date();
                    }
                    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-4 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "shrink-0 w-10 h-10 rounded-full bg-blue-100 flex items-center justify-center text-blue-600",
                                children: getItemIcon(item.type)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                lineNumber: 447,
                                columnNumber: 17
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex-1 min-w-0",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: "flex items-start justify-between gap-4",
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "flex-1 min-w-0",
                                            children: [
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                    className: "flex items-center gap-2 mb-1",
                                                    children: [
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs font-medium text-gray-500 uppercase",
                                                            children: getItemTypeLabel(item.type)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                            lineNumber: 454,
                                                            columnNumber: 25
                                                        }, this),
                                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                            className: "text-xs text-gray-400",
                                                            children: formatTimestamp(item.timestamp)
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                            lineNumber: 457,
                                                            columnNumber: 25
                                                        }, this)
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 453,
                                                    columnNumber: 23
                                                }, this),
                                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h3", {
                                                    className: "font-semibold text-theme-darkest mb-1",
                                                    children: item.title
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 461,
                                                    columnNumber: 23
                                                }, this),
                                                item.description && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(DescriptionContent, {
                                                    description: item.description
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 462,
                                                    columnNumber: 44
                                                }, this),
                                                item.type === "calendar_event" && item.location && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500 mb-2",
                                                    children: [
                                                        "📍 ",
                                                        item.location
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 464,
                                                    columnNumber: 25
                                                }, this),
                                                item.type === "calendar_event" && item.attendees && item.attendees.length > 0 && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                    className: "text-xs text-gray-500",
                                                    children: [
                                                        "👥 ",
                                                        item.attendees.length,
                                                        " attendee",
                                                        item.attendees.length !== 1 ? "s" : ""
                                                    ]
                                                }, void 0, true, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 469,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                            lineNumber: 452,
                                            columnNumber: 21
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                            className: "shrink-0 flex gap-2",
                                            children: [
                                                item.type === "calendar_event" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleQuickAction(item, "view-event"),
                                                    className: "text-xs px-2 py-1 bg-blue-50 text-blue-600 rounded hover:bg-blue-100",
                                                    children: "View Event"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 476,
                                                    columnNumber: 25
                                                }, this),
                                                item.type === "action_item" && item.status === "pending" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleQuickAction(item, "complete-action"),
                                                    className: "text-xs px-2 py-1 bg-green-50 text-green-600 rounded hover:bg-green-100",
                                                    children: "Complete"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 484,
                                                    columnNumber: 25
                                                }, this),
                                                item.type === "email" && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                                    onClick: ()=>handleQuickAction(item, "view-email"),
                                                    className: "text-xs px-2 py-1 bg-gray-50 text-gray-600 rounded hover:bg-gray-100",
                                                    children: "View Email"
                                                }, void 0, false, {
                                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                                    lineNumber: 492,
                                                    columnNumber: 25
                                                }, this)
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                            lineNumber: 474,
                                            columnNumber: 21
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                    lineNumber: 451,
                                    columnNumber: 19
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                                lineNumber: 450,
                                columnNumber: 17
                            }, this)
                        ]
                    }, item.id, true, {
                        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                        lineNumber: 443,
                        columnNumber: 15
                    }, this);
                })
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
                lineNumber: 314,
                columnNumber: 9
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx",
        lineNumber: 262,
        columnNumber: 5
    }, this);
}
_s1(ContactTimelineCard, "8yjWxIxSzeTRPOonKwIEag3TGR0=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRouter"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$QueryClientProvider$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQueryClient"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c1 = ContactTimelineCard;
var _c, _c1;
__turbopack_context__.k.register(_c, "DescriptionContent");
__turbopack_context__.k.register(_c1, "ContactTimelineCard");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/components/contacts/ContactSaveBar.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactSaveBar
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactAutosaveProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
function ContactSaveBar() {
    _s();
    const { isSaving, pendingCount, lastSavedAt, lastError, hasUnsavedChanges, flush, clearError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactAutosave"])();
    const [isManuallySaving, setIsManuallySaving] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showSavedBriefly, setShowSavedBriefly] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    // Show "Saved" briefly after manual save
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ContactSaveBar.useEffect": ()=>{
            if (lastSavedAt && !isSaving && !hasUnsavedChanges && !lastError) {
                setShowSavedBriefly(true);
                const timer = setTimeout({
                    "ContactSaveBar.useEffect.timer": ()=>setShowSavedBriefly(false)
                }["ContactSaveBar.useEffect.timer"], 2000);
                return ({
                    "ContactSaveBar.useEffect": ()=>clearTimeout(timer)
                })["ContactSaveBar.useEffect"];
            } else {
                setShowSavedBriefly(false);
            }
        }
    }["ContactSaveBar.useEffect"], [
        lastSavedAt,
        isSaving,
        hasUnsavedChanges,
        lastError
    ]);
    const handleManualSave = async ()=>{
        setIsManuallySaving(true);
        clearError();
        try {
            const success = await flush();
            if (!success && lastError) {
            // Error already set by flush
            }
        } catch (error) {
        // Error handled by provider
        } finally{
            setIsManuallySaving(false);
        }
    };
    const getStatusText = ()=>{
        if (isSaving || isManuallySaving || pendingCount > 0) {
            return "Saving…";
        }
        if (lastError) {
            return "Couldn't save";
        }
        if (showSavedBriefly) {
            return "Saved";
        }
        if (lastSavedAt) {
            // Show "Saved" if saved within last 5 seconds
            const timeSinceSave = Date.now() - lastSavedAt;
            if (timeSinceSave < 5000) {
                return "Saved";
            }
        }
        return null;
    };
    const getButtonLabel = ()=>{
        if (isSaving || isManuallySaving || pendingCount > 0) {
            return "Saving…";
        }
        if (lastError) {
            return "Retry save";
        }
        if (showSavedBriefly) {
            return "Saved";
        }
        return "Save changes";
    };
    const statusText = getStatusText();
    const buttonLabel = getButtonLabel();
    const isButtonDisabled = !hasUnsavedChanges && pendingCount === 0 && !lastError;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "flex items-center gap-3",
        children: [
            statusText && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                className: `text-sm ${lastError ? "text-red-600 dark:text-red-400" : isSaving || isManuallySaving ? "text-blue-600 dark:text-blue-400" : "text-green-600 dark:text-green-400"}`,
                children: statusText
            }, void 0, false, {
                fileName: "[project]/components/contacts/ContactSaveBar.tsx",
                lineNumber: 86,
                columnNumber: 9
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                onClick: handleManualSave,
                disabled: isButtonDisabled,
                variant: hasUnsavedChanges && !lastError ? "primary" : "outline",
                size: "sm",
                children: buttonLabel
            }, void 0, false, {
                fileName: "[project]/components/contacts/ContactSaveBar.tsx",
                lineNumber: 98,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/components/contacts/ContactSaveBar.tsx",
        lineNumber: 84,
        columnNumber: 5
    }, this);
}
_s(ContactSaveBar, "2aobrGrNNtWQK04kiYZKaiT+zCA=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactAutosave"]
    ];
});
_c = ContactSaveBar;
var _c;
__turbopack_context__.k.register(_c, "ContactSaveBar");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactEditor.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactEditor
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$BasicInfoCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/BasicInfoCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$TagsClassificationCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/TagsClassificationCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActionItemsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ActionItemsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NotesCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/NotesCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NextTouchpointCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/NextTouchpointCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$OutreachDraftCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/OutreachDraftCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ContactInsightsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ContactInsightsCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActivityCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ActivityCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ContactTimelineCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/contact-cards/ContactTimelineCard.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactAutosaveProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useDebouncedAutosave.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactSaveBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactSaveBar.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
;
;
;
;
;
function ContactEditorContent({ contactDocumentId, userId, initialActionItems, initialContact, uniqueSegments = [] }) {
    _s();
    // Read contact directly from React Query cache for optimistic updates
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactDocumentId);
    // Initialize autosave hook (must be inside provider)
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"])();
    // Browser unload guard
    const { hasUnsavedChanges, pendingCount, lastError } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactAutosave"])();
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ContactEditorContent.useEffect": ()=>{
            const handleBeforeUnload = {
                "ContactEditorContent.useEffect.handleBeforeUnload": (e)=>{
                    if (pendingCount > 0 || hasUnsavedChanges || lastError) {
                        e.preventDefault();
                        e.returnValue = "Changes are still saving. Please wait.";
                        return "Changes are still saving. Please wait.";
                    }
                }
            }["ContactEditorContent.useEffect.handleBeforeUnload"];
            window.addEventListener("beforeunload", handleBeforeUnload);
            return ({
                "ContactEditorContent.useEffect": ()=>{
                    window.removeEventListener("beforeunload", handleBeforeUnload);
                }
            })["ContactEditorContent.useEffect"];
        }
    }["ContactEditorContent.useEffect"], [
        hasUnsavedChanges,
        pendingCount,
        lastError
    ]);
    // Show loading state if contact is not available
    if (!contact && !initialContact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                height: "h-96",
                width: "w-full"
            }, void 0, false, {
                fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                lineNumber: 63,
                columnNumber: 9
            }, this)
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
            lineNumber: 62,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-6",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "grid grid-cols-1 xl:grid-cols-3 gap-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "xl:col-span-2 space-y-6",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$BasicInfoCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 73,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$TagsClassificationCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId,
                            uniqueSegments: uniqueSegments
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 74,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActionItemsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId,
                            initialActionItems: initialActionItems,
                            initialContact: contact || undefined
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 79,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NextTouchpointCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 85,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$OutreachDraftCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 86,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$NotesCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ContactTimelineCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 88,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                    lineNumber: 72,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "space-y-6 xl:sticky xl:top-6 xl:self-start",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ContactInsightsCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId,
                            initialContact: initialContact
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 93,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$contact$2d$cards$2f$ActivityCard$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 98,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: "hidden xl:block",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactSaveBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                                lineNumber: 101,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                            lineNumber: 100,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
                    lineNumber: 92,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
            lineNumber: 70,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
        lineNumber: 69,
        columnNumber: 5
    }, this);
}
_s(ContactEditorContent, "322naOtC0worgsjHgvDBwMlyq6I=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useDebouncedAutosave$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDebouncedAutosave"],
        __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContactAutosave"]
    ];
});
_c = ContactEditorContent;
function ContactEditor({ contactDocumentId, userId, initialActionItems, initialContact, uniqueSegments = [] }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactEditorContent, {
        contactDocumentId: contactDocumentId,
        userId: userId,
        initialActionItems: initialActionItems,
        initialContact: initialContact,
        uniqueSegments: uniqueSegments
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ContactEditor.tsx",
        lineNumber: 117,
        columnNumber: 5
    }, this);
}
_c1 = ContactEditor;
var _c, _c1;
__turbopack_context__.k.register(_c, "ContactEditorContent");
__turbopack_context__.k.register(_c1, "ContactEditor");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactsLink.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactsLink
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactGuardedLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactGuardedLink.tsx [app-client] (ecmascript)");
"use client";
;
;
function ContactsLink({ variant = "default", className = "", children = "Back to Contacts" }) {
    const baseClasses = "transition-colors duration-200 font-medium cursor-pointer";
    const variantClasses = {
        default: "flex items-center gap-2 px-4 py-2 text-theme-darkest hover:text-theme-medium rounded-sm",
        error: "inline-block px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-sm"
    };
    const iconSvg = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
        className: "w-5 h-5",
        fill: "none",
        stroke: "currentColor",
        viewBox: "0 0 24 24",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
            strokeLinecap: "round",
            strokeLinejoin: "round",
            strokeWidth: 2,
            d: "M10 19l-7-7m0 0l7-7m-7 7h18"
        }, void 0, false, {
            fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
            lineNumber: 31,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
        lineNumber: 25,
        columnNumber: 5
    }, this);
    // Use ContactGuardedLink if we're on a contact page (will fallback to regular Link if context not available)
    const LinkComponent = __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactGuardedLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"];
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(LinkComponent, {
        href: "/contacts",
        className: `${baseClasses} ${variantClasses[variant]} ${className}`,
        children: [
            variant !== "error" && iconSvg,
            children
        ]
    }, void 0, true, {
        fileName: "[project]/app/(crm)/_components/ContactsLink.tsx",
        lineNumber: 44,
        columnNumber: 5
    }, this);
}
_c = ContactsLink;
var _c;
__turbopack_context__.k.register(_c, "ContactsLink");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/_components/ContactDetailMenu.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactDetailMenu
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContactMutations.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Modal.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Button.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ErrorMessage$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/components/ErrorMessage.tsx [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/error-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__ = __turbopack_context__.i("[project]/lib/error-reporting/index.ts [app-client] (ecmascript) <locals>");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
function ContactDetailMenu({ contactId, userId }) {
    _s();
    const [isOpen, setIsOpen] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showDeleteModal, setShowDeleteModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [showArchiveModal, setShowArchiveModal] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const [deleteError, setDeleteError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [archiveError, setArchiveError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const dropdownRef = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useRef"])(null);
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactId);
    const deleteContactMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteContact"])();
    const archiveContactMutation = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArchiveContact"])(userId);
    // Close dropdown when clicking outside
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useEffect"])({
        "ContactDetailMenu.useEffect": ()=>{
            const handleClickOutside = {
                "ContactDetailMenu.useEffect.handleClickOutside": (event)=>{
                    if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
                        setIsOpen(false);
                    }
                }
            }["ContactDetailMenu.useEffect.handleClickOutside"];
            if (isOpen) {
                document.addEventListener("mousedown", handleClickOutside);
            }
            return ({
                "ContactDetailMenu.useEffect": ()=>{
                    document.removeEventListener("mousedown", handleClickOutside);
                }
            })["ContactDetailMenu.useEffect"];
        }
    }["ContactDetailMenu.useEffect"], [
        isOpen
    ]);
    const handleArchive = ()=>{
        if (!contact) return;
        setArchiveError(null);
        archiveContactMutation.mutate({
            contactId,
            archived: !contact.archived
        }, {
            onSuccess: ()=>{
                setShowArchiveModal(false);
                setIsOpen(false);
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Archiving contact in ContactDetailMenu",
                    tags: {
                        component: "ContactDetailMenu",
                        contactId
                    }
                });
                setArchiveError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    const handleDelete = ()=>{
        setDeleteError(null);
        deleteContactMutation.mutate(contactId, {
            onSuccess: ()=>{
                setShowDeleteModal(false);
                setIsOpen(false);
                // Navigate to contacts page
                window.location.href = "/contacts";
            },
            onError: (error)=>{
                (0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$reporting$2f$index$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__$3c$locals$3e$__["reportException"])(error, {
                    context: "Deleting contact in ContactDetailMenu",
                    tags: {
                        component: "ContactDetailMenu",
                        contactId
                    }
                });
                setDeleteError((0, __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$error$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["extractErrorMessage"])(error));
            }
        });
    };
    if (!contact) return null;
    const contactName = (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact);
    const isArchived = contact.archived || false;
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showDeleteModal,
                onClose: ()=>setShowDeleteModal(false),
                title: "Delete Contact",
                closeOnBackdropClick: !deleteContactMutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: [
                            "Are you sure you want to delete ",
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("strong", {
                                children: contactName
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 107,
                                columnNumber: 43
                            }, this),
                            "? This action cannot be undone."
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                        lineNumber: 106,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setShowDeleteModal(false),
                                disabled: deleteContactMutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 110,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleDelete,
                                disabled: deleteContactMutation.isPending,
                                loading: deleteContactMutation.isPending,
                                variant: "danger",
                                size: "sm",
                                error: deleteError,
                                children: "Delete"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 118,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                        lineNumber: 109,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                lineNumber: 100,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Modal$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                isOpen: showArchiveModal,
                onClose: ()=>setShowArchiveModal(false),
                title: isArchived ? "Unarchive Contact" : "Archive Contact",
                closeOnBackdropClick: !archiveContactMutation.isPending,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                        className: "text-theme-dark mb-6",
                        children: isArchived ? `Are you sure you want to unarchive ${contactName}? They will appear in your contacts list again.` : `Are you sure you want to archive ${contactName}? They will be hidden from your main contacts view but can be restored later.`
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                        lineNumber: 138,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex gap-3 justify-end",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: ()=>setShowArchiveModal(false),
                                disabled: archiveContactMutation.isPending,
                                variant: "outline",
                                size: "sm",
                                children: "Cancel"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 144,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Button$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Button"], {
                                onClick: handleArchive,
                                disabled: archiveContactMutation.isPending,
                                loading: archiveContactMutation.isPending,
                                variant: "primary",
                                size: "sm",
                                error: archiveError,
                                children: isArchived ? "Unarchive" : "Archive"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 152,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                        lineNumber: 143,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                lineNumber: 132,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "relative",
                ref: dropdownRef,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                        onClick: (e)=>{
                            e.stopPropagation();
                            setIsOpen(!isOpen);
                        },
                        className: `p-1.5 rounded-sm transition-colors focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-1 ${isOpen ? "bg-card-light" : "hover:bg-card-light"}`,
                        "aria-label": "Contact options",
                        "aria-expanded": isOpen,
                        "aria-haspopup": "true",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                            className: "w-5 h-5 text-foreground",
                            fill: "none",
                            stroke: "currentColor",
                            viewBox: "0 0 24 24",
                            "aria-hidden": "true",
                            children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                strokeLinecap: "round",
                                strokeLinejoin: "round",
                                strokeWidth: 2,
                                d: "M12 5v.01M12 12v.01M12 19v.01M12 6a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2zm0 7a1 1 0 110-2 1 1 0 010 2z"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 188,
                                columnNumber: 13
                            }, this)
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                            lineNumber: 181,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                        lineNumber: 167,
                        columnNumber: 9
                    }, this),
                    isOpen && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "fixed inset-0 z-10",
                                onClick: ()=>setIsOpen(false),
                                "aria-hidden": "true"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 201,
                                columnNumber: 13
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute left-0 top-full mt-1 z-20 w-48 bg-card-highlight-light border border-theme-lighter rounded-sm shadow-lg py-1",
                                role: "menu",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setIsOpen(false);
                                            setShowArchiveModal(true);
                                        },
                                        className: "w-full text-left px-4 py-2 text-sm text-foreground hover:bg-selected-active transition-colors",
                                        role: "menuitem",
                                        children: isArchived ? "Unarchive" : "Archive"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                        lineNumber: 210,
                                        columnNumber: 15
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                                        onClick: (e)=>{
                                            e.stopPropagation();
                                            setIsOpen(false);
                                            setShowDeleteModal(true);
                                        },
                                        className: "w-full text-left px-4 py-2 text-sm text-red-600 dark:text-red-400 hover:bg-selected-active transition-colors",
                                        role: "menuitem",
                                        children: "Delete"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                        lineNumber: 221,
                                        columnNumber: 15
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                                lineNumber: 206,
                                columnNumber: 13
                            }, this)
                        ]
                    }, void 0, true)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/_components/ContactDetailMenu.tsx",
                lineNumber: 166,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ContactDetailMenu, "9F/fvoupTyupm3ZR55DgjEydHA4=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useDeleteContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContactMutations$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useArchiveContact"]
    ];
});
_c = ContactDetailMenu;
var _c;
__turbopack_context__.k.register(_c, "ContactDetailMenu");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactDetailPageClient
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemedSuspense$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/ThemedSuspense.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactEditor.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactsLink.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactDetailMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/_components/ContactDetailMenu.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactSaveBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactSaveBar.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/contacts/ContactAutosaveProvider.tsx [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/contact-utils.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/components/Skeleton.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
;
;
;
function ContactDetailContent({ contactDocumentId, userId, initialActionItems, uniqueSegments }) {
    _s();
    const { data: contact } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(userId, contactDocumentId);
    const { data: actionItems = initialActionItems || [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"])(userId, contactDocumentId, initialActionItems);
    if (!contact) {
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    height: "h-20",
                    width: "w-full"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 43,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$Skeleton$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    height: "h-96",
                    width: "w-full"
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 44,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
            lineNumber: 42,
            columnNumber: 7
        }, this);
    }
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["Fragment"], {
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                className: "flex flex-col gap-4",
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "flex flex-col xl:flex-row xl:items-start xl:justify-between gap-4",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4 min-w-0 flex-1",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-16 h-16 bg-linear-to-br from-blue-500 to-purple-600 rounded-full flex items-center justify-center text-white font-semibold text-2xl shadow-lg shrink-0",
                                        children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getInitials"])(contact)
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 55,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "min-w-0 flex-1",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                                                className: "text-3xl font-bold text-theme-darkest mb-1 truncate",
                                                children: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$contact$2d$utils$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["getDisplayName"])(contact)
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                lineNumber: 59,
                                                columnNumber: 15
                                            }, this),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                                className: "text-gray-500 flex items-center gap-2 min-w-0",
                                                children: [
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("svg", {
                                                        className: "w-4 h-4 shrink-0",
                                                        fill: "none",
                                                        stroke: "currentColor",
                                                        viewBox: "0 0 24 24",
                                                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("path", {
                                                            strokeLinecap: "round",
                                                            strokeLinejoin: "round",
                                                            strokeWidth: 2,
                                                            d: "M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"
                                                        }, void 0, false, {
                                                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                            lineNumber: 69,
                                                            columnNumber: 19
                                                        }, this)
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                        lineNumber: 63,
                                                        columnNumber: 17
                                                    }, this),
                                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                                        className: "truncate",
                                                        children: contact.primaryEmail
                                                    }, void 0, false, {
                                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                        lineNumber: 76,
                                                        columnNumber: 17
                                                    }, this)
                                                ]
                                            }, void 0, true, {
                                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                lineNumber: 62,
                                                columnNumber: 15
                                            }, this)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 58,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                lineNumber: 54,
                                columnNumber: 11
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "hidden xl:flex xl:items-center xl:gap-3",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        variant: "default"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 81,
                                        columnNumber: 13
                                    }, this),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactDetailMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                                        contactId: contactDocumentId,
                                        userId: userId
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 82,
                                        columnNumber: 13
                                    }, this)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                lineNumber: 80,
                                columnNumber: 11
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                        lineNumber: 53,
                        columnNumber: 9
                    }, this),
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "xl:hidden flex items-center justify-end",
                        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactSaveBar$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {}, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                            lineNumber: 87,
                            columnNumber: 11
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                        lineNumber: 86,
                        columnNumber: 9
                    }, this)
                ]
            }, void 0, true, {
                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                lineNumber: 52,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactEditor$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                contactDocumentId: contactDocumentId,
                userId: userId,
                initialActionItems: actionItems,
                uniqueSegments: uniqueSegments
            }, void 0, false, {
                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                lineNumber: 92,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true);
}
_s(ContactDetailContent, "O2scNxGYdEyGpFgjTxPX2u9HyAY=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"]
    ];
});
_c = ContactDetailContent;
function ContactDetailPageClient({ contactDocumentId, userId, initialActionItems, uniqueSegments }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$contacts$2f$ContactAutosaveProvider$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["ContactAutosaveProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "space-y-6",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "xl:hidden flex items-center justify-between",
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactsLink$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            variant: "default"
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                            lineNumber: 113,
                            columnNumber: 11
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$_components$2f$ContactDetailMenu$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                            contactId: contactDocumentId,
                            userId: userId
                        }, void 0, false, {
                            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                            lineNumber: 114,
                            columnNumber: 11
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 112,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$components$2f$ThemedSuspense$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
                    fallback: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "space-y-6",
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "flex items-center gap-4",
                                children: [
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "w-16 h-16 bg-theme-light rounded-full animate-pulse"
                                    }, void 0, false, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 122,
                                        columnNumber: 17
                                    }, void 0),
                                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                        className: "space-y-2",
                                        children: [
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-8 bg-theme-light rounded w-48 animate-pulse"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                lineNumber: 124,
                                                columnNumber: 19
                                            }, void 0),
                                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                                className: "h-5 bg-theme-light rounded w-64 animate-pulse"
                                            }, void 0, false, {
                                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                                lineNumber: 125,
                                                columnNumber: 19
                                            }, void 0)
                                        ]
                                    }, void 0, true, {
                                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                        lineNumber: 123,
                                        columnNumber: 17
                                    }, void 0)
                                ]
                            }, void 0, true, {
                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                lineNumber: 121,
                                columnNumber: 15
                            }, void 0),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "h-96 bg-theme-light rounded animate-pulse"
                            }, void 0, false, {
                                fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                                lineNumber: 128,
                                columnNumber: 15
                            }, void 0)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                        lineNumber: 120,
                        columnNumber: 13
                    }, void 0),
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(ContactDetailContent, {
                        contactDocumentId: contactDocumentId,
                        userId: userId,
                        initialActionItems: initialActionItems,
                        uniqueSegments: uniqueSegments
                    }, void 0, false, {
                        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                        lineNumber: 132,
                        columnNumber: 11
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
                    lineNumber: 118,
                    columnNumber: 9
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
            lineNumber: 110,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx",
        lineNumber: 109,
        columnNumber: 5
    }, this);
}
_c1 = ContactDetailPageClient;
var _c, _c1;
__turbopack_context__.k.register(_c, "ContactDetailContent");
__turbopack_context__.k.register(_c1, "ContactDetailPageClient");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/app/(crm)/contacts/[contactId]/_components/ContactDetailPageClientWrapper.tsx [app-client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>ContactDetailPageClientWrapper
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/navigation.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useContact.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useActionItems.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/hooks/useAuth.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/@tanstack/react-query/build/modern/useQuery.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/util/timestamp-utils-server.ts [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f5b$contactId$5d2f$ContactDetailPageClient$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/(crm)/contacts/[contactId]/ContactDetailPageClient.tsx [app-client] (ecmascript)");
;
var _s = __turbopack_context__.k.signature();
"use client";
;
;
;
;
;
;
;
function ContactDetailPageClientWrapper({ contactId, userId }) {
    _s();
    const { user, loading: authLoading } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"])();
    // Use userId prop if provided (from SSR), otherwise get from client auth (for E2E mode or if SSR didn't have it)
    // In production, userId prop should always be provided from SSR
    // In E2E mode, it might be empty, so we wait for auth to load and use user?.uid
    const effectiveUserId = userId || (authLoading ? "" : user?.uid || "");
    // React Query automatically uses prefetched data from HydrationBoundary
    const { data: contact, isLoading: contactLoading, isFetching: contactFetching, isFetched: contactFetched } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"])(effectiveUserId, contactId);
    const { data: actionItems = [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"])(effectiveUserId, contactId);
    const { data: uniqueSegments = [] } = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"])({
        queryKey: [
            "unique-segments",
            effectiveUserId
        ],
        queryFn: {
            "ContactDetailPageClientWrapper.useQuery": async ()=>{
                // For now, we'll fetch all contacts and extract unique segments
                // TODO: Create an API route for this if needed
                const response = await fetch("/api/contacts");
                if (!response.ok) {
                    return [];
                }
                const data = await response.json();
                const contacts = data.contacts || [];
                const segments = new Set();
                contacts.forEach({
                    "ContactDetailPageClientWrapper.useQuery": (contact)=>{
                        if (contact.segment?.trim()) {
                            segments.add(contact.segment.trim());
                        }
                    }
                }["ContactDetailPageClientWrapper.useQuery"]);
                return Array.from(segments).sort();
            }
        }["ContactDetailPageClientWrapper.useQuery"],
        staleTime: 5 * 60 * 1000
    });
    // Wait for auth to load and query to complete before calling notFound
    // In Playwright mode, auth might still be loading, so we should wait for it
    // Also, if the query is still loading/fetching, we shouldn't call notFound yet
    // This prevents calling notFound() before React Query hydration completes
    // CRITICAL: Only call notFound if the query has been fetched at least once
    // If contactFetched is false, the query hasn't run yet and placeholderData might not be available
    // Also wait if we don't have a userId yet (query will be disabled until we have one)
    const hasUserId = !!effectiveUserId || !!user?.uid;
    const queryEnabled = !!effectiveUserId && !!contactId;
    const shouldWait = authLoading || !hasUserId || !queryEnabled || contactLoading || contactFetching || !contactFetched;
    // Only call notFound if ALL of these are true:
    // 1. Auth has loaded (!authLoading)
    // 2. We have a userId (auth is ready)
    // 3. Query is enabled (has userId and contactId)
    // 4. Query has been fetched at least once (contactFetched === true)
    // 5. Query is not loading/fetching (query has completed)
    // 6. Contact is explicitly null (not undefined - null means 404, undefined means not fetched yet)
    // Note: We check contact === null (not !contact) because undefined means query hasn't run yet
    // but null means query ran and returned 404
    if (contact === null && !authLoading && hasUserId && queryEnabled && contactFetched && !contactLoading && !contactFetching) {
        (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$navigation$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["notFound"])();
    }
    // If auth is still loading or query is still fetching, show loading state
    // Don't return null - return a loading placeholder to prevent unmounting
    if (shouldWait) {
        // Return a minimal loading state instead of null to prevent unmounting
        return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            style: {
                display: 'none'
            }
        }, void 0, false, {
            fileName: "[project]/app/(crm)/contacts/[contactId]/_components/ContactDetailPageClientWrapper.tsx",
            lineNumber: 79,
            columnNumber: 12
        }, this);
    }
    // Action items are already converted to ISO strings on the server
    // This is just a safety check in case any timestamps slipped through
    const serializedActionItems = actionItems.map((item)=>({
            ...item,
            dueDate: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.dueDate),
            completedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.completedAt),
            createdAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.createdAt) || new Date().toISOString(),
            updatedAt: (0, __TURBOPACK__imported__module__$5b$project$5d2f$util$2f$timestamp$2d$utils$2d$server$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["convertTimestampToISO"])(item.updatedAt) || new Date().toISOString()
        }));
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f28$crm$292f$contacts$2f5b$contactId$5d2f$ContactDetailPageClient$2e$tsx__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], {
        contactDocumentId: contactId,
        userId: userId,
        initialActionItems: serializedActionItems,
        uniqueSegments: uniqueSegments
    }, void 0, false, {
        fileName: "[project]/app/(crm)/contacts/[contactId]/_components/ContactDetailPageClientWrapper.tsx",
        lineNumber: 93,
        columnNumber: 5
    }, this);
}
_s(ContactDetailPageClientWrapper, "4hd56OPEdNETpNXA8C7pq1bthfg=", false, function() {
    return [
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useAuth$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useAuth"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useContact$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useContact"],
        __TURBOPACK__imported__module__$5b$project$5d2f$hooks$2f$useActionItems$2e$ts__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useActionItems"],
        __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f40$tanstack$2f$react$2d$query$2f$build$2f$modern$2f$useQuery$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useQuery"]
    ];
});
_c = ContactDetailPageClientWrapper;
var _c;
__turbopack_context__.k.register(_c, "ContactDetailPageClientWrapper");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
]);

//# debugId=ebf9fdc5-5736-d52d-21a9-246663bbed0b
//# sourceMappingURL=_08370231._.js.map