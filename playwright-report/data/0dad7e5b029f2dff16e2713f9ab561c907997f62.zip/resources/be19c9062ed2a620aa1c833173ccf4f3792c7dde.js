(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/_08370231._.js",
  "static/chunks/node_modules_54bd2c50._.js"
],
    source: "dynamic"
});
