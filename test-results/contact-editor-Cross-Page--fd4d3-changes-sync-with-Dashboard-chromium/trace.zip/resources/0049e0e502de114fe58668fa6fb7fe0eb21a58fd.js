(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__28bc9c2a._.css",
  "static/chunks/node_modules_@tanstack_query-devtools_build_b080155d._.js",
  "static/chunks/_82fb71aa._.js",
  "static/chunks/node_modules_@firebase_auth_dist_esm_940b9c9a._.js",
  "static/chunks/node_modules_@firebase_firestore_dist_index_esm_af799df8.js",
  "static/chunks/node_modules_@sentry_core_build_cjs_629adc4b._.js",
  "static/chunks/node_modules_@sentry_browser_build_npm_cjs_dev_0b137fc6._.js",
  "static/chunks/node_modules_@sentry-internal_browser-utils_build_cjs_2523542d._.js",
  "static/chunks/node_modules_@sentry-internal_replay_build_npm_cjs_index_690b9442.js",
  "static/chunks/node_modules_@sentry_nextjs_build_cjs_f98684cb._.js",
  "static/chunks/node_modules_@tanstack_query-devtools_build_736394b3._.js",
  "static/chunks/node_modules_338ae1fd._.js"
],
    source: "dynamic"
});
